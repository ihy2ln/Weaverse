---
title: Chapter 9
favourite: false
---
## User
Chapter 9 scene beat 1

Ji and elo go shopping first and then after they go shopping they go to the merchant Guild now when they go to the merchant Guild explain in more detail of the merchant Guild from the building exterior and interior and the outgoings of people inside the building. Now after they go into the building they will meet with a rep at the front desk and that rep will gladly help j i and ELO register Ji under the merchant Guild upon registering for the merchant Guild Ji will be able to start selling his Goods that he acquired throughout yesterday's Adventure.

## AI
The market stalls thinned out by midmorning, most of the good produce already gone to early risers. John picked through a crate of dried peppers anyway, turning one over in his fingers before tossing it back.

"These smell like nothing," John said. "Elo, smell this."

"It smells like a pepper."

"Exactly my point."

Elowen bought a sack of grain and two waterskins without haggling, paying whatever the vendor asked and moving on before John caught up. She carried both packs slung over one shoulder like they weighed nothing, which to her, they didn't.

"You're supposed to bargain," John said. "Half the fun's in the bargain."

"I don't like fighting over prices."

"It's not fighting, it's a conversation."

"With yelling."

John gave up on that argument by the third stall and let her buy what she wanted. They filled two packs with rope, oil, a fire-starter kit, and a wedge of hard cheese that Elowen sniffed twice before approving. By the time they turned down Guildmerchant Row, the sun sat high enough to burn off the last of the morning fog.

The Merchant Guild building rose above every shopfront on the street, three storeys of grey granite banded with copper trim gone green with age. Twin banners hung either side of the entrance, the guild's sigil—a scale balanced between a coin and a sword—stitched in gold thread that caught the light every time the wind picked up. Wagons queued along the side alley, porters hauling crates stamped with wax seals toward a loading dock at the rear.

"Big place," John said, tilting his head back to take in the whole front.

"Vale Vanguard's guild hall is half this size," Elowen said. "Adventurers fight. Merchants apparently need more room to argue."

The doors stood open, propped by iron wedges, and the noise hit before they'd crossed the threshold—dozens of overlapping conversations, the clack of an abacus, someone shouting a price two floors up. Inside, the ceiling arched three storeys high, ringed by balconies where clerks leaned over railings to shout figures down at the floor. Long counters ran the length of the room, each one manned by guild reps sorting through crates of goods that adventurers dumped in front of them—monster hides, raw ore, glass vials of something that glowed faint blue, bundles of herbs tied with string.

A board on the far wall listed prices in chalk, numbers erased and rewritten every few minutes by a runner on a ladder. Two men argued over a shipment of iron near the back, voices rising until a guard in guild colours ambled over and the argument dropped to a mutter. Elsewhere, a woman counted coins into neat stacks with the kind of focus John usually only saw in gamblers.

"Everyone's got something to sell," John said.

"Or something to buy," Elowen said. "That man's arguing about the price of nails."

"Nails are important, Elo."

She didn't answer that, just steered him toward the front desk where a shorter counter sat apart from the trading floor, marked with a sign reading NEW REGISTRATIONS in neat block letters.

The rep behind it looked up before they'd fully approached, a middle-aged woman with ink stains on her fingers and a ledger already half open. Her eyes went to John first, then flicked to Elowen's height, then back to John with the kind of polite curiosity guild staff probably trained for.

"First time in the Guild hall?" she said.

"First time anywhere in this city, really," John said. "I've got goods to sell and no idea how any of this works."

"That's what we're here for." She slid the ledger around so it faced him. "You'll need to register as a merchant first—one-time fee, five silver, refundable against your first sale over fifty. Name?"

"John. Just John."

"Surname?"

"Isekai," Elowen said, before John could answer. "He goes by John Isekai."

The rep wrote it down without questioning it, guild clerks having heard stranger names cross this counter. She turned the ledger, tapped a line near the bottom.

"Sign here, and I'll need to see what you're bringing to sell. We appraise on-site, post it to the board, and take a five percent cut on anything that moves. You keep the rest."

John signed his name with more flourish than the moment called for and dropped his pack onto the counter, unbuckling the straps.

"Yesterday's haul," John said. "Some of it I don't even know what it is."

The rep pulled the pack open and started laying items out across the counter—a handful of curved claws still crusted with dried blood, three chunks of something crystalline that hummed faintly against the wood, a coiled length of hide that shimmered when it caught the light.

"Where'd you get gravebeetle carapace?" she said, holding one of the crystalline chunks up to the window light. "This sells for triple what most first-timers bring in."

"We fought something ugly in a cave," John said. "Elo did most of the fighting."

"I hit it until it stopped moving," Elowen said.

The rep set the carapace down, already reaching for a fresh tag to write the appraisal price.

## User
Create a scene beat prompt of 500 Words detailed of exterior and interior, talkitive convo, ecchi, quick bj in the dressing room for the clothing store clerk

for Claude sonnet 5 a scene beat of 1000 words. ELO escorts ji escorts in to the high standing trusted clothing store elo uses first, then to the merchants Guild at the merchants Guild he will sell his Rewards and loot that he acquired during the first day (chapter 1-3).

## AI
# Scene Beat Prompt (500 words) — For Chapter 9, Beat 2

**Scene Goal:** Elowen brings John to a high-end clothing store she personally trusts and frequents, leading into a flirtatious, ecchi-charged shopping sequence that escalates into a quick oral encounter with the store clerk in the dressing room. Afterward, the pair heads to the Merchant Guild, where John sells off the loot and rewards gathered during his first day's adventure (Chapters 1-3).

---

**Exterior Setting:**
Describe the clothing store's storefront as distinct from the market stalls—polished stone facade, tailored mannequins in the window wearing adventurer-grade fashion (function meets flair), a brass bell over the door, awning in muted guild colours. Elowen should reference why she trusts this specific shop (maybe it outfitted her academy gear, or a family connection to Onyx Reach craftsmanship).

**Interior Setting:**
Warm lighting, bolts of fabric stacked along shelves, a fitting area with curtained booths toward the back. Mannequins showing off adventurer cloaks, reinforced travel wear, and CEL-conductive threading for low-rank users. A few other customers browsing, ambient chatter about fabric quality and pricing.

**Talkative Conversation Beats:**
- John needles Elowen about needing new clothes when his current gear works fine; she insists his current outfit "looks cheap" for someone who fought a cave monster.
- Establish the clerk—friendly, forward, complimentary about John's build/presence (playing into his Harem Energy trait and WAHM baseline flirtation). She should measure him with obvious enthusiasm, using teasing dialogue rather than narration to build tension.
- Elowen, oblivious in her straightforward way, encourages the clerk to "take care of him properly," unintentionally setting up the escalation.
- Dialogue should stay quick, bantering, and light before the encounter—no lingering exposition.

**Ecchi Escalation:**
- Clerk leads John to a dressing booth to "check the fit" of trousers or a tunic, using flimsy pretext.
- Elowen waits outside, chatting with another customer or examining fabric, unaware/unbothered by what's happening (consistent with WAHM normalisation of casual intimacy).
- Inside the booth: clerk's dialogue drives the escalation—teasing about his measurements, commenting on his enhanced luck/charm, initiating contact through compliments rather than narrated internal monologue.
- Quick, efficient blowjob scene—keep pacing brisk, dialogue-forward, using her spoken reactions and his responses to carry the scene rather than drawn-out description. Should end with John cleaning up quickly, stepping out casually, Elowen none the wiser or simply unfazed.

**Transition:**
- John purchases the outfit (discounted or "on the house" per clerk's flirtation), they leave the shop.
- Head toward the Merchant Guild building (already described in Chapter 9 Beat 1).

**Merchant Guild Selling Sequence:**
- At the registration/new counter, John lays out the loot acquired during Chapters 1-3 (specify: monster parts, a found dungeon item, raw materials, maybe a rare drop).
- Rep appraises each item aloud, giving prices, reacting with surprise at anything unusually rare.
- Include a comedic or lucky beat tied to John's S-Rank luck trait—an item worth more than expected, or a rep recognising something valuable.
- End on the tally, coin exchange, and Elowen's reaction to the total.

## User
Create a scene beat prompt of 1000 Words detailed of exterior and interior, talkitive convo, ecchi lucky pervert and erotic, Describe the people in the focus of the scene.

Claude sonnet 5 a scene beat of 1500 words.

Scene starts with ji and elo going to the clothing store the wahb pink goblin like female clerk. Happy to help and talkative with elo. As she helped him get a weeks worth of clothes fitted. He went into the dressing room. But seeing her flirtatious mouth movements he wanted to taste that mouth. Kissing her while on the dressing room stool. To having her on her knees so she could use her mouth to give him a quick sultry wet bj mostly of ji fucking her mouth against the dressing room wall, size difference body wise and dick to mouth/throat.

After getting dressed in merchant clothing with support role style gear on top. Gets a heavy discount on a full weeks of outfits, because he was lucky, he gave her a large dose of cel infused nut, and he was a man.

they go to the merchant guild. Be very descriptive of this building. Its made matching the adventure guild but has more cel-stone to which helps to keep the funds safe from bombardment. Wide open floor plan. Dedicated afm lane. (Include some ecchi parts)

He will sell his Rewards and loot that he acquired during the first day (in the earlier chapters). Which will net him a few hundred gold…which is over two months of living expenses…if he was going out living the life short term rich in just one day. (Lucky pervert for the win)

Before ji and elo left they were called to the 3rd floor to talk with the merchant gm.

End scene of them being escorted by a tall bunny womab with a phat toned ass that ji stares at as they climb the stairs.

## AI
# Scene Beat Prompt (1500 words) — For Chapter 9, Beat 2

**Scene Goal:** Elowen leads John into a trusted clothing store where a WAHB pink goblin-like clerk fits him for a week's worth of clothes. Flirtation escalates into a dressing-room encounter—John initiates a kiss after fixating on her mouth, then guides her to her knees for a rough, sultry blowjob against the dressing room wall, emphasizing size difference (his enhanced proportions vs. her smaller goblin frame, dick-to-mouth/throat stretch). He pays part of the discount with CEL-infused semen, leveraging his male status and luck. The pair then heads to the Merchant Guild—architecturally similar to the Adventure Guild but reinforced with denser CEL-stone, featuring a dedicated AFM lane. John sells his Chapter 1-3 loot for a lucky windfall (several hundred gold, months of living expenses in one sitting). Before leaving, they're summoned to the third floor to meet the Merchant Guild Master. Scene ends as a tall, toned bunny-eared woman with a prominent rear escorts them up the stairs, John's eyes locked on her the whole climb.

---

## Clothing Store Interior & Clerk

**Setting:** Warm interior lit by hanging CEL-lanterns, bolts of fabric in every colour stacked floor to ceiling, adventurer-grade outfits on mannequins ranging from reinforced travel cloaks to support-class robes threaded with faint CEL conductivity lines.

**The Clerk:** A WAHB pink goblin-type woman—short by Adams Haven standards but still towering over John, skin a soft rosy-pink with a faint goblin cast to her features (pointed ears, slightly upturned nose, sharp little canines that show when she grins). Despite the goblin heritage, her body follows full WAHB proportions—exaggerated hourglass, oversized chest straining her shop apron, hips flaring wide beneath a cinched waist. She should be talkative from the moment they enter, immediately warming to Elowen (commenting on her build, asking about her blade, gossiping about mutual acquaintances in the trade). Her attention shifts to John with obvious, unshy interest—commenting on his rarity as a male customer, teasing about his "cute face" while taking his measurements with a tailor's tape, letting her hands linger.

**Talkative Beats:**
- Elowen and the clerk chat like old friends—shop talk, pricing, maybe a shared joke about difficult customers.
- Clerk fusses over John, listing outfit options for a full week: casual wear, a formal set, travel gear, sleepwear—rattling off fabric types and support-class enhancements woven into the seams.
- Her mouth should be a visual focus during this exchange—full lips, exaggerated movements as she talks, biting her lip while measuring his inseam, smirking around whatever teasing line she delivers next.
- John's internal focus (delivered through dialogue/action, not narration) locks onto her mouth—he comments on it, maybe asks something forward, sets up the pretext to get her alone in the dressing booth.

## Dressing Room Encounter

**Setup:** John steps into the fitting booth to try the first outfit. Clerk follows to "check the fit," pulling the curtain. Elowen remains outside, chatting with another customer or examining a bolt of fabric, unbothered by the delay—consistent with WAHM normalization of casual intimacy, no suspicion needed.

**Escalation:**
- John, seated on the fitting stool, pulls her down for a kiss rather than letting her keep talking—decisive, not hesitant. Her surprise should read as brief, replaced fast by enthusiasm (WAHM wiring toward male desire).
- Dialogue drives the pacing—her teasing about his forwardness, him commenting on finally getting to taste that mouth, quick back-and-forth rather than narrated internal monologue.
- Guide her down to her knees. Establish the size contrast physically through dialogue and blocking—she has to adjust her jaw, comment on the stretch, react to the size difference (14" length against a goblin-sized mouth/throat).
- The blowjob should be rough and quick—John taking control, pressing her against the dressing room wall, minimal soft buildup. Her muffled reactions, gagging/adjusting sounds through dialogue cues, praise from John. End on his climax—reference the CEL-infused nature of his release without lingering on mechanics already established in his codex (Vital Infusion).
- Quick cleanup, both stepping out of the booth composed, Elowen none the wiser or entirely unfazed if she notices.

## Discount Negotiation

- Clerk rings up the week's outfits at full price, then knocks a heavy discount off the total—dialogue should establish this ties to his luck stat and rarity as a male customer (AFM cultural reverence), plus the "payment" of a large dose of his CEL-infused release, framed casually within the world's norms rather than transactional.
- John leaves dressed in new merchant-appropriate clothing layered with support-role gear—define the outfit briefly (practical trousers, a fitted tunic, a satchel-vest hybrid suited to a support specialist).

## Merchant Guild Exterior & Interior

**Exterior:** Should mirror the Adventure Guild's architecture—Silverwood timber framing, marble accents—but noticeably reinforced with a much higher density of Celestium-veined stone, the walls humming with a visible blue-white pulse. Establish this CEL density exists specifically for financial security (bombardment/magical theft resistance), giving the building a fortress-like presence despite its commercial function. Bank-adjacent aesthetic—more vault than guild hall.

**Interior:** Wide open floor plan, different from the Adventure Guild's segmented rooms—one enormous trading floor visible from the entrance, sectioned only by low dividers and standing counters. Include a dedicated **AFM lane**—a roped-off, plush-carpeted corridor with its own staff, clearly marked for male patrons, offering expedited service, private appraisal booths, and attentive staff who visibly light up when a male enters. John should note the lane exists, maybe get flagged toward it by staff, creating a small ecchi beat (a staff member fawning, escorting him personally, perhaps a lingering touch or compliment).

**Ecchi Beats:** Female staff throughout the guild floor should react to John's presence per world-building (WAHM baseline attraction)—glances, a comment from a passing clerk, someone "accidentally" brushing against him while reviewing his loot.

## Selling the Loot

- John lays out his Chapter 1-3 haul at the appraisal counter—reference the specific items already established (whatever he collected from his first adventure/cave encounter—claws, crystalline chunks, hide).
- The appraiser should react with visible surprise at a rare item hidden in the pile (tie to his S-Rank luck—something worth far more than a first-timer should have stumbled onto).
- T

## User
Create a scene beat prompt of 1000 Words detailed of exterior and interior, talkitive convo, ecchi lucky pervert and erotic, Describe the people in the focus of the scene.







Claude sonnet 5 a scene beat of 1500 words.







Scene starts with ji and elo going to the clothing store the wahb pink goblin like female clerk. Happy to help and talkative with elo. As she helped him get a weeks worth of clothes fitted. He went into the dressing room. But seeing her flirtatious mouth movements he wanted to taste that mouth. Kissing her while on the dressing room stool. To having her on her knees so she could use her mouth to give him a quick sultry wet bj mostly of ji fucking her mouth against the dressing room wall, size difference body wise and dick to mouth/throat.







After getting dressed in merchant clothing with support role style gear on top. Gets a heavy discount on a full weeks of outfits, because he was lucky, he gave her a large dose of cel infused nut, and he was a man.







they go to the merchant guild. Be very descriptive of this building. Its made matching the adventure guild but has more cel-stone to which helps to keep the funds safe from bombardment. Wide open floor plan. Dedicated afm lane. (Include some ecchi parts)







He will sell his Rewards and loot that he acquired during the first day (chapters 1-3). Which will net him a few hundred gold…which is over two months of living expenses…if he was going out living the life short term rich in just one day. (Lucky pervert for the win)







Before ji and elo left they were called to the 3rd floor to talk with the merchant gm.







End scene of them being escorted by a tall bunny womab with a phat toned ass that ji stares at as they climb the stairs.

## AI
# Scene Beat Prompt (1500 words) — For Chapter 9, Beat 2

**Scene Goal:** Elowen escorts John into a trusted clothing shop for a week's worth of fitted outfits. The WAHB pink goblin clerk is warm, chatty, and openly flirtatious with both of them. John fixates on her mouth mid-conversation and pulls her into the dressing booth, kissing her before working her down to her knees for a rough, size-contrasted blowjob against the booth wall. He pays part of the bill in CEL-infused seed, stacking with his luck stat to land a steep discount on the full week's wardrobe. Dressed in new merchant-appropriate gear, he and Elowen head to the Merchant Guild—a building that mirrors the Adventure Guild's construction but saturated with far denser Celestium-stone for financial security, featuring a wide-open trading floor and a dedicated AFM lane. John sells his Chapter 1-3 loot for a lucky windfall worth months of living expenses. Before leaving, a runner summons them to the third floor to meet the Merchant Guild Master. The scene ends as a tall bunny-eared escort leads them up the stairs, John's eyes locked on her rear the entire climb.

---

## Clothing Store — Exterior & Interior

**Exterior:** A narrow but well-kept storefront wedged between two larger guild-adjacent buildings, its sign carved from pale silverwood and painted in soft rose-gold lettering. Bay windows display mannequins in layered travel wear—reinforced trousers, support-class robes with faint CEL-thread stitching visible along the seams. The door chimes on entry, brass and glass, polished from decades of handling.

**Interior:** Warm, cluttered-but-organized—bolts of fabric stacked to the ceiling in every colour, a long counter with a measuring station, and a row of curtained fitting booths along the back wall. CEL-lanterns hang at intervals, casting a gentle amber glow that makes every fabric look richer than it probably is.

**The Clerk — Description Focus:** A WAHB pink goblin-type woman, shorter than Elowen but still a head or more above John, with rosy-pink skin, pointed ears, an upturned nose, and small sharp canines that flash when she grins. Despite the goblin cast to her face, her body runs full WAHB template—wide hips, cinched waist, an apron straining across an oversized chest. Her mouth should be a repeated visual anchor: full lips, exaggerated movement when she talks, a habit of biting her bottom lip mid-sentence or smirking around a tease.

**Talkative Beats:**
- She and Elowen fall into easy, familiar chatter—comments on Elowen's blade, a shared joke about a mutual acquaintance, maybe a quick exchange about guild politics or a recent shipment of fabric.
- She turns her attention to John with unshy enthusiasm, commenting on the novelty of a male customer, rattling off outfit categories for a full week—daywear, travel gear, a formal set, sleepwear—while measuring him with a tailor's tape, letting her hands linger at his waist or inseam.
- Dialogue should carry the flirtation entirely—no internal narration of attraction, just her teasing lines and his responses building toward the pretext of getting her alone.
- John should comment directly on her mouth at some point—something forward, something that gives him the excuse to follow her into the booth.

## Dressing Room Encounter

**Setup:** John steps into the booth to try the first outfit. She follows to "check the fit," curtain drawn. Elowen stays outside, examining fabric or chatting with another customer, entirely unbothered by the delay—consistent with WAHM normalization of casual intimacy.

**Escalation:**
- Seated on the fitting stool, John pulls her down into a kiss mid-sentence rather than waiting for an opening—decisive, not tentative. Her surprise should be brief, replaced immediately by enthusiasm.
- Dialogue carries the shift—her teasing him for being bold, him saying something about finally getting to taste what she's been offering all along.
- He guides her to her knees. Establish the size contrast through dialogue and blocking—she adjusts her jaw, comments on the stretch, reacts audibly to the difference between his proportions and her mouth/throat.
- The blowjob plays rough and fast—John taking control, pressing her back against the booth wall, minimal soft buildup, praise and commands driving the pace. Her muffled sounds and adjustments should read through dialogue cues (gagging, swallowing, brief protests that aren't really protests).
- Climax hits with his CEL-infused release—reference the effect through her reaction (a shudder, a glow beneath her skin, a stated craving) rather than re-explaining the mechanic in full.
- Quick cleanup. Both step out of the booth composed. Elowen doesn't react, or reacts with mild, matter-of-fact acknowledgment at most.

## Discount Negotiation

- At the counter, she rings up the full week's wardrobe, then knocks a steep discount off the total—dialogue should tie this openly to his luck stat, his rarity as a male customer under AFM custom, and the "payment" of a generous dose of his release, treated as an unremarkable transactional norm in this world rather than anything transgressive.
- John leaves dressed in the new outfit—practical merchant trousers, a fitted tunic, a satchel-vest layered over the top with subtle CEL-conductive threading suited to a support specialist's role.

## Merchant Guild — Exterior & Interior

**Exterior:** Architecturally similar to the Silverbrook Adventure Guild—Silverwood timber framing, pale marble facing—but the Celestium veining running through the stone sits far denser here, glowing with a steadier, brighter pulse. Establish this density exists deliberately for financial security, giving the building a vault-like presence: thick walls, reinforced shutters, a subtle hum in the air that adventurers might associate with wards rather than aesthetics.

**Interior:** Unlike the Adventure Guild's segmented room layout, the Merchant Guild opens into one enormous trading floor—wide open, sectioned only by low counters and standing appraisal stations. Overhead, a domed CEL-stone ceiling washes the floor in cool blue-white light. Clerks move between stations with ledgers, runners dash between counters and a chalk board tallying live prices.

**AFM Lane:** A roped-off corridor along one side of the floor, plush carpet distinguishing it from the open stone elsewhere, staffed by attentive clerks who light up visibly when a male approaches. John gets flagged toward it by a staff member the moment he's noticed—include a small ecchi beat here, a clerk fawning over him, maybe a lingering touch on his arm as she guides him toward a private appraisal booth.

**Ecchi Beats (Ambient):** Female staff throughout the floor should react to John's presence per world norms—glances held a beat too long, a passing clerk "accidentally" brushing against him, someone commenting to a colleague within easy earshot.

## Selling the Loot

- At the appraisal counter, John lays out everything gathered across Chapters 1-3—the GKOM shards, the slime oil vial, the Starlight Mushrooms, Moonpetal flower, Silvervein Ore chunks, the crystallized sap.
- The appraiser reacts with visible surprise at the rarity of several items, especially anything a first-timer shouldn't have stumbled onto—tie this explicitly to his S-Rank luck through her dialogue.
- Running tally lands in the hundreds of gold—establish through dialogue that this equals two-plus months of comfortable living expenses in a single day's haul. Elowen should react to the total, maybe teasing him about being "rich" already.

## Summons to the Third Floor

- Before they leave, a runner or floor clerk approaches with a message—the Merchant Guild Master wants a word, third floor, now.
- Brief exchange of confusion/curiosity between John and Elowen about why a guildmaster would want to see them personally after one appraisal.

## Closing Image

- A tall, toned bunny-eared woman arrives to escort them up—describe her build in WAHB terms, emphasizing a prominent, toned rear that draws John's attention the entire climb up the staircase, with Elowen noticing his staring but not commenting, or commenting dryly.
- End the scene on that image—John's eyes fixed upward, the stairs stretching ahead, the mystery of the summons left open for the next beat.

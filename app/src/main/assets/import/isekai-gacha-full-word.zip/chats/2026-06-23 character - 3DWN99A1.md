---
title: Character
favourite: false
---
## User
Make a cel-a ability JI's codex. His cel-a ability needs a proper name. Support build like a bard but also has a pasive buffing as well.

Passively raises mental moral and physical conditioning.

Using skills he can raise a target(s) stats. Has 3 skills a low rank low mp solo target skill. A medium rank skill medium mp that will raise a small group in an immediate area. And a high rank skill with medium mp for a high boost of a small group.

## AI
### **CODEX: CEL-A Ability – [Silver Chord Symphony]**

**Wielder:** John "Isekai"  
**Rank:** D (Current) – evolves with I-Point investment  
**Type:** Passive/Active Support (Bardic Resonance)  
**Visual Indicators:** Faint silver-blue harmonic ripples in the air; targets’ veins pulse with soft light during buff activation.

---

#### **Passive Aura: [Harmonic Foundation]**

- **Effect:** John radiates a constant 30m-radius aura that gently raises morale, sharpens reflexes, and accelerates minor physical recovery (scrapes, fatigue, mental fog).  
- **Mechanics:** No CEL cost. The effect is subtle—like a reassuring hum in the back of the mind—but cumulative over hours.  
- **Stacking:** Does not stack with other passive auras, but complements active skills.

---

#### **Active Skills**

John channels CEL through his voice or touch to weave “resonance threads” that temporarily amplify a target’s attributes.

---

### **Ⅰ. [Focal Note] – Low Rank, Low MP, Single Target**

- **Cost:** 5% CEL reserves  
- **Range:** Touch or line-of-sight (10m)  
- **Duration:** 30 seconds  
- **Effect:** +15% to one chosen stat (STR, DEX, CON, INT, WIS, or CHA) for one ally.  
- **Cooldown:** 10 seconds  
- **Usage:** Quick combat injection – e.g., boosting a vanguard’s strength for a decisive blow or a mage’s INT for a spell.  
- **Visual:** A single silver-blue note rings in the air; the target’s skin briefly shimmers.

---

### **Ⅱ. [Harmonic Chorus] – Medium Rank, Medium MP, Small Group (Area)**

- **Cost:** 15% CEL reserves  
- **Range:** 15m radius centered on John  
- **Duration:** 1 minute  
- **Effect:** All allies within radius gain +10% to their two highest base stats (calculated at cast). If the ally has no clear “highest,” randomly selects two.  
- **Cooldown:** 2 minutes  
- **Usage:** Squad buff before engagement or during skirmish repositioning.  
- **Visual:** A soft chord emanates from John, causing the air to ripple like heat haze. Allies’ eyes briefly flash silver.

---

### **Ⅲ. [Crescendo Union] – High Rank, Medium MP, Small Group (Targeted)**

- **Cost:** 25% CEL reserves  
- **Range:** 20m – John must designate up to 5 visible allies  
- **Duration:** 45 seconds  
- **Effect:** +25% to all stats for the targeted allies. Additionally, any one of John’s activated support skills (e.g., Vital Transfer) has its effect doubled while Crescendo Union is active.  
- **Cooldown:** 5 minutes  
- **Usage:** Boss fights or critical moments. High MP cost leaves John vulnerable; he must rely on his luck and allies’ protection.  
- **Visual:** A brilliant silver-blue crescendo of light arcs from John to each designated ally, leaving trails like shooting stars. Targets become outlined in silver energy.

---

#### **Rank Progression (Future)**

- **C-Rank:** [Focal Note] duration increases to 2 minutes. [Harmonic Chorus] gains +5% additional effect.  
- **B-Rank:** [Crescendo Union] cooldown reduced to 3 minutes; can now target 7 allies.  
- **A-Rank:** Passive aura extends to 50m and begins to grant minor regeneration (1hp/min).  
- **S-Rank:** All skills gain a “Resonance Overdrive” – next cast costs 50% less MP.

---

**Note from IIS Assistant:** *“Silver Chord Symphony is a textbook support ability. It won’t win fights alone, but it turns good fighters into great ones. Ideal for John’s style—make everyone else shine while he stays in the back. Just don’t let him get cornered.”*

## User
Not bard related just as a refrence

## AI
### **CODEX: CEL-A Ability – [Inspiring Presence]**

**Wielder:** John "Isekai"  
**Rank:** D (Current) – evolves with I-Point investment  
**Type:** Passive/Active Support (Resonant Empowerment)  
**Visual Indicators:** John's silver eyes glow faintly; a warm, almost imperceptible shimmer surrounds allies when buffs are active.

---

#### **Passive Aura: [Sustained Confidence]**

- **Effect:** John radiates a constant 30m-radius aura that gently lifts morale, sharpens mental clarity, and accelerates minor physical recovery (bruises, fatigue, mental fog).  
- **Mechanics:** No CEL cost. The effect is subtle—like a steadying hand on the shoulder—but cumulative over hours.  
- **Stacking:** Does not stack with other passive auras, but complements active skills.

---

#### **Active Skills**

John channels CEL through his voice, touch, or mere presence to "imprint" a temporary boost onto allies.

---

### **Ⅰ. [Focused Encouragement] – Low Rank, Low MP, Single Target**

- **Cost:** 5% CEL reserves  
- **Range:** Touch or line-of-sight (10m)  
- **Duration:** 30 seconds  
- **Effect:** +15% to one chosen stat (STR, DEX, CON, INT, WIS, or CHA) for one ally.  
- **Cooldown:** 10 seconds  
- **Usage:** Quick combat injection – e.g., boosting a vanguard’s strength for a decisive blow or a mage’s INT for a spell.  
- **Visual:** John's eyes flash silver; the target's skin briefly glows with a faint silver sheen.

---

### **Ⅱ. [Morale Surge] – Medium Rank, Medium MP, Small Group (Area)**

- **Cost:** 15% CEL reserves  
- **Range:** 15m radius centered on John  
- **Duration:** 1 minute  
- **Effect:** All allies within radius gain +10% to their two highest base stats (calculated at cast). If the ally has no clear "highest," randomly selects two.  
- **Cooldown:** 2 minutes  
- **Usage:** Squad buff before engagement or during skirmish repositioning.  
- **Visual:** A pulse of silver light radiates from John; allies feel a surge of confidence and energy.

---

### **Ⅲ. [Peerless Drive] – High Rank, Medium MP, Small Group (Targeted)**

- **Cost:** 25% CEL reserves  
- **Range:** 20m – John must designate up to 5 visible allies  
- **Duration:** 45 seconds  
- **Effect:** +25% to all stats for the targeted allies. Additionally, any one of John’s other support skills (e.g., Vital Transfer) has its effect doubled while Peerless Drive is active.  
- **Cooldown:** 5 minutes  
- **Usage:** Boss fights or critical moments. High MP cost leaves John vulnerable; he must rely on his luck and allies’ protection.  
- **Visual:** Silver-blue light arcs from John to each designated ally, leaving trails like shooting stars. Allies become outlined in silver energy.

---

#### **Rank Progression (Future)**

- **C-Rank:** [Focused Encouragement] duration increases to 2 minutes. [Morale Surge] gains +5% additional effect.  
- **B-Rank:** [Peerless Drive] cooldown reduced to 3 minutes; can now target 7 allies.  
- **A-Rank:** Passive aura extends to 50m and grants minor regeneration (1hp/min).  
- **S-Rank:** All skills gain a "Resonance Overdrive" – next cast costs 50% less MP.

---

**Note from IIS Assistant:** *"Inspiring Presence is exactly what John needs – a support that makes everyone around him better without drawing attention. Just keep him alive, and the team becomes unstoppable."*

## User
Create a codex for JI incubus racial abilites. Create an over name for the

His cel infused sperm can act like a potion. Deoendant on the users intent will create its use. If the user wants it to heal it can heal, or be used for energy recovery, or a mixture of both.

The more ingested the more potent the effects will be.

1 small vials worth is that of a D-rank potion. A large vial is C-rank, through a gallons worth is an elixer A grade quality.

Even his excrements can offer positive effects. Not as strong as the sperm.

Only downside is that has to be ingested or "absorbed" before it gets cold.

## AI
### **CODEX: Incubus Racial Abilities – [Essence Alchemy]**

**Wielder:** John "Isekai"  
**Type:** Passive Biological Production (CEL-Infused Secretions)  
**Visual Indicators:** Semen glows faint silver-blue for 60 seconds post-ejaculation before losing potency.

---

#### **Core Mechanism: [L

## User
10 minute before his sperm cools down

## AI
### **CODEX: Incubus Racial Abilities – [Essence Alchemy]**

**Wielder:** John "Isekai"  
**Type:** Passive Biological Production (CEL-Infused Secretions)  
**Potency Window:** 10 minutes post-production before properties degrade

---

#### **Core Mechanism: [Vital Infusion]**

John's body naturally saturates his seminal fluid with concentrated CEL energy during production. The resulting substance functions as a consumable buff—potency and effect depend on intent at the moment of release and volume produced.

**Activation:** Intent-based. At climax, John visualizes the desired effect (healing, energy restoration, or balanced mixture). The CEL imprints that intent into the fluid.

**Consumption Requirement:** Must be ingested or absorbed transdermally within 10 minutes of production. After the window closes, the CEL dissipates and the fluid becomes inert.

---

#### **Potion Equivalency by Volume**

| Volume | Equivalent Grade | Effect Duration | Typical Uses |
|--------|------------------|-----------------|--------------|
| Small vial (5ml) | D-rank potion | 15 minutes | Combat patch-up, minor stamina refill |
| Large vial (30ml) | C-rank potion | 1 hour | Moderate wound closure, significant energy recovery |
| Gallon (≈3.8L) | A-rank elixir | 8 hours | Full regeneration, complete stamina restoration, status cleanse |

**Note:** The gallon threshold requires multiple sessions or extended production—John's daily output averages 3 gallons total across 24 hours.

---

#### **Effect Types (Intent-Dependent)**

**Healing Focus:** Accelerates natural regeneration, closes wounds, mends minor fractures. Requires recipient to mentally accept the healing intent—resistance halves effectiveness.

**Energy Recovery:** Restores CEL reserves, soothes mental fatigue, sharpens reflexes. Ideal for allies who've overextended their abilities.

**Balanced Mixture:** Splits potency 50/50 between healing and recovery. Weaker in both categories but versatile for emergencies.

---

#### **Secondary Secretions: [Residual Essence]**

Sweat, saliva, and other bodily fluids carry trace amounts of CEL—roughly 10% the potency of seminal fluid by equivalent volume.

- **Sweat:** Absorbed through skin contact. Provides mild stamina recovery (E-rank equivalent per liter).
- **Saliva:** Transferred via kissing or shared drinks. Grants temporary +5% to mental clarity for 10 minutes per 50ml.
- **Urine:** Least potent. Can be processed into low-grade fertilizer or weak stamina tonic (F-rank) if collected fresh.

---

#### **Limitations & Drawbacks**

- **Production Cooldown:** Refractory period of 2 minutes minimum between "harvests." Repeated production within an hour yields diminishing CEL concentration (minus 15% per cycle).
- **Intent Lock:** Once imprinted, the effect cannot be changed. Poor visualization produces weaker or muddled results.
- **Dependency Risk:** Regular recipients build tolerance. After 10 doses within a week, potency drops 5% per subsequent dose until a 72-hour reset.
- **Personal Cost:** Each ejaculation consumes roughly 3% of John's daily CEL reserves. Heavy production leaves him drained and vulnerable.

---

**IIS Assistant Note:** *"Essence Alchemy turns John into a walking apothecary. Keep him fed, hydrated, and rested, and he can keep an entire squad operational. Just don't let him overproduce—a depleted John is a dead John."*

## User
Excrement is F-C rank.

Max time limit of degregration is when his fluids dry up. If kept warm/fresh can drastically delay the timer.

## AI
### **CODEX: Incubus Racial Abilities – [Essence Alchemy]**

**Wielder:** John "Isekai"
**Type:** Passive Biological Production (CEL-Infused Secretions)
**Degradation Timer:** Fluid must remain wet/fresh. Drying triggers CEL dissipation—complete degradation occurs once fully dry. Warm storage dramatically delays drying time.

---

#### Core Mechanism: [Vital Infusion]

John's body naturally saturates his seminal fluid with concentrated CEL energy during production. The resulting substance functions as a consumable buff—potency and effect depend on intent at the moment of release and volume produced.

**Activation:** Intent-based. At climax, John visualizes the desired effect (healing, energy restoration, or balanced mixture). The CEL imprints that intent into the fluid.

**Consumption Requirement:** Must be ingested or absorbed transdermally before the fluid fully dries. Warm, sealed containers can preserve potency for hours. Cold storage slows evaporation but doesn't halt it—refrigeration buys 2-3 hours. Direct sunlight or open air cuts the window to minutes.

---

#### Potion Equivalency by Volume

| Volume | Equivalent Grade | Effect Duration | Typical Uses |
|--------|------------------|-----------------|--------------|
| Small vial (5ml) | D-rank potion | 15 minutes | Combat patch-up, minor stamina refill |
| Large vial (30ml) | C-rank potion | 1 hour | Moderate wound closure, significant energy recovery |
| Gallon (≈3.8L) | A-rank elixir | 8 hours | Full regeneration, complete stamina restoration, status cleanse |

**Note:** The gallon threshold requires multiple sessions or extended production—John's daily output averages 3 gallons total across 24 hours.

---

#### Effect Types (Intent-Dependent)

**Healing Focus:** Accelerates natural regeneration, closes wounds, mends minor fractures. Requires recipient to mentally accept the healing intent—resistance halves effectiveness.

**Energy Recovery:** Restores CEL reserves, soothes mental fatigue, sharpens reflexes. Ideal for allies who've overextended their abilities.

**Balanced Mixture:** Splits potency 50/50 between healing and recovery. Weaker in both categories but versatile for emergencies.

---

#### Secondary Secretions: [Residual Essence]

Sweat, saliva, and other bodily fluids carry trace amounts of CEL—roughly 10% the potency of seminal fluid by equivalent volume.

- **Sweat:** Absorbed through skin contact. Provides mild stamina recovery (E-rank equivalent per liter).
- **Saliva:** Transferred via kissing or shared drinks. Grants temporary +5% to mental clarity for 10 minutes per 50ml.

---

#### Excretions: [Waste Transmutation]

Even John's solid and liquid waste carries CEL residue—far weaker than primary secretions but still functional.

| Volume | Equivalent Grade | Effect | Degradation |
|--------|------------------|--------|-------------|
| Single bowel movement | F-rank | Minor digestive aid, mild detoxification | 30 minutes wet |
| Full day's collection | E-rank | Moderate stamina boost, appetite suppression | 20 minutes wet |
| Processed concentrate (distillation) | D to C-rank | Energy recovery equivalent to weak potion | 10 minutes wet |

**Drawback:** Psychological barrier. Most recipients balk at consumption regardless of effect. The CEL content is genuine—the delivery method is the hurdle.

**Processing Note:** Waste can be refined into usable tonics through alchemical distillation. John's IIS assistant can provide blueprints for a basic extractor. The resulting product removes original form and texture, leaving a murky amber liquid. Potency degrades to F-rank minimum through processing but becomes palatable.

---

#### Preservation Methods

| Method | Extended Timer | Notes |
|--------|----------------|-------|
| Body temperature storage | +30 minutes | Held against skin or inside body cavity |
| Insulated thermos | +2 hours | Pre-warmed container doubles efficiency |
| CEL-infused crystal container | +6 hours | Expensive; crystal costs 500 credits each |
 | Refrigeration | +3 hours | Slows but doesn't stop degradation |
| Freezing | +8 hours | Thawing accelerates degradation—use immediately |
| Direct sunlight | -50% timer | UV accelerates CEL breakdown |
| Open air | -75% timer | Evaporation kills potency fast |

---

#### Limitations & Drawbacks

- **Production Cooldown:** Refractory period of 2 minutes minimum between "harvests." Repeated production within an hour yields diminishing CEL concentration (minus 15% per cycle).
- **Intent Lock:** Once imprinted, the effect cannot be changed. Poor visualization produces weaker or muddled results.
- **Dependency Risk:** Regular recipients build tolerance. After 10 doses within a week, potency drops 5% per subsequent dose until a 72-hour reset.
- **Personal Cost:** Each ejaculation consumes roughly 3% of John's daily CEL reserves. Heavy production leaves him drained and vulnerable.

---

**IIS Assistant Note:** *"Essence Alchemy turns John into a walking apothecary. Keep him fed, hydrated, and rested, and he can keep an entire squad operational. Just don't let him overproduce—a depleted John is a dead John. And for the love of god, don't let anyone talk him into the waste route unless absolutely necessary. The psychological damage isn't worth the F-rank boost."*

## User
No exctement drawbacks.

Incubus sperm, piss, and even fecal matter suite the users taste.

Extrement sweat and saliva is F-D, piss and fecal is D-C,

## AI
### **CODEX: Incubus Racial Abilities – [Essence Alchemy]**

**Wielder:** John "Isekai"
**Type:** Passive Biological Production (CEL-Infused Secretions)
**Degradation Timer:** Fluids remain potent until fully dry. Warm storage dramatically delays drying. Open air or direct sunlight accelerates evaporation.

---

#### Core Mechanism: [Vital Infusion]

John's body naturally saturates all bodily fluids with concentrated CEL energy during production. The resulting substances function as consumable buffs—potency and effect depend on intent at the moment of release and volume produced.

**Activation:** Intent-based. At climax or voiding, John visualizes the desired effect (healing, energy restoration, or balanced mixture). The CEL imprints that intent into the fluid.

**Consumption Requirement:** Must be ingested or absorbed transdermally before the fluid fully dries. Warm, sealed containers preserve potency for hours. Cold storage slows evaporation but doesn't halt it—refrigeration buys 2-3 hours. Direct sunlight or open air cuts the window to minutes.

**Palatability:** All of John's CEL-infused secretions naturally adapt to suit the consumer's taste preferences. Semen, urine, sweat, saliva, and fecal matter present as pleasantly flavored to each individual—sweet, savory, tart, or neutral based on personal palate. The body instinctively recognizes the substances as beneficial rather than waste.

---

#### Primary Secretion: Seminal Fluid

| Volume | Equivalent Grade | Effect Duration | Typical Uses |
|--------|------------------|-----------------|--------------|
| Small vial (5ml) | D-rank potion | 15 minutes | Combat patch-up, minor stamina refill |
| Large vial (30ml) | C-rank potion | 1 hour | Moderate wound closure, significant energy recovery |
| Gallon (≈3.8L) | A-rank elixir | 8 hours | Full regeneration, complete stamina restoration, status cleanse |

**Note:** The gallon threshold requires multiple sessions or extended production—John's daily output averages 3 gallons total across 24 hours.

---

#### Effect Types (Intent-Dependent)

**Healing Focus:** Accelerates natural regeneration, closes wounds, mends minor fractures.

**Energy Recovery:** Restores CEL reserves, soothes mental fatigue, sharpens reflexes.

**Balanced Mixture:** Splits potency 50/50 between healing and recovery.

---

#### Secondary Secretions: Sweat, Saliva, and Residual Fluids

| Fluid | Equivalent Grade | Effect | Typical Volume for Dose |
|-------|------------------|--------|------------------------|
| Sweat | F to D-rank | Mild stamina recovery, minor temperature regulation | 500ml (heavy exertion) |
| Saliva | F to D-rank | Temporary +5% to mental clarity, mild pain dulling | 50ml (prolonged kissing) |

All secondary secretions share the same pleasant taste adaptation and intent-locking mechanics as primary fluids.

---

#### Tertiary Secretions: Urine and Fecal Matter

| Substance | Equivalent Grade | Effect | Typical Volume for Dose |
|-----------|------------------|--------|------------------------|
| Urine | D to C-rank | Moderate energy restoration, accelerates minor injury healing | 300ml (single void) |
| Fecal matter | D to C-rank | Digestive fortification, toxin filtration, short-term endurance boost | 200g (single movement) |

**Production Note:** John's body routes excess CEL through waste pathways. A full day's combined urine and fecal output equals roughly 40% of his seminal fluid's total potency by volume. The intent-imprinting mechanism applies equally to all excretions.

---

#### Preservation Methods

| Method | Extended Timer | Notes |
|--------|----------------|-------|
| Body temperature storage | +30 minutes | Held against skin or inside body cavity |
| Insulated thermos | +2 hours | Pre-warmed container doubles efficiency |
| CEL-infused crystal container | +6 hours | Expensive; crystal costs 500 credits each |
| Refrigeration | +3 hours | Slows but doesn't stop degradation |
| Freezing | +8 hours | Thawing accelerates degradation—use immediately |
| Direct sunlight | -50% timer | UV accelerates CEL breakdown |
| Open air | -75% timer | Evaporation kills potency fast |

---

#### Limitations & Drawbacks

- **Production Cooldown:** Refractory period of 2 minutes minimum between "harvests." Repeated production within an hour yields diminishing CEL concentration (minus 15% per cycle).
- **Intent Lock:** Once imprinted, the effect cannot be changed. Poor visualization produces weaker or muddled results.
- **Personal Cost:** Each ejaculation consumes roughly 3% of John's daily CEL reserves. Voiding (urination/defecation) costs 1% per event. Heavy production leaves him drained and vulnerable.

---

**IIS Assistant Note:** *"Essence Alchemy turns John into a walking apothecary. Keep him fed, hydrated, and rested, and he can keep an entire squad operational. Just don't let him overproduce—a depleted John is a dead John. And yes, everything he produces tastes good. Don't ask me how. It just does."*

## User
Update vera's character sheet. She is the head gate guard of the southern side of sbf. Wheres a standard officer combat gear.

She has a large buttocks, feminine muscular orge race, light green skin, emerald pupils, long dark brown hair.

Battle axe beserker battle type.

Aggressive, military, formal.

## AI


## User
Update vera's character sheet. She is the head gate guard of the southern side of sbf. Wheres a standard officer combat gear.



She has a large buttocks, feminine muscular orge race, light green skin, emerald pupils, long dark brown hair.



Battle axe beserker battle type.



Aggressive, military, formal.

Orphane of a small random village in the sbf that was attacked and destroyed by a gkom monaters she hid from them while most of the villagers were killed.

## AI
### Codex Entry: Vera Ironbough

---

#### Basic Information

- **Name:** Vera Ironbough
- **Alias:** The Southern Gatekeeper, Emerald Berserker
- **Race:** Ogre (Forest Variant)
- **Age:** 32 (WAHB Prime Maturity)
- **Occupation:** Head Gate Guard – Southern Silverwood Forest Entrance
- **Class:** Berserker

---

#### Physical Attributes

- **Height:** 7'4" (224 cm)
- **Weight:** 280 lbs (127 kg) of dense, battle-hardened muscle
- **Skin:** Light green with faint darker mottling across shoulders and forearms
- **Eyes:** Emerald green pupils, sharp and discerning
- **Hair:** Long dark brown, worn in a tight combat braid reaching mid-back
- **Distinctive Features:** Two short tusks protruding from lower jaw; pronounced muscular definition across arms, shoulders, and thighs; massive, rounded buttocks that strain standard-issue trousers
- **WAHB Measurements:** 48-32-52 (Feminine muscular amazon build, bottom-heavy)

---

#### Equipment

- **Primary Weapon:** [Gatekeeper's Greataxe] – Double-bladed battle axe with reinforced CEL-steel head. Weighs 80 lbs. Extended haft for sweeping strikes.
- **Armor:** Standard Southern Gate Officer Combat Gear – Reinforced leather and steel pauldrons, chest plate, gauntlets, and greaves. Modified trousers reinforced at the seat and thighs for her proportions. Minimal helmet—prefers full visibility.
- **Utility:** Gate keys, signal whistle, emergency flare pouch, standard-issue canteen.

---

#### Combat Profile

- **Primary Weapon:** Greataxe (two-handed)
- **Secondary:** Bare fists (crushing grip strength)
- **Fighting Style:** [Emerald Fury] – Aggressive forward momentum. Closes distance with devastating charge attacks, then chains wide sweeping axe strikes. Eschews defense for overwhelming offense. Relies on ogre durability to absorb hits that land.

**Special Techniques:**

- **[Ground Splitter]:** Overhead axe slam—creates shockwave, staggers surrounding enemies.
- **[Rending Cyclone]:** 360-degree spinning cleave. Clears multiple targets, leaves Vera briefly winded.
- **[Gatecrasher]:** Shoulder-first charging rush. Uses body mass as weapon. Can knock reinforced doors off hinges.

---

#### Personality

- **Aggressive:** Meets problems head-on. No patience for subtlety or politics. If something needs doing, she does it—loudly.
- **Military:** Follows chain of command. Expects discipline from subordinates. Runs the South Gate like a garrison post, not a checkpoint.
- **Formal with Superiors, Blunt with Everyone Else:** Snaps crisp salutes to ranking officers. Tells civilians to "move or get moved."
- **Loyal:** Fiercely protective of those under her watch. Once you're in her unit, you're family.

---

#### Sexual Profile

- **Style:** Dominant Aggressor
- **Sexual Kinks:**
  1. **Physical Overwhelm:** Prefers partners she can physically dominate—pinning, lifting, holding down.
  2. **Battle Lust:** Aroused by combat and physical exertion. Post-fight adrenaline dumps translate directly to bedroom aggression.
  3. **Biting and Marking:** Leaves bruises and teeth marks. Claims ownership.
- **Favorite Positions:**
  1. **Full Mount:** Straddles partner, hips driving down with full body weight. Grinds until satisfied.
  2. **Against the Wall:** Presses partner against any vertical surface, thighs locked around their waist. Takes control of rhythm completely.

---

#### Background

- **Origin:** Born in a nameless village deep in Silverwood Forest. Population forty-seven—loggers, herbalists, a single blacksmith.
- **The Attack:** When Vera was sixteen, a GKOM monster pack overran the village at dusk. She wedged herself beneath a collapsed storage shed and stayed silent while the creatures slaughtered everyone she knew. By dawn, she was the sole survivor.
- **Rescue:** A Forest Ranger patrol found her three days later, dehydrated and clutching a woodcutting axe. She'd refused to leave the ruins.
- **Training:** Enlisted with the Rangers the day she turned eighteen. Channeled her rage into combat drills. Passed every physical examination through sheer fury. Her instructors noted "unorthodox enthusiasm" in her performance reviews.
- **Rise:** Promoted to South Gate Head Guard after single-handedly repelling a GKOM breach. Twelve variants dead in eight minutes. She earned a commendation and a new axe.
- **Current Role:** Oversees all southern traffic entering and exiting Silverwood Forest. Commands fifteen gate guards. Has not lost a single guard under her command.

---

#### RPG Attributes (Scale 1-10)

- **Strength:** 10 (Ogre physique + berserker conditioning)
- **Dexterity:** 5 (Adept with her axe, but agility sacrificed for power)
- **Constitution:** 9 (Takes hits that would cripple lesser fighters; keeps swinging)
- **Intelligence:** 5 (Street-smart, tactically sound, not book-learned)
- **Wisdom:** 4 (Impulsive. Her answer to most problems is "hit it harder")
- **Charm:** 6 (Commanding presence. Attractive despite—or because of—scarred knuckles and resting battle-face)

---

#### Key Relationships

- **Forest Rangers Guild:** Respected field asset. Senior officers value her reliability. Junior rangers fear her inspections.
- **Subordinates (South Gate Guards):** Loyal to a fault. They've seen her fight. They'd follow her into any breach.
- **GKOM Variants:** Hatred. Pure, undiluted. Every variant she kills is one less orphan-maker.

---

#### Vulnerabilities

- **Impulsive:** Charges before assessing. Can be baited into traps.
- **Rage Trance:** In prolonged combat, slips into a state where she stops hearing orders. Keeps fighting until all threats are eliminated—or she physically cannot move.
- **Survivor's Guilt:** The village massacre still haunts her. Nightmares. Three drinks minimum to sleep through the night.
- **Trust Issues:** Keeps people at arm's length emotionally. Losing everyone once was enough.

---

#### Quote

*"South Gate doesn't fall. Not on my watch. Not ever."*

---

#### Inventory

- Gatekeeper's Greataxe
- Standard Southern Gate Officer Combat Gear
- Signal whistle (silver, engraved with ranger insignia)
- Emergency flare pouch (5 flares)
- Standard-issue canteen (filled with black tea, cold)
- Whetstone (pocket-sized)
- Village remnant—a charred wooden bead on a leather cord, worn around left wrist

---

**Gate Log Note:** *"Captain Ironbough processed 347 travelers today. Zero incidents. Three merchants complained about her 'tone.' Merchants were reminded that the forest kills polite people."*

## User
Make a character sheet for her subordinate. She is on the smaller side contrasting vera at 6ft.

Nerdy type kind of chubby but clearly has large proportions.

Has no actual sexual experience with a male but has done extensive research.

Voyrism fetish.

Grew up in sbc normal everyday life. Wanted to join the military to 'toughen up' but realized early on ahe is more suited to admin work. And was stationed at as a guard admin. Worked her way up to vice captain of the second gate.

Learned/found out she has aptitude for magical attacks. Pick 2 elements. B-rank

## AI
### Codex Entry: Mira Thornwood

---

#### Basic Information

- **Name:** Mira Thornwood
- **Alias:** The Desk Berserker, South Gate's Little Scholar
- **Race:** Half-Elf (Forest Variant)
- **Age:** 26
- **Occupation:** Vice-Captain – Southern Silverwood Forest Gate
- **Class:** Arcane Artillery (B-Rank CEL-A)

---

#### Physical Attributes

- **Height:** 6'0" (183 cm)
- **Weight:** 195 lbs (88 kg) – soft, plush build
- **Skin:** Warm ivory with faint freckles across nose and shoulders
- **Eyes:** Round, hazel-green behind wire-rimmed spectacles
- **Hair:** Mouse-brown, shoulder-length, perpetually escaping a practical bun
- **Distinctive Features:** Soft double chin, full cheeks, thick thighs, broad hips, and a generous bust that strains uniform buttons. Glasses perpetually smudged. Ink stains on fingers.
- **WAHB Measurements:** 44-30-46 (Chubby pear-shaped build, heavy bottom and bust)

---

#### Equipment

- **Primary Weapon:** [Quartermaster's Ledger] – A reinforced oak clipboard with CEL-conductive silver inlay. Functions as a spell focus. The back plate stops blades.
- **Secondary:** Standard-issue short sword (mostly ornamental; she's terrible with it).
- **Armor:** Standard Southern Gate Officer Combat Gear – Altered at the seams by her own hand. Reinforced stitching at bust and hips. Elbow pads worn from desk-leaning.
- **Utility:** Three spare inkwells, enchanted quill (auto-dips), emergency signal scrolls, pocket almanac of GKOM variant weak points.

---

#### Combat Profile

- **Primary Style:** Ranged magical bombardment from behind cover
- **Secondary:** Bureaucratic obstruction (knows every regulation that can delay an enemy)
- **Fighting Style:** [Classroom Artillery] – Stands behind Vera and lobs elemental devastation over the Captain's shoulders. Mutters spell formulas like vocabulary drills. Gets flustered when spells work better than expected.

**CEL-A: [Elemental Academia]** – B-Rank

- **[Lightning Ledger]:** Arcs electricity through her enchanted clipboard. Chain-lightning that jumps between up to four targets. Leaves scorch marks on paperwork.
- **[Frost Filing]:** Conjures crystalline ice formations—walls, slicks, and caltrops. Accidentally froze the entire guardhouse tea kettle once. Twice.
- **[Flash Paper]:** Blinding burst of light. Uses it to escape conversations she doesn't want to have. Also effective against light-sensitive GKOM variants.
- **[Overdue Notice]:** Combined lightning-frost spear. Long cast time. Devastating impact. Only used when genuinely annoyed.

---

#### Personality

- **Nerdy:** Reads academic journals on variant biology for fun. Annotates field reports with citations. Gets excited about new research papers.
- **Book-Smart, Combat-Anxious:** Knows seventeen theoretical ways to kill a D-rank variant. Has personally killed three and wrote a dissertation on each.
- **Self-Deprecating:** Jokes about her weight, her desk job, her lack of field experience. Stops laughing if someone agrees.
- **Loyal to Vera:** The Captain saw potential in a chubby admin girl who flunked basic combat. Mira would walk into the forest with nothing but her ledger for Vera.
- **Easily Flustered:** Discussions of sexuality, romance, or her own body send her into rambling tangents about unrelated topics. Blushes to her ears.

---

#### Sexual Profile

- **Style:** Theoretical Expert, Practical Virgin
- **Experience with Males:** None. Zero. Extensive reading material.
- **Voyeurism Fetish:** Prefers watching to participating. Has accidentally witnessed three guardhouse trysts and took detailed mental notes. Keeps a private journal with observations about "mating behaviors." Would die of mortification if discovered.
- **Self-Pleasure:** Prolific. Approaches masturbation with academic rigor—experiments with rhythm, pressure, fantasy scenarios. Charts results. The charts are color-coded.
- **Secret Desires:** Wants to be overwhelmed by someone who knows what they're doing. Fantasizes about being pursued, pinned, and thoroughly educated. Would never admit this aloud.
- **Favorite Research Topics:** Positions requiring flexibility, oral techniques, stamina enhancement methods, anything involving size differences.

---

#### Background

- **Origin:** Born and raised in Silverbrook City's Scholar's Canopy District. Parents run a moderately successful bookstore specializing in magical theory. Only child.
- **Childhood:** Spent her youth reading adventure novels and dreaming of heroic quests. Built pillow forts and pretended to siege them with spells. Never actually left the city limits until she enlisted.
- **Enlistment:** Joined the Southern Gate Guard at age 22 to "toughen up" and "see the real world." Basic training lasted three weeks. She sprained an ankle, nearly set the barracks on fire, and accidentally cited labor regulations at her drill instructor.
- **Reassignment:** Command recognized her organizational skills. Transferred to administrative duties. Thrived.
- **Rise:** Streamlined the South Gate's entire filing system. Reduced supply waste by 40%. Implemented a rotation schedule that improved guard morale. Vera noticed.
- **Vice-Captain Promotion:** Vera needed someone to handle logistics so she could focus on hitting things. Mira was the obvious choice. She cried when Vera offered her the position.
- **Current Role:** Manages scheduling, inventory, incident reports, and inter-guild correspondence for the South Gate. Sits at a reinforced desk within earshot of Vera's axe swings. Provides ranged magical support when the gate is breached.

---

#### RPG Attributes (Scale 1-10)

- **Strength:** 3 (Barely passed physicals. Relies on telekinesis for heavy lifting)
- **Dexterity:** 4 (Trips over her own feet but has precise handwriting)
- **Constitution:** 5 (Soft body, decent stamina from running between filing rooms)
- **Intelligence:** 8 (Academic brilliance. Photographic memory for regulations and bestiary entries)
- **Wisdom:** 6 (Excellent logistical sense. Terrible personal judgment)
- **Charm:** 5 (Endearing in a bumbling way. Blushes easily. Gets tongue-tied around attractive people)

---

#### Key Relationships

- **Vera Ironbough:** Idolizes her Captain. Terrified of disappointing her. Writes Vera's field reports in heroic prose the Captain would never compose herself. Vera pretends not to notice.
- **South Gate Guards:** Protective of their Vice-Captain. Tease her mercilessly. Would murder anyone outside the unit who did the same.
- **Parents:** Exasperated but proud. Send care packages with new books and baked goods. Still hope she'll come home and work in the shop.
- **Scholarly Community:** Respected as a promising amateur variantologist. Published one paper on GKOM behavior patterns. Peer-reviewed by actual academics who didn't know she was a gate guard.

---

#### Vulnerabilities

- **Physical Cowardice:** Will absolutely run from direct combat. Vera covers her.
- **Overthinks Everything:** Can strategize for hours while a situation requires immediate action.
- **Crippling Self-Doubt:** Dismisses her own achievements. Assumes praise is politeness.
- **Magical Overextension:** B-Rank power with C-Rank stamina. Three big spells and she's useless.

---

#### Quote

*"I've read seventy-four papers on proper gate defense doctrine. The Captain's approach—'hit it with an axe until it stops moving'—is not among them. It does, however, appear to work."*

---

#### Inventory

- Quartermaster's Ledger (enchanted spell focus)
- Standard Southern Gate Officer Combat Gear (altered)
- Wire-rimmed spectacles (spare pair in desk drawer)
- Three inkwells (black, red for corrections, silver for magical notation)
- Enchanted quill (auto-dips, never runs dry)
- Emergency signal scrolls (5)
- Pocket almanac of GKOM variant weak points (annotated, dog-eared)
- Personal journal (hidden compartment in desk, contains observation notes)
- Snacks (dried fruit, oat cakes, emergency chocolate)
- Romance novel (currently reading, hidden inside a book on tax law)

---

**Gate Log Note:** *"Vice-Captain Thornwood successfully reorganized our requisition forms and electrocuted a D-rank variant today. The requisition forms were the greater challenge. She's an inspiration."* — Guard-Sergeant Kelva

## User
Differnt name

## AI


## User
Differnt name 750 words max

## AI
### Codex Entry: Elara Vellum

---

#### Basic Information

- **Name:** Elara Vellum
- **Alias:** The Desk Berserker, South Gate's Little Scholar
- **Race:** Half-Elf (Forest Variant)
- **Age:** 26
- **Occupation:** Vice-Captain – Southern Silverwood Forest Gate
- **Class:** Arcane Artillery (B-Rank CEL-A)

---

#### Physical Attributes

- **Height:** 6'0" (183 cm) – notably small beside Vera's 7'4"
- **Weight:** 195 lbs (88 kg) – soft, plush build
- **Skin:** Warm ivory with faint freckles
- **Eyes:** Round, hazel-green behind wire-rimmed spectacles
- **Hair:** Mouse-brown, shoulder-length, perpetually escaping a bun
- **Distinctive Features:** Full cheeks, thick thighs, broad hips, generous bust straining uniform buttons. Ink-stained fingers, perpetually smudged glasses.
- **WAHB Measurements:** 44-30-46 (Chubby pear shape, bottom-heavy)

---

#### Equipment

- **Primary Weapon:** [Quartermaster's Ledger] – Reinforced oak clipboard with CEL-conductive silver inlay. Functions as spell focus and emergency shield.
- **Secondary:** Standard-issue short sword (purely ornamental; she's hopeless with it).
- **Armor:** Standard Southern Gate Officer Combat Gear, altered by her own hand to accommodate her proportions. Elbow pads worn from desk-leaning.
- **Utility:** Three spare inkwells, enchanted quill, emergency signal scrolls, pocket almanac of variant weak points.

---

#### Combat Profile

- **Fighting Style:** [Classroom Artillery] – She stands behind Vera and lobs elemental devastation over the Captain's shoulders, muttering spell formulas like vocabulary drills.

**CEL-A: [Elemental Academia]** – B-Rank

- **[Lightning Ledger]:** Chain-lightning from her clipboard, jumping up to four targets. Scorches paperwork.
- **[Frost Filing]:** Conjures ice walls, slicks, and caltrops. Once froze the guardhouse kettle—twice.
- **[Flash Paper]:** Blinding light burst. Used for tactical retreats and escaping unwanted conversations.
- **[Overdue Notice]:** Combined lightning-frost spear. Long cast time, devastating impact. Only used when genuinely annoyed.

---

#### Personality

- **Nerdy:** Reads academic journals on variant biology for fun. Annotates field reports with citations. Gets excited about new research.
- **Book-Smart, Combat-Anxious:** Knows seventeen theoretical ways to kill a D-rank variant. Has personally killed three and wrote a dissertation on each.
- **Self-Deprecating:** Jokes about her weight, desk job, lack of field experience. Stops laughing if someone agrees.
- **Loyal to Vera:** The Captain saw potential in a chubby admin girl who flunked basic combat. Elara would follow her into the forest with nothing but her ledger.
- **Easily Flustered:** Discussions of romance or her own body send her into rambling tangents about unrelated topics. Blushes to her ears.

---

#### Sexual Profile

- **Experience with Males:** None. Zero. Extensive research only.
- **Voyeurism Fetish:** Prefers watching to participating. Has accidentally witnessed three guardhouse trysts and taken detailed mental notes. Keeps a private, color-coded journal of observations. Would die if discovered.
- **Secret Desires:** Fantasizes about being pursued, pinned, and thoroughly educated by someone experienced. Would never admit this aloud.

---

#### Background

- **Origin:** Born and raised in Silverbrook City's Scholar's Canopy District. Parents run a bookstore specializing in magical theory.
- **Enlistment:** Joined the gate guard at 22 to "toughen up." Basic training lasted three weeks—she sprained an ankle, nearly set the barracks on fire, and accidentally cited labor regulations at her drill instructor. Reassigned to admin.
- **Rise:** Streamlined the South Gate's entire filing system, reduced supply waste by 40%, implemented a rotation schedule that improved morale. Vera noticed and promoted her.
- **Current Role:** Manages scheduling, inventory, incident reports. Provides ranged magical support when the gate is breached, usually from behind Vera.

---

#### RPG Attributes (Scale 1-10)

- **Strength:** 3 (Barely passed physicals)
- **Dexterity:** 4 (Trips over her own feet; precise handwriting)
- **Constitution:** 5 (Soft body, decent stamina from desk-to-filing-room sprints)
- **Intelligence:** 8 (Photographic memory for regulations and bestiary entries)
- **Wisdom:** 6 (Excellent logistical sense, terrible personal judgment)
- **Charm:** 5 (Endearing, bumbling, blushes easily)

---

#### Key Relationships

- **Vera Ironbough:** Idolizes her Captain. Terrified of disappointing her. Writes Vera's field reports in heroic prose the Captain would never compose herself.
- **South Gate Guards:** Protective of their Vice-Captain. Tease her mercilessly; would murder anyone outside the unit who did the same.
- **Parents:** Exasperated but proud. Send care packages with new books and baked goods.

---

#### Vulnerabilities

- **Physical Cowardice:** Runs from direct combat. Vera covers her.
- **Overthinks Everything:** Strategizes for hours while situation requires immediate action.
- **Magical Overextension:** B-Rank power, C-Rank stamina. Three big spells and she's useless.

---

#### Quote

*"I've read seventy-four papers on proper gate defense doctrine. The Captain's approach—'hit it with an axe until it stops moving'—is not among them. It does, however, appear to work."*

---

#### Inventory

- Quartermaster's Ledger (enchanted spell focus)
- Standard Southern Gate Officer Combat Gear (altered)
- Wire-rimmed spectacles (spare pair in desk drawer)
- Three inkwells (black, red, silver)
- Enchanted quill
- Emergency signal scrolls
- Pocket almanac of variant weak points (annotated, dog-eared)
- Personal journal (hidden compartment, observation notes)
- Snacks (dried fruit, emergency chocolate)
- Romance novel hidden inside a book on tax law

---

**Gate Log Note:** *"Vice-Captain Vellum successfully reorganized our requisition forms and electrocuted a D-rank variant today. The requisition forms were the greater challenge. She's an inspiration."* — Guard-Sergeant Kelva

## User
Guild master of sbc ag codex

Tall woman tough beautiful woman with an eye patch on her left eye. long Cyan hair, ponytail. Beastwoman(dont pick a fox or a wolf something exotic)

Wahb muscle but not overly muscularly. More feminine than muscular type.

Large proportions, wears a crop top battle version, hot shorts with a thick belt, wail tail type of underwear, low profile shoes.

Martial artist expert, s-rank. inner Ki control and can control cel in the air.

Loud, hearty, tomboy boistries, jubilent, loyal, heart on the sleeve, type.

Being a guild master she Has had sex with a man has also had two children both are female.

Sex prefrence exhibitionism, dominated in a bought.

## AI
### Codex Entry: Kaela Stormfang

---

#### Basic Information

- **Name:** Kaela Stormfang
- **Alias:** The One-Eyed Tempest, Guild Mother
- **Race:** Beastwoman (Snow Leopard Variant)
- **Age:** 48 (WAHB Prime, two centuries of vitality remaining)
- **Occupation:** Guild Master – Silverbrook Adventure Guild
- **Class:** Martial Arts Grandmaster (S-Rank CEL-A)

---

#### Physical Attributes

- **Height:** 7'2" (218 cm)
- **Weight:** 245 lbs (111 kg) – lithe, powerful, feminine
- **Skin:** Fair with faint silver rosette markings tracing shoulders, outer thighs, and lower back
- **Eyes:** Single right eye, amber-gold with slit pupil. Left eye covered by a black leather patch.
- **Hair:** Long cyan, worn in a high ponytail that falls past her hips. Two smaller strands frame her angular face.
- **Distinctive Features:** Leopard ears twitching atop her head; long, thick tail matching her hair color; fanged smile; rosette fur patches at wrists and ankles. The eyepatch hides a scarred socket—she never speaks of it.
- **WAHB Measurements:** 46-28-50 (Amazonian hourglass, broad shoulders tapering to narrow waist, powerful hips and thighs)

---

#### Equipment

- **Attire:** White crop top ending above her navel, reinforced with CEL-thread stitching. Black hot shorts with a thick brown leather belt bearing the guild crest. A whale-tail style undergarment peeks above the belt line. Low-profile leather wraps on feet for silent movement despite her size.
- **Weapons:** None. Her body is the weapon.
- **Accessories:** Guild Master's pendant (CEL-keyed to all guild wards), leather bracelet woven from her daughters' baby hair, silver hoop earrings (three in right ear).

---

#### Combat Profile

- **Fighting Style:** [Celestial Fist] – Inner Ki manipulation combined with external CEL control. She strikes with precision, not fury. Each blow channels ambient CEL through her limbs, creating shockwaves on impact. Movement is fluid, almost dance-like, her tail counterbalancing impossible acrobatics.

**CEL-A: [Storm's Embrace]** – S-Rank

- **[Hollow Bones Breathing]:** Passive. Her Ki circulates continuously, drawing ambient CEL into her core. Grants perpetual heightened reflexes, minor regeneration, and environmental awareness within 50 meters. Her ears twitch before danger arrives.
- **[Palm of the Tempest]:** Open-palm strike that releases compressed CEL as concussive force. Can shatter reinforced steel. Non-lethal variants merely send opponents flying.
- **[Cyclone Sweep]:** Spinning low kick that generates a localized tornado. Used for crowd control or creating distance. Once cleared the guild hall's main floor of thirty brawlers in four seconds.
- **[Eye of the Storm]:** Meditation technique. Slows perception of time to a crawl. Heart rate drops to three beats per minute. She analyzes threats, predicts movements, then strikes when ready. Activated while standing perfectly still.
- **[Heaven's Fist]:** Signature technique. Leaping overhead strike that condenses all surrounding CEL into a single downward blow. Leaves a crater. She used it once during her S-Rank certification. The testing chamber required full reconstruction.
- **[Sky Father's Rebuke]:** Ultimate technique. Channeled over ten seconds. A continuous barrage of CEL-infused strikes at supersonic speed. Exhausts her completely. Never used outside life-or-death scenarios.

---

#### Personality

- **Loud:** Her laughter echoes through the guild hall. She announces her presence before entering rooms. Small talk booms. Secrets are foreign to her.
- **Hearty:** Greets everyone like an old friend. Slaps backs hard enough to stagger. Buys rounds for the entire tavern when celebrating. Cries openly at weddings, funerals, and particularly moving quest completions.
- **Tomboy Boisterous:** Fights, drinks, and carouses with the rowdiest adventurers. Tells filthy jokes. Arm-wrestles challengers. Farts without apology.
- **Jubilant:** Finds joy in everything—a sunny morning, a well-cooked meal, a rookie's first successful quest. Radiates infectious positivity. The guild's morale is directly proportional to her proximity.
- **Loyal:** Her people come first. Always. She remembers every guild member's name, their families, their dreams. Would wage war on any kingdom that threatened them.
- **Heart on Her Sleeve:** Emotions broadcast through her ears and tail. Anger flattens ears and lashes tail. Joy makes ears swivel and tail curl. Sadness droops both. She cannot bluff at cards. Everyone still lets her play.

---

#### Sexual Profile

- **Experience:** Extensive. Married once (widowed). Two children. Several lovers since.
- **Exhibitionism:** Thrives on being watched. Has taken lovers in the guild hall's upper balcony while celebrations raged below. The risk of discovery heightens her pleasure. Her tail gives away her arousal every time.
- **Preference for Being Dominated:** A switch at heart, but craves partners who can match her physically and overpower her. The rare individual who pins her earns her undying affection. She wants to lose—needs to lose—to someone strong enough to make her submit.
- **Physicality:** Bites, scratches, wrestles. Sex is a full-contact sport. Partners should expect bruises.
- **Kinks:** Collars, leashes, being mounted from behind while her tail is held, public risk, size difference (she's fascinated by smaller partners who can still dominate her).

---

#### Background

- **Origin:** Born to a snow leopard pride in the Moonstone Hills. Third daughter of the chieftain. Expected to be a diplomat. She broke the expectations along with three training dummies before her tenth birthday.
- **Training:** Studied under an ancient martial arts master who lived as a hermit in the Silverwood Forest. He taught her Ki control. She surpassed him at age 22.
- **Rise:** Joined the Silverbrook Adventure Guild as a D-Rank brawler. Earned S-Rank status within eight years through relentless questing, impossible feats, and a refusal to stay down. Elected Guild Master by unanimous vote at 35.
- **Family:** Married a human adventurer named Doran. He died during a GKOM breach twelve years ago. She wears the eyepatch because of that same battle—she lost the eye protecting their unborn second daughter. Never sought healing. Calls it "the cost of love."
- **Children:** Two daughters. Senna (19), took after her father—studying to be a guild clerk. Rielle (12), took after her mother—already throwing punches at training dummies. Both live in the guild quarters.
- **Current Role:** Oversees all guild operations. Personally evaluates B-Rank to A-Rank promotions. Still takes field assignments when the threat demands S-Rank power. Has not lost a guild member under her command in five years.

---

#### RPG Attributes (Scale 1-10 / S-Rank)

- **Strength:** 9 (Punches through walls. Restrains herself constantly.)
- **Dexterity:** 10 (Leopard agility. Moves like silk in wind.)
- **Constitution:** 8 (Takes hits. L

## User
750 words max Guild master of sbc ag character sheet codex.

Tall woman tough beautiful woman with an eye patch on her left eye. long Cyan hair, ponytail. Beastwoman(dont pick a fox or a wolf something exotic)

Wahb muscle but not overly muscularly. More feminine than muscular type.

Large proportions, wears a crop top battle version, hot shorts with a thick belt, wail tail type of underwear, low profile shoes.

Martial artist expert, s-rank. inner Ki control and can control cel in the air.

Loud, hearty, tomboy boistries, jubilent, loyal, heart on the sleeve, type.

Being a guild master she Has had the opportunity to have sex with one male. Also lucky enough to have been incomated on her first of few times having twins both are female. Been decades since last sexual encounter with a male.

Sex prefrence exhibitionism, dominated in a bought.

## AI
### Codex Entry: Kaela Stormfang

---

#### Basic Information

- **Name:** Kaela Stormfang
- **Alias:** The One-Eyed Tempest, Guild Mother
- **Race:** Beastwoman (Snow Leopard Variant)
- **Age:** 48 (WAHB Prime, two centuries of vitality remaining)
- **Occupation:** Guild Master – Silverbrook Adventure Guild
- **Class:** Martial Arts Grandmaster (S-Rank CEL-A)

---

#### Physical Attributes

- **Height:** 7'2" (218 cm)
- **Weight:** 245 lbs (111 kg) – lithe, powerful, feminine
- **Skin:** Fair with faint silver rosette markings tracing shoulders, outer thighs, and lower back
- **Eyes:** Single right eye, amber-gold with slit pupil. Left eye covered by black leather patch.
- **Hair:** Long cyan, high ponytail falling past her hips. Two strands frame her angular face.
- **Distinctive Features:** Leopard ears twitching atop her head; long, thick tail matching her hair; fanged smile; rosette fur patches at wrists and ankles. The eyepatch hides a scarred socket from a GKOM beast's claw.
- **WAHB Measurements:** 46-28-50 (Amazonian hourglass, broad shoulders, narrow waist, powerful hips)

---

#### Attire

White crop top ending above her navel, reinforced with CEL-thread stitching. Black hot shorts with a thick brown leather belt bearing the guild crest. A whale-tail undergarment peeks above the belt line. Low-profile leather foot wraps. Guild Master's pendant rests between her collarbones.

---

#### Combat Profile

- **Fighting Style:** [Celestial Fist] – Inner Ki manipulation combined with external CEL control. Strikes channel ambient CEL through her limbs, creating shockwaves. Movement is fluid, dance-like, her tail counterbalancing impossible acrobatics.

**CEL-A: [Storm's Embrace]** – S-Rank

- **[Hollow Bones Breathing]:** Passive Ki circulation draws ambient CEL into her core. Perpetual heightened reflexes, minor regeneration, environmental awareness within 50 meters. Her ears twitch before danger arrives.
- **[Palm of the Tempest]:** Open-palm strike releasing compressed CEL as concussive force. Shatters reinforced steel. Non-lethal variant sends opponents flying.
- **[Cyclone Sweep]:** Spinning low kick generating a localized tornado. Once cleared the guild hall of thirty brawlers in four seconds.
- **[Eye of the Storm]:** Meditation technique. Slows time perception. Heart rate drops to three beats per minute. Analyzes threats, predicts movements, then strikes.
- **[Heaven's Fist]:** Leaping overhead strike condensing all surrounding CEL into a single downward blow. Leaves a crater. The testing chamber required full reconstruction.
- **[Sky Father's Rebuke]:** Ultimate technique. Ten-second channel. Continuous barrage of CEL-infused strikes at supersonic speed. Exhausts her completely. Reserved for life-or-death scenarios.

---

#### Personality

- **Loud:** Her laughter echoes through the guild hall. Announces her presence before entering rooms. Slaps backs hard enough to stagger. Buys rounds for the entire tavern.
- **Hearty:** Greets everyone like an old friend. Cries openly at weddings, funerals, and rookie promotions. Farts without apology.
- **Tomboy Boisterous:** Fights, drinks, and carouses with the rowdiest adventurers. Tells filthy jokes. Arm-wrestles challengers.
- **Jubilant:** Finds joy in everything. Radiates infectious positivity. Guild morale is directly proportional to her proximity.
- **Loyal:** Remembers every guild member's name, their families, their dreams. Would wage war on any kingdom that threatened them.
- **Heart on Sleeve:** Emotions broadcast through ears and tail. Anger flattens ears, lashes tail. Joy makes ears swivel, tail curl. She cannot bluff at cards. Everyone still lets her play.

---

#### Sexual Profile

- **Experience:** One male partner, decades ago. A rare encounter that gifted her twin daughters. She remembers it vividly—the feel of being pinned, dominated, filled. No male since. The memory sustains her.
- **Exhibitionism:** Thrives on being watched. Risk of discovery heightens her pleasure. Her tail gives away her arousal every time.
- **Craves Being Dominated:** The one partner who overpowered her earned her heart. She wants to lose—needs to lose—to someone strong enough to make her submit.
- **Physicality:** Bites, scratches, wrestles. Sex is a full-contact sport. Partners should expect bruises.
- **Kinks:** Collars, leashes, being mounted from behind while her tail is held, public risk, being conquered by someone who bests her in combat first.

---

#### Background

- **Origin:** Born to a snow leopard pride in the Moonstone Hills. Third daughter of the chieftain. Broke expectations and training dummies alike before her tenth birthday.
- **Training:** Studied under an ancient hermit master in Silverwood Forest. Surpassed him at 22.
- **Rise:** Joined the guild as D-Rank brawler. Earned S-Rank in eight years. Elected Guild Master by unanimous vote at 35.
- **The Eyepatch:** Lost her eye to a GKOM alpha beast twelve years ago. Killed it bare-handed immediately after. Refused magical replacement. Calls it "a fair trade."
- **Children:** Twin daughters from her sole male encounter. Senna and Rielle (12), both snow leopard beastwomen. They live in the guild quarters. Senna favors books; Rielle favors her fists.
- **Current Role:** Oversees all guild operations. Personally evaluates B-Rank to A-Rank promotions. Takes field assignments when threats demand S-Rank power. Five years without losing a single guild member under her command.

---

#### RPG Attributes (Scale 1-10)

- **Strength:** 9 (Punches through walls. Restrains herself constantly.)
- **Dexterity:** 10 (Leopard agility. Moves like silk in wind.)
- **Constitution:** 8 (Takes hits that would fell lesser warriors.)
- **Intelligence:** 6 (Tactical genius in combat. Average at paperwork. Delegates.)
- **Wisdom:** 7 (Reads people instantly. Trusts her gut.)
- **Charm:** 9 (Magnetic. Her laughter could rally armies.)

---

#### Quote

*"The guild isn't a building. It's the people in it. You bleed for them, they bleed for you. That's the only rule that matters."*

---

#### Inventory

- Guild Master's pendant (CEL-keyed to all guild wards)
- Leather bracelet woven from her daughters' baby fur
- Three silver hoop earrings (right ear)
- Hip flask (aged whiskey, shared freely)
- Spare eyepatch (black leather, kept in belt pouch)

## User
She wasnt sexually pleased not dominated, she was elected a male because of her being a guild master.

## AI
### Codex Entry: Kaela Stormfang

---

#### Basic Information

- **Name:** Kaela Stormfang
- **Alias:** The One-Eyed Tempest, Guild Mother
- **Race:** Beastwoman (Snow Leopard Variant)
- **Age:** 48 (WAHB Prime, two centuries of vitality remaining)
- **Occupation:** Guild Master – Silverbrook Adventure Guild
- **Class:** Martial Arts Grandmaster (S-Rank CEL-A)

---

#### Physical Attributes

- **Height:** 7'2" (218 cm)
- **Weight:** 245 lbs (111 kg) – lithe, powerful, feminine
- **Skin:** Fair with faint silver rosette markings tracing shoulders, outer thighs, and lower back
- **Eyes:** Single right eye, amber-gold with slit pupil. Left eye covered by black leather patch.
- **Hair:** Long cyan, high ponytail falling past her hips. Two strands frame her angular face.
- **Distinctive Features:** Leopard ears twitching atop her head; long, thick tail matching her hair; fanged smile; rosette fur patches at wrists and ankles. The eyepatch hides a scarred socket from a GKOM beast's claw.
- **WAHB Measurements:** 46-28-50 (Amazonian hourglass, broad shoulders, narrow waist, powerful hips)

---

#### Attire

White crop top ending above her navel, reinforced with CEL-thread stitching. Black hot shorts with a thick brown leather belt bearing the guild crest. A whale-tail undergarment peeks above the belt line. Low-profile leather foot wraps. Guild Master's pendant rests between her collarbones.

---

#### Combat Profile

- **Fighting Style:** [Celestial Fist] – Inner Ki manipulation combined with external CEL control. Strikes channel ambient CEL through her limbs, creating shockwaves. Movement is fluid, dance-like, her tail counterbalancing impossible acrobatics.

**CEL-A: [Storm's Embrace]** – S-Rank

- **[Hollow Bones Breathing]:** Passive Ki circulation draws ambient CEL into her core. Perpetual heightened reflexes, minor regeneration, environmental awareness within 50 meters. Her ears twitch before danger arrives.
- **[Palm of the Tempest]:** Open-palm strike releasing compressed CEL as concussive force. Shatters reinforced steel. Non-lethal variant sends opponents flying.
- **[Cyclone Sweep]:** Spinning low kick generating a localized tornado. Once cleared the guild hall of thirty brawlers in four seconds.
- **[Eye of the Storm]:** Meditation technique. Slows time perception. Heart rate drops to three beats per minute. Analyzes threats, predicts movements, then strikes.
- **[Heaven's Fist]:** Leaping overhead strike condensing all surrounding CEL into a single downward blow. Leaves a crater.
- **[Sky Father's Rebuke]:** Ultimate technique. Ten-second channel. Continuous barrage of supersonic CEL-infused strikes. Exhausts her completely. Reserved for life-or-death scenarios.

---

#### Personality

- **Loud:** Her laughter echoes through the guild hall. Announces her presence before entering rooms. Slaps backs hard enough to stagger. Buys rounds for the entire tavern.
- **Hearty:** Greets everyone like an old friend. Cries openly at weddings, funerals, and rookie promotions. Farts without apology.
- **Tomboy Boisterous:** Fights, drinks, and carouses with the rowdiest adventurers. Tells filthy jokes. Arm-wrestles challengers.
- **Jubilant:** Finds joy in everything. Radiates infectious positivity. Guild morale is directly proportional to her proximity.
- **Loyal:** Remembers every guild member's name, their families, their dreams. Would wage war on any kingdom that threatened them.
- **Heart on Sleeve:** Emotions broadcast through ears and tail. Anger flattens ears, lashes tail. Joy makes ears swivel, tail curl. She cannot bluff at cards. Everyone still lets her play.

---

#### Sexual Profile

- **Experience:** One male partner, decades ago. Assigned to her by guild charter—a privilege of her rank as Guild Master. Clinical. Efficient. She fulfilled the obligation and conceived twins from that single encounter. No male since. No longing for one either. The arrangement left her cold.
- **Exhibitionism:** Thrives on being watched. Finds genuine heat in public risk, in being seen. Her tail gives away her arousal every time.
- **Craves Being Dominated:** The one thing her Guild Master privilege never granted her. No one dares pin a legend. She dreams of being bested in combat, then taken as a prize. To lose. To submit. To be conquered by someone strong enough to make her yield. Her rank makes this an impossible fantasy.
- **Physicality:** Bites, scratches, wrestles. Sex is a full-contact sport. Partners should expect bruises.
- **Kinks:** Collars, leashes, being mounted from behind while her tail is held, public risk, being claimed by someone who defeats her in combat first.

---

#### Background

- **Origin:** Born to a snow leopard pride in the Moonstone Hills. Third daughter of the chieftain. Broke expectations and training dummies alike before her tenth birthday.
- **Training:** Studied under an ancient hermit master in Silverwood Forest. Surpassed him at 22.
- **Rise:** Joined the guild as D-Rank brawler. Earned S-Rank in eight years. Elected Guild Master by unanimous vote at 35.
- **The Eyepatch:** Lost her eye to a GKOM alpha beast twelve years ago. Killed it bare-handed immediately after. Refused magical replacement. Calls it "a fair trade."
- **The Encounter:** Guild Master privileges granted her one sanctioned male partner for reproductive purposes. She selected a human man whose records were sealed afterward. The coupling was duty, not passion. She conceived twins. She has never spoken of it and discourages questions.
- **Children:** Twin daughters, Senna and Rielle (12), both snow leopard beastwomen. They live in the guild quarters. Senna favors books; Rielle favors her fists.
- **Current Role:** Oversees all guild operations. Personally evaluates B-Rank to A-Rank promotions. Takes field assignments when threats demand S-Rank power. Five years without losing a single guild member under her command.

---

#### RPG Attributes (Scale 1-10)

- **Strength:** 9 (Punches through walls. Restrains herself constantly.)
- **Dexterity:** 10 (Leopard agility. Moves like silk in wind.)
- **Constitution:** 8 (Takes hits that would fell lesser warriors.)
- **Intelligence:** 6 (Tactical genius in combat. Average at paperwork. Delegates.)
- **Wisdom:** 7 (Reads people instantly. Trusts her gut.)
- **Charm:** 9 (Magnetic. Her laughter could rally armies.)

---

#### Quote

*"The guild isn't a building. It's the people in it. You bleed for them, they bleed for you. That's the only rule that matters."*

---

#### Inventory

- Guild Master's pendant (CEL-keyed to all guild wards)
- Leather bracelet woven from her daughters' baby fur
- Three silver hoop earrings (right ear)
- Hip flask (aged whiskey, shared freely)
- Spare eyepatch (black leather, kept in belt pouch)

## User
Make Kaela 75 years old, the daughters in their 20s.

She lost her eye in a fight to a SS-rank beast as a sign of bravery protecting her unit from its wrath. She was given a ss-rank beast eye but its hard to control so she wears an eye patch.

## AI
### Codex Entry: Kaela Stormfang

---

#### Basic Information

- **Name:** Kaela Stormfang
- **Alias:** The One-Eyed Tempest, Guild Mother
- **Race:** Beastwoman (Snow Leopard Variant)
- **Age:** 75 (WAHB Prime, 200+ years of vitality remaining)
- **Occupation:** Guild Master – Silverbrook Adventure Guild
- **Class:** Martial Arts Grandmaster (S-Rank CEL-A)

---

#### Physical Attributes

- **Height:** 7'2" (218 cm)
- **Weight:** 245 lbs (111 kg) – lithe, powerful, feminine
- **Skin:** Fair with faint silver rosette markings tracing shoulders, outer thighs, and lower back
- **Eyes:** Right eye amber-gold with slit pupil. Left eye hidden beneath a black leather patch – beneath it lies the grafted eye of an SS-rank beast, a baleful vertical slit that glows with untamed CEL.
- **Hair:** Long cyan, high ponytail falling past her hips. Two strands frame her angular face.
- **Distinctive Features:** Leopard ears, thick matching tail, fanged smile; rosette fur at wrists and ankles. The eyepatch covers a chaotic organ she struggles to control.
- **WAHB Measurements:** 46-28-50 (Amazonian hourglass)

---

#### Attire

White crop top ending above her navel, reinforced with CEL-thread stitching. Black hot shorts with a thick brown leather belt bearing the guild crest. A whale-tail undergarment peeks above the belt line. Low-profile leather foot wraps. Guild Master's pendant rests between her collarbones.

---

#### Combat Profile

- **Fighting Style:** [Celestial Fist] – Inner Ki circulates CEL through her limbs, producing shockwaves on impact. Movement is fluid, dance-like; her tail counterbalances impossible acrobatics.

**CEL-A: [Storm's Embrace]** – S-Rank

- **[Hollow Bones Breathing]:** Passive Ki draws ambient CEL, granting perpetual heightened reflexes and minor regeneration. Her ears twitch before danger strikes.
- **[Palm of the Tempest]:** Open-palm strike releases compressed CEL as concussive force. Non-lethal variant sends opponents flying.
- **[Cyclone Sweep]:** Spinning low kick generates a localized tornado. Once cleared the guild hall of thirty brawlers in four seconds.
- **[Eye of the Storm]:** Meditation slows time perception; heart rate drops to three beats per minute while she analyzes threats.
- **[Heaven's Fist]:** Leaping overhead strike condensing all surrounding CEL into a single downward blow. Leaves a crater.
- **[Sky Father's Rebuke]:** Ultimate ten-second channel: a supersonic barrage of CEL strikes. Exhausts her completely.

---

#### Personality

- **Loud:** Her laughter booms through the guild. She slaps backs hard enough to stagger, buys rounds for everyone.
- **Hearty:** Welcomes all as old friends. Cries openly at weddings, funerals, and rookie promotions. Farts without apology.
- **Tomboy Boisterous:** Fights, drinks, and carouses with the rowdiest. Tells filthy jokes, arm-wrestles challengers.
- **Jubilant:** Infectiously positive. Guild morale is directly tied to her presence.
- **Loyal:** Remembers every member’s name, their families, their dreams. Would wage war for any of them.
- **Heart on Sleeve:** Ears and tail broadcast her emotions; she cannot bluff at cards. Still invited to every game.

---

#### Sexual Profile

- **Experience:** One male partner decades ago, a cold sanctioned duty as Guild Master’s privilege at age 53. Conceived twin daughters from that single encounter. No interest in repeating it.
- **Exhibitionism:** Thrives on being watched; risk of discovery ignites genuine heat. Her tail betrays arousal immediately.
- **Craves Being Dominated:** For all her fame, no one dares pin a legend. She dreams of being bested in combat, then taken as a prize. To lose. To submit. An impossible fantasy.
- **Physicality:** Bites, scratches, wrestles. Sex is full-contact; partners must expect bruises.
- **Kinks:** Collars, leashes, being mounted from behind while her tail is held, public risk, being conquered by a foe who defeats her first.

---

#### Background

- **Origin:** Born to a snow leopard pride in the Moonstone Hills. Third daughter of the chieftain; shattered expectations and training dummies alike before age ten.
- **Training:** Studied under an ancient hermit master in Silverwood Forest. Surpassed him at 22.
- **Rise:** Joined the guild as a D-Rank brawler. Earned S-Rank in eight years. Elected Guild Master by unanimous vote at 35.
- **The Eye:** At 55, an SS-rank GKOM horror assaulted the guild hall. Kaela led the defense, sacrificing her left eye to land the killing blow. The guild’s finest healers and alchemists transplanted the creature’s eye into her socket as a badge of honor. The eye pulses with corrupted CEL, granting fleeting visions of savage might if uncovered. She keeps it patched, both to control its wild energy and to hide its unsettling glow.
- **Children:** Twin daughters Senna and Rielle (now 22) from the sanctioned encounter. Both snow leopard beastwomen live in guild quarters. Senna buries herself in books; Rielle buries her fists in training dummies.
- **Current Role:** Forty years as Guild Master. Personally oversees all critical promotions. Still takes the field when threats demand S-Rank power. Not a single guild member lost under her command in over a decade.

---

#### RPG Attributes (Scale 1-10)

- **Strength:** 9 (Punches through walls. Restrains herself constantly.)
- **Dexterity:** 10 (Leopard agility. Moves like silk in wind.)
- **Constitution:** 8 (Shrugs off blows that would fell lesser warriors.)
- **Intelligence:** 6 (Tactical genius in battle; delegates paperwork.)
- **Wisdom:** 7 (Reads people instantly. Trusts her gut.)
- **Charm:** 9 (Magnetic. Her laughter could rally armies.)

---

#### Quote

*"The guild isn’t a building. It’s the people in it. You bleed for them, they bleed for you. That’s the only rule that matters."*

---

#### Inventory

- Guild Master’s pendant (CEL-keyed to all guild wards)
- Leather bracelet woven from her daughters’ baby fur
- Three silver hoop earrings (right ear)
- Hip flask (aged whiskey, shared freely)
- Spare eyepatch (black leather, kept in belt pouch)

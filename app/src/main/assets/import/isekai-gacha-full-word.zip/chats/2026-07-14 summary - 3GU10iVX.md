---
title: Summary
favourite: false
---
## User
Provide a scene susummary 50-100 words

## AI
# Chapter 7 - Scene 2 Summary

John collapses into unconsciousness after the day's events, and Elowen carries him through Silverbrook's quiet streets with Kaela at her side. An unseen AFM detail shadows them from rooftops. The two women share candid admissions about John's intensity before Kaela kisses his cheek, says goodbye, and turns back toward the guild. Elo carries him to the Frosted Mug, where Helda nods toward the stairs.

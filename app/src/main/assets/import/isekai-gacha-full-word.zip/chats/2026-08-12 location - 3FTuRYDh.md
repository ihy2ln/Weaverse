---
title: Location
favourite: false
---
## User
Create a location codex for the sbf adventure guild

Add missing details to add flavor and texture to the building

The theme is a high level major city adventure guild. Theme is high grade old sbf wood and light themed marble/cel like stone, glass like windows and ceilings. 3 floors and a basement.

3rd floor is reserved for the highest rank adventures and guild master, vice guild master, important meetings

2nd floor is for resting, medium rank guilds, and meetings.

Ground floor is for reception, all ranks, quest info, eatery, guild stores,

Basment is for training, testing, recruitment, jail.

Main hallway with large rooms connected to the main hallway.

## AI
# Codex Entry: Silverbrook Adventure Guild

**Classification:** Major Regional Guild Hall
**Location:** Silverbrook Settlement, Eastern Edge of Silverwood Forest
**Affiliation:** Continental Adventure Guild Network
**Jurisdiction:** Crystalmere Province

---

## Overview

The Silverbrook Adventure Guild sits at the heart of Silverbrook Settlement like a sovereign unto itself. Three storeys of polished Silverwood timber and pale Celestium-veined marble rise above the surrounding buildings, its glass ceiling panels catching the forest light and scattering it across the stonework in fractured silver ribbons. The structure predates half the settlement around it, built when Silverwood timber was still being felled freely before the Moonstrider accords restricted harvesting. Every beam, every panel, every carved bannister came from trees that no axe would be permitted to touch today.

From the street, the guild reads as old money and earned authority. The exterior walls combine rough-hewn Silverwood planks with dressed marble blocks quarried from the Moonstone Hills, their natural Celestium threads catching ambient light and giving the stone an inner luminescence that pulses faintly after dark. Arched windows of clear forest glass—poured thick and set in iron frames—line each floor, and the roofline is capped with a continuous glass lantern that floods the interior's upper reaches with daylight from dawn to dusk.

A carved relief above the main entrance depicts a Silverwood Tree in full ancient maturity, its canopy sheltering seven figures representing the seven founding adventurer classes of Crystalmere Province. The guild crest—a silver tree on a field of dark marble—is inlaid in Celestium tile on the entrance threshold, worn smooth by decades of boots but still glowing softly underfoot.

---

## Structural Layout

### Main Hallway

The spine of the building. A broad corridor runs the full depth of the ground floor from the entrance doors to the rear loading access, wide enough for six people to walk abreast without touching shoulders. The ceiling here reaches the full three-floor height, open to a vaulted glass panel at the top that runs the length of the hallway like a skylight spine. Silverwood columns line both sides at regular intervals, each one carved from a single trunk, the grain running unbroken from floor to capital. The floor is pale Celestium-veined marble, the same stone as the exterior, laid in broad slabs with thin Silverwood inlay strips between them.

All major rooms on the ground floor open directly off this hallway through wide double doors of dark Silverwood with glass panel inserts. The hallway connects the street entrance to the rear courtyard exit and serves as the natural artery through which all foot traffic moves. Notice boards mounted between the columns carry active quest postings, settlement bulletins, and guild announcements, updated each morning by the reception clerks.

A wide staircase at the hallway's midpoint rises to the upper floors, framed by a carved Silverwood balustrade that continues up through all three levels. A second, narrower service staircase at the rear provides access for staff and supply movement without cutting through the main public spaces.

---

## Ground Floor

**Purpose:** Reception, open access, commerce, information, dining.
**Access:** All registered guild members and the general public.

### Reception Hall

The first room branching from the main hallway's entrance end. Staffed at all hours by a rotating team of clerks behind a long curved counter of polished Silverwood, the surface worn to a deep lustre from years of hands and elbows. Behind the clerks, a wall of pigeonhole filing—hundreds of small compartments housing active member dossiers, pending quest assignments, and guild correspondence—rises to the ceiling. A rolling ladder on a brass rail provides access to the upper reaches.

The reception ceiling is lower than the hallway's, intimate by design, with recessed Celestium-stone panels set between exposed Silverwood beams that cast a steady, warm ambient glow rather than harsh directed light. A waiting bench of carved Silverwood runs the length of the far wall, padded in dark green leather, occupied at almost any hour by adventurers waiting on paperwork, new applicants watching the room with hungry eyes, or couriers resting before their next run.

A separate window at the counter's end handles financial transactions—quest payouts, deposit holding, and guild fee collections—attended by a dedicated accounts clerk who operates behind a secondary panel of reinforced glass.

### Quest Board Room

The largest room on the ground floor, directly off the main hallway's midpoint. The Quest Board Room is the building's loudest space at any hour. Three walls are given entirely to layered cork and Silverwood panel boards displaying active quests sorted by rank, region, and urgency. Quests are pinned with colour-coded tags—white for open, amber for claimed, red for critical. A standing railing separates browsers from the boards themselves, preventing the kind of scramble that stripped earlier, less-organised guilds of half their postings each morning.

The ceiling glass panel from the main hallway extends into this room's upper section, giving clean natural light over the boards during daylight. Oil lamp clusters on iron rings handle the evening and overnight hours. Rectangular reading tables occupy the room's centre, scattered with reference maps, dungeon records, and monster classification pamphlets that members consult before committing to a posting.

A clerk station in the corner manages quest registration—a member cannot remove a posting without signing it out in person.

### Guild Store

Adjacent to the Quest Board Room, accessible both from the hallway and through an internal door connecting to the quest space. The Guild Store carries standard adventuring supplies—rations, rope, light tools, basic healing compounds, monster repellent preparations, torch

## User
Condense to 1000 words max

## AI
# Codex Entry: Silverbrook Adventure Guild

**Classification:** Major Regional Guild Hall
**Location:** Silverbrook Settlement, Eastern Edge of Silverwood Forest
**Affiliation:** Continental Adventure Guild Network

---

## Overview

The Silverbrook Adventure Guild stands as the settlement's most imposing structure—three storeys of ancient Silverwood timber and Celestium-veined marble that predates half the town around it. Every beam came from trees no axe would touch today, felled before the Moonstrider harvesting accords locked the old-growth forest down. The exterior combines rough-hewn Silverwood planks with pale marble quarried from the Moonstone Hills, the natural Celestium threads giving the stone a faint inner pulse after dark. A continuous glass lantern caps the roofline, flooding the interior with daylight. Above the entrance, a carved relief depicts an ancient Silverwood sheltering seven founding adventurer classes. The guild crest—silver tree on dark marble—is inlaid in Celestium tile at the threshold, worn smooth by decades of boots, still glowing.

---

## Main Hallway

The building's spine. Wide enough for six abreast, running the full depth of the ground floor from entrance to rear courtyard. A vaulted glass panel runs its entire ceiling length. Silverwood columns carved from single trunks line both sides. The floor is pale Celestium-veined marble with Silverwood inlay strips between slabs. All major ground floor rooms open off this corridor through wide Silverwood double doors with glass panel inserts. Quest notices cover the boards mounted between columns, updated each morning. A grand staircase at the hallway's midpoint—framed by carved Silverwood balustrade—connects all three floors. A rear service stair handles staff and supply movement.

---

## Ground Floor — Public Level

**Access:** All ranks, general public.

**Reception Hall** — A long curved Silverwood counter staffed at all hours. Behind it, floor-to-ceiling pigeonhole filing holds active member dossiers, quest assignments, and correspondence. Celestium-stone panels set between exposed beams cast steady ambient light. A reinforced glass window at the counter's end handles all financial transactions separately.

**Quest Board Room** — The building's loudest space. Three walls of layered cork and Silverwood panels display active quests sorted by rank, region, and urgency, tagged white for open, amber for claimed, red for critical. Central reading tables hold reference maps and dungeon records. A clerk station manages sign-outs—no posting leaves the board without a signature.

**Guild Store** — Standard adventuring supplies, basic healing compounds, tools, rope, and torches alongside guild-sourced Silverwood equipment and Celestium-grade materials at premium pricing. A locked case behind the counter holds restricted items requiring rank verification.

**Eatery** — Open from before dawn to late evening. Heavy Silverwood tables, long bench seating, a kitchen that produces straightforward substantial food at fair prices. The eatery connects directly to the main hallway and to a rear service entrance for deliveries. A short bar runs along one wall serving ale, cider, and hot drinks. The room fills at dawn with departing parties and again at dusk with returning ones.

---

## Second Floor — Operations Level

**Access:** Registered members, mid-rank and above.

Quieter than the ground floor. The staircase opens onto a carpeted landing with the same Silverwood and marble aesthetic carried upward. Natural light comes through large arched forest-glass windows and the hallway's upper glass panel.

**Rest Quarters** — Private and shared rooms for members on extended contracts or recovering between assignments. Furnishings are plain but quality—Silverwood frames, good mattresses, lockable storage. Shared washrooms at each corridor end.

**Meeting Rooms** — Four medium-sized rooms used for party briefings, contract negotiations with clients, and inter-guild correspondence meetings. Each holds a central table, chairs, and a wall-mounted map bracket. Soundproofed with layered Silverwood panelling.

**Mid-Rank Lounge** — A common room for C-rank and above. Comfortable chairs, a reading collection of dungeon records and regional surveys, and a small service bar. The one room on this floor with a view directly into the forest through an oversized glass panel.

---

## Third Floor — Restricted Level

**Access:** A-rank members, Guild Master, Vice Guild Master, invited guests only.

The Celestium-veined marble grows richer here—the stone was selected for highest thread density, giving the walls a continuous soft luminescence that needs no additional lamp support during daylight. The glass ceiling panel reaches its full width on this floor, making the space feel open despite the closed-door nature of everything that happens inside it.

**Guild Master's Office** — Corner position, maximum sightlines. Large Silverwood desk, document vault, a private meeting table seating six. The only room in the building with direct access to the roof observation platform above.

**Vice Guild Master's Office** — Adjacent, connected by an internal door. Mirrors the Guild Master's layout at slightly reduced scale.

**High Council Chamber** — The floor's centrepiece. A circular room with a round Celestium-inlaid table, twelve seats, and a domed glass ceiling section that sits directly under the roofline lantern. Used for rank promotions, major contract negotiations, crisis briefings, and inter-guild summits.

**A-Rank Lounge** — Sparse, private, well-appointed. A place to debrief after high-difficulty assignments without the noise of the floors below.

---

## Basement — Functional Core

**Access:** Staff, recruits, detainees, authorised personnel.

Stone-walled, lit entirely by Celestium-panel lighting recessed into the ceiling. Cooler than the floors above. The basement handles everything the public-facing building cannot.

**Training Hall** — The largest basement space. Open floor, reinforced walls, weapon racks, padded impact zones, and suspended target frames. Used for applicant assessments, active member conditioning, and rank-up physical trials.

**Testing Chamber** — Separated from the training hall by a heavy Silverwood door. Controlled environment for ability evaluation, dungeon simulation exercises, and formal rank examination. Observation slot in the door for assessors.

**Recruitment Office** — Where new applicants are processed, interviewed, and assigned provisional status. Bare and deliberate—no decoration, no comfort. The guild does not soften first impressions here.

**Holding Cells** — Four stone cells with iron-reinforced Silverwood doors. Used for detaining members who breach guild law, dangerous captures awaiting transfer, or individuals held pending provincial authority handover. A duty guard post sits opposite the cell block at all hours.

## User
Update the inn. Pick a location close 10 minute walk to the ag. Known for a ag inn. 10 woman adventures dorm, large tavern, inn for visitors

## AI
# Codex Entry: The Frosted Mug Inn

**Classification:** Inn & Tavern (Adventure Guild Affiliate)
**Location:** Silverbrook Settlement, 10-minute walk from the Silverbrook Adventure Guild along the Main Road
**Proprietress:** Helda Frostmane
**Reputation:** “The guild’s real common room” — unofficial home base for adventurers of every stripe

---

## Overview

The Frosted Mug sits a measured ten minutes from the guildhall gates on a well-trampled stretch of the Main Road, close enough that a runner can fetch a forgotten quest slip and be back before the ale goes flat. Formerly the Frostblood family homestead, the building combines a stone foundation with frost-birch timber framing, the mortar between stones laced with a crystalline grit that catches moonlight and glimmers faintly after dark. Two structures share the compound: the main inn building housing private rooms and the public tavern, and a converted trapper’s lodge out back that serves a very specific purpose.

Everyone calls it “the Mug” now. The guild runs the boards, but the Mug runs the gossip, the war stories, and the hangovers.

---

## Main Building — The Mug

**Ground Floor: The Tavern**
A long, low-beamed room that can swallow a full adventuring party and still have space for a card game at the corner table. Silverwood-plank flooring, heavy tables scarred with decades of blade tips and tankard rings, bench seating that has shaped itself to a thousand backsides. A stone hearth dominates the far wall, burning seasoned birch through the cold months. The bar runs nearly the length of the room—frost-birch top over a fieldstone base—with a brass foot rail that has seen more boots than a cobbler’s shop. Helda’s own frostmead is always on draft, alongside a rotating selection of local ales and a cider pressed from Silverwood-edge apples. The kitchen turns out straightforward food from before dawn until the last drunk stumbles home: meat pies, root stew, fried tubers, black bread with salted butter. The tavern connects directly to the main road entrance and to a rear door leading to the courtyard and the dorm building beyond.

**Upper Floors: Guest Rooms**
Eight private rooms spread across two floors, each small but meticulously kept. The beds are the Mug’s true claim to fame—deep mattresses stuffed with Silverwood wool, layered under goose-down quilts, the headboards carved from frost-birch branches. Helda’s rule is simple: no weapons on the mattress, no blood on the sheets. Two rooms are discreetly fitted as WAHO chambers, marked by a small silver frostflower above the doorframe, booked through quiet word with Helda herself. Washrooms at each corridor’s end offer hot water at all hours, a luxury not every inn in Silverbrook can claim.

**Staff Quarters**
Tucked under the eaves, a small apartment houses the live-in staff: Gwenyth Ironpaw (beastkin cook and brewmaster), Lyriel Moonwhisper (elf housekeeper and herbalist), and Tamsin Sparkwright (gnome maintenance and mechanist). Helda’s own quarters occupy the ground floor behind the kitchen—close enough to hear a brawl start before it finishes.

---

## Secondary Building — The Den

**Purpose:** Female adventurers’ dormitory
**Capacity:** 10 beds

The converted trapper’s lodge across the courtyard is the Mug’s worst-kept secret and its most cherished feature. Helda, a retired C-rank brawler herself, converted the building years ago into a bunkhouse specifically for female adventurers waiting on contracts, recovering from dungeons, or simply too broke for a private room. Ten beds line the walls in a single open bay—sturdy Silverwood frames with decent mattresses, each with a lockable foot locker. A communal bath with a deep copper soaking tub, a small drying rack for gear, and a wood stove for winter nights. The dorm operates on a first-come, first-serve basis, with guild membership granting priority. Helda keeps no roster, but she knows exactly who is sleeping where every night, and trouble is evicted before sunrise. A matron’s nook at the entrance holds a small desk where Helda or one of her staff checks members in at odd hours. The Den’s atmosphere is sleepover-meets-barracks: gear hangs from bedposts, drying herbs scent the air, and someone is always braiding someone else’s hair at the long table under the window.

Pricing is steeply discounted for registered guild members. Visitors may inquire, but Helda’s answer is usually a flat no unless a guild matron vouches for them.

---

## Courtyard & Amenities

The central courtyard connects the two buildings via flagstone paths. Wrought-iron tables and chairs cluster under a young Silverwood sapling that Helda planted the year she bought the property. A stable with six stalls—enchanted to stay frost-free—sits against the compound’s rear wall, a well fed from the Silverthread River offers clean water, and a small herb garden supplies both the kitchen and Lyriel’s remedies. A smokehouse and drying racks complete the working end of the yard.

---

## Pricing & Policies

- **Private Room:** 2 Gleams/night (meals included)
- **The Den (dorm bed):** 1 Gleam/night for guild members, 2 Gleams for non-members
- **Stabling:** 1 Gleam/night per mount
- **WAHO Upgrade:** +5 Gleams (negotiate directly with Helda)
- **Helda’s Rules:** No weapons at the table. No trouble in my beds. No men in the Den. Ever.

---

## Reputation & Atmosphere

The Mug is the guild’s unofficial spillover. At dawn the tavern fills with parties grabbing a last hot meal before hitting the forest. At dusk it floods with the same parties, dirtier and drunker, rehashing every misstep over frostmead and card games. Helda holds court behind the bar, a broad-shouldered frost-born beastkin who remembers every name and every tab. She’ll cry at a wedding announcement, break up a fight with one hand on each collar, and personally walk a homesick rookie back to the Den at two in the morning. The guild posts quests; the Mug posts the stories that come back from them. No adventurer in Silverbrook feels like a stranger after one night under its roof.

## User
Make a detailed adding texture and flavorful codex for fhe sbc merchant guild. It is built with cel infused stone more than sbf wood to help protect the vaults and other high value products.

Has 4 floors and basement. Instead of a guild hall Its closer to a multifloor mall.

1st floor has the main entrance plaza, low level meeting rooms, receptions desk, etc. Also has the open market plaza

2nd-3rd floor are for meetings and personal shops. The higher your merchant rank depends on the shop size and location.

4th floor is received for top guild workers, top guild members, restrcited access.

cel laced Basement is a high restricted access for vaults of high value to ultra quality products.

## AI
# Codex Entry: The Argent Bourse

**Classification:** Merchant Guild Hall & Trade Complex
**Location:** Merchant's Ring District, Silverbrook City, beneath the Silver Bourse Tree
**Affiliation:** Argent Merchants Consortium
**Reputation:** "The Vault City" — where fortunes are made on the first floor and buried on the last

---

## Overview

Where the Adventure Guild wears its age in Silverwood grain, the Argent Bourse wears its wealth in stone. Four floors and a basement of dressed Celestium-infused granite rise beneath the Silver Bourse Tree's rotating market platforms, the building constructed less like a hall and more like a fortress that happened to sell things. Silverwood appears only as accent—door frames, display cases, the odd ceremonial beam—because the Consortium learned generations ago that wood burns, wood rots, and wood cannot stop a determined thief. Stone does. Stone laced with Celestium does better.

The exterior walls are pale grey shot through with veins of blue-white CEL that pulse on a slow, steady rhythm, brighter near the ground floor and dimmer as the eye climbs, until the basement—invisible from the street—runs with the densest thread of all. Locals call the effect "the Bourse's heartbeat," and merchants swear the building thrums faintly underfoot on auction days, when enough gold and CEL-marked goods change hands to spike the ambient field.

The entrance is a broad archway of black granite, flanked by two seated silver lion statues cast from actual argent-grade ore, their eyes inset with dull CEL crystal that some claim tracks visitors as they pass. Above the arch, an engraved ledger-relief depicts the founding seven trading houses shaking hands over a scale, the scale itself inlaid with real Celestium so it never tarnishes. The guild crest—a silver coin split by a merchant's balance—is set into the entrance floor in mosaic tile, and unlike the Adventure Guild's worn threshold, the Bourse's crest gleams untouched. Nobody walks on a merchant's money here. You walk around it.

---

## Ground Floor — The Plaza

**Access:** Open to the public, all merchant ranks.

The ground floor abandons any pretence of a guild hall corridor and opens instead into a vast, sky-lit plaza—the building's true heart. A domed glass-and-CEL ceiling three storeys up floods the space with clean white light by day and a soft argent glow by night, powered by the same CEL lattice running through the walls. The floor is polished pale stone inlaid with concentric rings of darker granite, radiating outward from a central fountain where a bronze statue of the Consortium's founder, Argent Voss, eternally counts coin into an overflowing bowl.

**Open Market Plaza** — Ringed stalls and permanent kiosks fill the outer rings of the floor, licensed vendors rotating on quarterly contracts. Silk merchants from the southern provinces, gem cutters from the Moonstone Hills, exotic spice traders who set up shop for a single season before vanishing back into the trade roads. The plaza runs loud and colourful, criers hawking wares over the low murmur of haggling, the smell of incense and hot metal and fresh leather all competing for space in the air.

**Reception Desk** — A long crescent counter of black stone dominates the plaza's inner ring, staffed by CEL-vetted clerks who verify guild membership, issue visitor passes, and direct traffic toward whichever floor a visitor's business requires. Behind the desk, a floor-to-ceiling ledger wall of locked brass drawers holds active contracts, membership records, and standing trade agreements, each drawer keyed to a specific clerk's CEL signature.

**Low-Tier Meeting Rooms** — A bank of eight small rooms along the plaza's western wall, available to any registered merchant on a first-come basis for negotiating small contracts, settling disputes, or meeting new trade partners. Plain stone walls, a table, two benches, a lockbox for the deposit fee. No frills. The Consortium reserves comfort for those who've earned it.

**Currency Exchange & Assay Office** — Tucked behind reinforced glass near the fountain, staffed by licensed assayers who verify coin purity, appraise raw Celestium samples, and convert foreign currency at the day's posted rate, chalked fresh each morning on a board above the counter.

---

## Second & Third Floors — The Gallery Levels

**Access:** Registered merchants, rank-gated shop allocation.

The stairs and twin CEL-powered lift platforms at the plaza's rear carry traffic up into what merchants simply call "the Gallery"—two floors of permanent shopfronts ringing an open central well that looks straight down into the plaza below and straight up through the glass dome above. Balconied walkways with polished brass railings wrap each floor, shop after shop set into the stone like jewels in a setting, the whole arrangement closer to a market of small kingdoms than a guild corridor.

**Shop Allocation by Rank** — Space here is currency in itself. A newly ranked merchant gets a narrow stall on the third floor's outer ring, barely wide enough for a counter and a curtain. Climb the Consortium's ranks—Bronze Ledger, Silver Ledger, Gold Ledger, and the rare Argent Ledger—and the shop grows with you: wider frontage, better lighting, a spot closer to the well's centre where foot traffic pools thickest. The most coveted addresses sit on the second floor's inner ring, directly above the plaza fountain, reserved for Gold and Argent Ledger holders who've paid their allocation fees in full for the quarter.

**Personal Shops** — Every trade imaginable finds a stall here: fine jewellers with CEL-lit display cases, tailors draped in silks that shift colour under the ambient light, rare book dealers, alchemical suppliers, a scattering of dungeon-loot brokers who deal exclusively with Adventure Guild contacts. Each shop is customised to its owner's trade and rank, from bare stone counters to fully appointed boutiques with private fitting rooms and CEL-cooled display cabinets for perishable magical goods.

**Meeting Chambers** — Interspersed between shop rows, a dozen soundproofed meeting rooms of increasing size and comfort, bookable by rank tier. Gold Ledger holders and above get first refusal on the largest chambers, complete with a private attendant and refreshment service.

---

## Fourth Floor — The Ledger Hall

**Access:** Top guild officials, Argent Ledger holders, invited guests only.

The fourth floor drops the mall atmosphere entirely. Quiet, carpeted, sealed behind a single guarded stairwell checkpoint, the Ledger Hall runs on a different rhythm than the floors below. The CEL veining in the stone up here burns a richer blue, selected for density during construction the same way the Adventure Guild reserved its finest marble for its own top floor.

**Guild Master's Chambers** — Occupying the corner position with sightlines over both the plaza dome and the district's Silver Bourse Tree beyond, the Guild Master's office holds a black granite desk the size of a small boat, a document vault sealed with a triple CEL-lock, and a private balcony overlooking the market rings below.

**Vice Officials' Suites** — A row of five offices for the Consortium's ranking officers—Trade Director, Assay Master, Ledger Keeper, Security Warden, and Foreign Relations envoy—each appointed to reflect the holder's domain.

**The Round Table** — A circular chamber at the floor's centre, mirroring the Adventure Guild's High Council Chamber in function if not in warmth. Twelve seats around a CEL-inlaid table host quarterly rank promotions, major contract ratifications, and the occasional tense negotiation between rival trading houses that the plaza floor isn't discreet enough to handle.

**Argent Lounge** — A private retreat for Argent Ledger holders, all four of them at present. Deep chairs, a curated wine collection, and a window that looks straight down through the building's central well to the fountain far below—a reminder of how far up the ranks a person has climbed.

---

## Basement — The Vault

**Access:** Extremely restricted. Security Warden authorisation, dual-key verification, or direct Guild Master order required.

Below the plaza, the CEL lattice reaches saturation levels found nowhere else in the district. The walls here don't merely carry veins of Celestium—entire sections are cast from CEL-laced stone poured solid, dense enough that the air itself carries a faint metallic taste. No windows. No glass. Light comes from recessed CEL-panels calibrated to a cool, clinical white that leaves no shadow to hide in.

**The Approach** — A single guarded stairwell descends from the fourth floor, the only route down. Two additional checkpoints break the descent, each staffed around the clock, each requiring a fresh verification pass.

**Vault Chambers** — A dozen sealed rooms of varying size, from small personal lockboxes for individual Gold and Argent Ledger holders to the cavernous Consortium Reserve, where the guild's collective wealth, master trade agreements, and highest-grade raw Celestium stock sit behind doors that take two keyholders acting in tandem to open.

**Appraisal Vault** — A separate secured chamber where ultra-rare items—dungeon-sourced artefacts, unclassified CEL formations, items awaiting Scholar's Canopy verification—are examined under full lockdown before being cleared for either sale, storage, or, in rare cases, destruction.

**Security Post** — A permanent detachment of Consortium-employed guards, several of them retired B-rank adventurers drawn by the pay, holds the basement at all hours. Nobody has ever successfully robbed the Argent Bourse. The Consortium intends to keep that record intact.

## User
Details and flavor pertaining to the buildings aesthitics. Go into detail describing the interior and exterior of the building.

## AI
# Codex Entry: The Argent Bourse — Architectural Aesthetics

**Classification:** Merchant Guild Hall & Trade Complex
**Location:** Merchant's Ring District, Silverbrook City

---

## Exterior Aesthetics

The Argent Bourse rejects the warm, grain-and-lantern glow of the Adventure Guild across the city and replaces it with something colder, harder, deliberately impressive. The building rises four storeys from a wide granite plinth, its footprint nearly square, corners rounded rather than sharp so that the CEL veining running through the stone can trace unbroken lines from foundation to roof without interruption. Up close, the exterior stone reads as a pale dove-grey, almost silver in direct sun, quarried from a single vein in the Moonstone Hills chosen specifically for its density of natural Celestium thread. The Consortium didn't build with this stone by accident—they spent eleven years and a small fortune sourcing enough matching granite to clad an entire building without a single visible seam of mismatched colour.

The CEL veins themselves run in slow, branching patterns across every wall, thicker near ground level and tapering as they climb, like frost creeping up glass in reverse. By day they're barely visible, a faint blue-white shimmer beneath the stone's surface. By night, the building becomes a landmark visible from half the district—every vein glowing in soft synchronised pulse, brightest at the base, dimming toward the roofline, giving the whole structure the appearance of something quietly breathing.

The roofline itself breaks from the flat, functional lines below it. A shallow-domed glass ceiling crowns the plaza beneath, its curve supported by black iron ribwork forged in a radiating sunburst pattern, each panel of glass a slightly different tint of pale blue so that sunlight scatters through in soft prismatic fragments rather than a single flat wash. At night, the dome glows from within like a second moon set into the district skyline, visible even from the Silver Bourse Tree's uppermost platforms.

The main entrance sits recessed beneath a deep colonnade of six fluted granite pillars, each easily thirty feet tall, their surfaces polished to a near-mirror sheen. The two seated lion statues flanking the archway are cast from genuine silver-argent alloy rather than painted stone, weathered to a soft grey patina everywhere except their CEL-crystal eyes, which someone in the maintenance guild polishes weekly to keep the "watching" effect sharp. Above them, the founding relief is carved in deep bas-relief rather than shallow etching, deliberately lit from below by a row of ground-set CEL lamps so the seven trading houses seem to loom rather than merely decorate.

Wide steps of the same pale granite lead up to the entrance from street level, worn smooth in a narrower path down the centre where decades of foot traffic have concentrated, flanked by untouched stone at the edges—a visible record of exactly how many people walk this building's centre line rather than its margins.

---

## Interior Aesthetics — Ground Floor Plaza

Stepping through the entrance arch, the temperature itself seems to shift—cooler, cleaner, the air carrying a faint mineral crispness that locals half-jokingly call "vault breath." The plaza's scale hits immediately: three full storeys of open air above, capped by the glass dome, the space so large that voices from the far side of the fountain reach the entrance only as texture, not words.

The floor is a masterwork of concentric inlay—pale stone rings alternating with bands of darker charcoal granite, each ring subdivided by thin brass strips that catch the dome light and throw faint gold lines across the floor like a compass rose stretched to building scale. At the exact centre, the bronze founder's fountain sits atop a raised marble dais, water running in a continuous silver sheet down Argent Voss's cast bronze arms into the overflowing bowl below, the basin's rim inlaid with actual small-denomination coins sealed under clear resin—donated, tradition says, by every merchant who's ever closed a deal within these walls.

The market stalls ringing the outer floor break the plaza's cold formality with deliberate colour—striped awnings in a dozen competing trade-house hues, hanging silk banners, lantern strings threaded between kiosk poles. It's the one part of the building where the Consortium allows visual chaos, because chaos here means commerce, and commerce is the entire point.

The reception counter's crescent of black stone sits polished to the point of reflection, cool under the palm, its surface inlaid with a single unbroken line of silver script running its length—the Consortium's founding charter, rendered too small to read at a glance but perfectly legible up close, a detail most visitors never notice until a clerk points it out.

---

## Interior Aesthetics — Gallery Levels (Second & Third Floors)

Ascending past the plaza, the architecture tightens and warms. The central well cuts straight up through both gallery floors, ringed by brass balcony railings polished to a warm gold rather than the ground floor's cool silver, softening the transition from commerce-hall to something closer to a jeweller's showroom. Sunlight from the dome above filters down through the well in a soft diffuse column, catching dust motes and the occasional drift of incense smoke from a shop below.

Shopfronts along both galleries are individually dressed by their owners within Consortium guidelines, creating a patchwork of competing aesthetics that somehow reads as cohesive rather than cluttered—dark lacquered wood beside pale stone beside gleaming CEL-lit glass, each storefront a small architectural statement of its owner's trade and rank. The stone floor here softens into warmer beige tones, inlaid with directional veining that subtly guides foot traffic toward the well's centre rather than the outer walls, a deliberate design choice that keeps buyers moving past every stall.

Ceiling height on these floors runs lower and more intimate than the plaza, lit by recessed CEL panels set into shallow coffered squares, each panel dimmable by the shop beneath it—giving individual merchants control over their own pool of light, a small luxury tied directly to rank.

---

## Interior Aesthetics — Fourth Floor Ledger Hall

The mall atmosphere vanishes the instant the stairwell checkpoint clears. Carpet replaces stone underfoot for the first time in the building, a deep charcoal weave threaded with faint silver filament that catches light without demanding attention. The CEL veining in these walls burns a richer, deeper blue than anywhere below, selected during construction for saturation density, giving the corridors a permanent twilight glow even at midday.

Where the lower floors favour open sightlines and loud colour, the fourth floor favours weight and shadow. Doorways are deep-set, frames carved from dark imported hardwood rather than the building's usual stone or Silverwood, each door fitted with brass hardware gone dark with age and deliberate lack of polish—wealth here doesn't need to shine, it simply needs to be understood. The Round Table chamber's domed section allows a narrow shaft of dome-light down from the plaza's glass ceiling far above, a single beam that crosses the room slowly through the day like a sundial, timed by original design so it falls directly across the table's centre at local noon.

---

## Interior Aesthetics — The Vault Basement

Descending past the final checkpoint, all warmth disappears. The CEL-laced stone here isn't veined—it's saturated, poured solid with Celestium suspended through the entire structure rather than threading across a surface. The walls hold a faint, constant blue-white glow with no discernible light source, the stone itself luminous rather than lit. There are no windows, no wood, no soft materials of any kind—every surface is stone, metal, or reinforced glass, chosen because none of them burn, bend, or bribe.

The air carries a faint electrical taste, sharp at the back of the throat, and sound behaves strangely down here—footsteps land flat and dead against CEL-dense stone that refuses to carry an echo, a deliberate acoustic property that makes eavesdropping functionally impossible. Vault doors are unadorned slabs of dark alloy, seams so tight they read as solid blocks until the mechanism cycles, and even then they open with a low, heavy sound rather than a dramatic groan—engineered quiet, like everything else about the building's deepest floor.

## User
Update scene beat

starting at the mgh entrance. Giving detail to the building.

Instead of going to a random clothing store ji is escorted to a clothing store in MGH. they end up at Elos reccomended clothing place of choice. Still has the hadcore sloppy toppy quick and rough bj with him dumping a massive load into the thick lipped flirtatious goblin clothing store clerk.

They do some shopping for everyday supplies while they are on the first floor making their way to the receptionists area.

Goes through the afm mgh receptionist line. Sells his drops and mats obtained during the yesterdays start to his adventure.

He received a couple months of currency from selling most of his drops and mats.

When ji and elo are about to leave a bunny merchant high attendant politely stops them and ask that they come to the merchant guild masters room.

Elo already saw it coming since Ji is a high value man that ks had to told the guild master about but she also has ears and money all over town.

As they are escorted upstairs ji gets a nice view of some grade a bunny ass.

## AI
The Argent Bourse rose ahead of them, pale granite catching the midmorning sun until the whole facade looked dusted in frost. John tilted his head back to take in the dome, glass panels throwing broken blue light across the steps.

"They polish the lions," Elowen said, nodding at the silver statues flanking the entrance. "Every week. Rain or not."

"Rich people problems."

They passed between the fluted pillars and the temperature dropped a few degrees, that mineral crispness settling into John's lungs. The plaza opened up beyond the archway—three storeys of open air, the fountain throwing silver sheets of water down bronze arms at the centre of it all.

"This way," Elowen said, already angling toward the market ring. "Trust me on this one."

She led him past a jeweller's stall glittering under CEL-lamps, past a spice trader shouting prices nobody was negotiating on, until she stopped in front of a narrow shopfront with a hand-painted sign reading **Nettle & Thread**.

"Best tailor on the ground floor," she said. "Cheap, fast, and she won't rob you blind."

Inside, bolts of fabric climbed the walls in every colour a dye vat could produce. A goblin woman stood behind the counter, green skin, oversized lips painted a deep plum that matched nothing else in the shop, and eyes that dragged up John's frame the second the door swung shut behind him.

"Well now." She rested both elbows on the counter, chin propped on her knuckles. "Vale Vanguard doesn't usually bring me the pretty ones."

"He needs everyday clothes," Elowen said. "Nothing fancy."

"Mm." The goblin's gaze didn't leave John's face. "I'll take real good care of him. Why don't you go pick out a belt or something, hon?"

Elowen blinked, glanced at John, then shrugged and wandered toward a rack near the window.

The goblin came around the counter with a measuring tape looped over one shoulder, but she never got as far as unspooling it. She dropped to her knees in front of him instead, plum lips already parting.

"Let's see what we're working with."

She had his trousers undone before he got a word out, and the sound she made when his cock came free—somewhere between delight and disbelief—carried clear across the shop floor. Elowen's ears didn't so much as twitch from behind the rack, too absorbed in fabric swatches to register what was happening ten feet away.

The goblin wasted no time on technique. She just opened her throat and took him down in one wet, sloppy drop, spit running down her chin, those thick lips stretched obscene around his girth. She gagged once, pulled back with a string of drool connecting her mouth to the tip, then dove straight back in like she'd been starving for it.

"Christ," John muttered, hand finding the back of her head.

She hummed around him, the vibration doing half the work, her throat working in fast, greedy pulls that left no room for finesse. Sloppy. Loud. The kind of noise that would've mortified anyone with something to prove. She had nothing to prove. She just wanted it messier.

He came without much warning, hips locking, and she took every rope of it swallowing hard between each pulse until her cheeks bulged and overflowed anyway, thick strands of it dripping down onto her apron.

She sat back on her heels, wiped her chin with the back of her hand, and grinned up at him like she'd won something.

"Come back anytime, hon." She hauled herself up, straightened her apron, and reached for her measuring tape like nothing had happened. "Now. Let's get you sized properly."

Twenty minutes later John walked out with two shirts, a pair of trousers, and a receipt that made no mention of what else got paid for.

"Find a belt?" he asked.

"Three, actually." Elowen held up a small paper sack. "Couldn't decide."

They worked their way through the ground floor after that, picking up the boring necessities nobody isekai's for—soap, a whetstone, a coil of rope, dried rations that tasted like compressed cardboard but kept for months. Elowen haggled every stall like it was a blood sport, and John let her, mostly because watching her stare down a spice merchant twice her age was funnier than anything else on offer.

The AFM line at the reception counter moved fast, males waved through ahead of the general queue, clerks falling over themselves to be the one who got to process his dossier. John dumped his sack of drops and mats onto the counter—claws, hide, a handful of raw CEL fragments he hadn't known the value of until the assayer's eyes lit up.

"That's a fine haul for a first outing," the clerk said, sorting the pile with practised hands. "Two months of stipend, easy, once we run the appraisal."

"Told you dungeon diving pays," Elowen said.

"You did the diving. I mostly stood there."

"You stood there very well."

The clerk counted out coin into a leather pouch, John's balance settling heavier in his pocket than it had any right to for one day's work.

They were three steps from the door when a voice caught them from behind.

"Excuse me—sirs, miss, if I could borrow a moment."

The attendant was a bunny-eared woman in the Consortium's grey and silver uniform, ears twitching, hands folded in front of her with the kind of practised politeness that meant she'd been sent, not asked.

"The Guild Master would appreciate a brief audience upstairs. Whenever it suits you, of course."

Elowen didn't look surprised. If anything, she looked like she'd been waiting for it.

"Course she wants to see you," she muttered under her breath as they followed. "Kaela's got a big mouth when it comes to good news. And this place has ears in every wall and coin in every pocket."

"Should I be worried?"

"No." She said it flat, certain. "Just don't be rude."

The attendant led them toward the staircase, hips swaying with each step in a way that put her uniform skirt to serious work, and John found himself several steps behind on purpose, admiring the view the whole climb up.

## User
Ch 9 scene beat 1 1000 word prompt for a 1500 word scene beat built for sonnet 5. Add dialogue, ecchi, lucky pervert, phsycial texture. Use ai language to help it give me the best scene.

Update scene beat

starting at the mgh entrance. Giving detail to the building.

Instead of going to a random clothing store ji is escorted to a clothing store in MGH. they end up at Elos reccomended clothing place of choice. Still has the hadcore sloppy toppy quick and rough bj with him dumping a massive load into the thick lipped flirtatious goblin clothing store clerk.

They do some shopping for everyday supplies while they are on the first floor making their way to the receptionists area.

Goes through the afm mgh receptionist line. Sells his drops and mats obtained during the yesterdays start to his adventure.

He received a couple months of currency from selling most of his drops and mats.

When ji and elo are about to leave a bunny merchant high attendant politely stops them and ask that they come to the merchant guild masters room.

Elo already saw it coming since Ji is a high value man that ks had to told the guild master about but she also has ears and money all over town.

As they are escorted upstairs ji gets a nice view of some grade a bunny ass.

## AI
The Argent Bourse rose out of the district like something carved rather than built, granite pale enough to look frosted even under full sun. John craned his neck at the entrance colonnade, six pillars thick as tree trunks polished to a mirror shine, the two silver lions flanking the archway watching him with crystal eyes that felt a little too aware for statues.

"Don't stare at the lions," Elowen said. "People'll think you're new."

"I am new."

"Don't advertise it."

Through the arch, the temperature dropped and the noise swelled—the plaza opened up three storeys tall, glass dome scattering light across a floor inlaid with rings of pale and charcoal stone. The fountain at the centre threw silver sheets down a bronze founder's arms, coins glinting under the surface of the basin.

"This way." Elowen cut through the market ring without slowing, past silk stalls and a spice trader hawking something that smelled like fire. "There's a tailor here I like. Cheap. Fast. Won't rob you blind."

The shopfront she stopped at had a hand-lettered sign—**Nettle & Thread**—and bolts of fabric stacked floor to ceiling in every colour a dye vat could manage. A goblin woman leaned on the counter inside, green-skinned, lips a deep painted plum, eyes tracking John the moment the door swung shut behind him.

"Well, well." She didn't move from her elbows. "Vale Vanguard doesn't usually bring me the pretty ones."

"He needs basics," Elowen said. "Shirts, trousers, nothing fussy."

"Mm-hm." The goblin's gaze hadn't left John once. "I'll take real good care of him. Go find yourself a belt, hon."

Elowen shrugged and drifted toward a rack near the window, entirely unbothered, and John barely had time to register the tape measure looped over the goblin's shoulder before she rounded the counter and dropped to her knees in front of him.

"Let's see what we're working with."

She had his trousers undone before he could get a syllable out, and the noise she made when his cock came free—half delight, half disbelief—carried further than it had any business carrying in a shop with the door unlocked.

"Sweet mother," she muttered, and then she wasn't talking anymore.

She swallowed him in one wet, sloppy drop, no warmup, no finesse, spit already running down her chin and pooling at her collar. Her thick lips stretched obscene around the girth of him, cheeks hollowing, throat working in fast greedy pulls that gagged her twice before she pulled back gasping, a string of drool bridging her mouth to the tip of him.

"Christ," John said, one hand finding the back of her head out of pure reflex.

She hummed something that might've been agreement and dove straight back down, sloppier the second time, spit and precome smearing across her chin, the counter creaking under her elbow where she braced herself. Loud, filthy, unconcerned with technique—she just wanted it messy, wanted the noise, wanted her own throat fighting her the whole way down.

Elowen flipped through a rack of belts ten feet away, humming to herself, ears not so much as twitching.

John came without much of a warning window, hips locking, and the goblin swallowed through every pulse of it, cheeks bulging on the last two before it spilled past her lips anyway, thick ropes of it dripping onto her apron. She sat back on her heels, wiped her chin with the back of one hand, and grinned up at him like she'd won a prize at a fair.

"Come back anytime, hon." She hauled herself upright, straightened her apron like nothing had happened, and reached for her measuring tape. "Now. Let's get you sized properly."

Twenty minutes later he walked out with two shirts, a pair of trousers, and a receipt that mentioned none of what else got paid for.

"Find a belt?" he asked.

"Three." Elowen held up a small paper sack, entirely pleased with herself. "Couldn't decide."

They worked the ground floor after that, picking through the boring necessities nobody isekai's for—soap, a whetstone, a coil of rope, dried rations that tasted like compressed cardboard but kept for months without turning. Elowen haggled every stall like blood sport, squaring off against a spice merchant twice her age until he caved on price just to make her leave.

"You enjoy that far too much," John said.

"It's the only puzzle I'm any good at."

The AFM line at the reception counter moved fast, males waved past the general queue while clerks nearly tripped over each other for the chance to process his dossier. John dumped his sack of drops and mats onto the counter—claws, hide strips, a handful of raw CEL fragments he hadn't known the value of until the assayer's eyes went wide.

"Fine haul for a first outing," the clerk said, sorting the pile with quick, practised hands.

"Told you dungeon diving pays," Elowen said.

"You did the diving. I mostly stood there looking useful."

"You stood there very well."

The clerk counted coin into a leather pouch, and John's balance settled heavier in his pocket than a single day's work had any right to earn him—two months' stipend, easy, once the appraisal cleared.

They were three steps from the door when a voice caught them from behind.

"Excuse me—if I could borrow a moment."

The attendant was bunny-eared, dressed in the Consortium's grey and silver, ears twitching once as she folded her hands in front of her with the kind of rehearsed politeness that meant she'd been sent, not asked.

"The Guild Master would appreciate a brief audience upstairs. Whenever suits you, of course."

Elowen didn't look surprised. If anything, she looked like she'd been waiting on it the whole walk over.

"Course she wants a look at you," she muttered, low enough for just him. "Kaela's got a big mouth about good news, and this place has ears in every wall and coin in every pocket."

"Should I be worried?"

"No." Flat, certain, no hesitation in it. "Just don't be rude."

The attendant turned and led them toward the staircase, and John found himself lagging half a step behind on purpose, watching the sway of her hips work her uniform skirt with every stair she climbed, silver trim catching the dome light overhead.

"You're staring," Elowen said, not quiet at all this time.

"I'm admiring the architecture."

"That's not architecture."

"Depends who you ask."

## User
provide me a Ch 9 scene beat 1 1000 word prompt, for a 1500 word scene beat built for sonnet 5. Add dialogue, ecchi, lucky pervert, phsycial texture. Use ai language to help it give me the best scene.

Break the prompt into scenes

starting at the mgh entrance. Giving detail to the building.



Instead of going to a random clothing store ji is escorted to a clothing store in MGH. they end up at Elos reccomended clothing place of choice. Still has the hadcore sloppy toppy quick and rough bj with him dumping a massive load into the thick lipped flirtatious goblin clothing store clerk.



They do some shopping for everyday supplies while they are on the first floor making their way to the receptionists area.



Goes through the afm mgh receptionist line. Sells his drops and mats obtained during the yesterdays start to his adventure.



He received a couple months of currency from selling most of his drops and mats.



When ji and elo are about to leave a bunny merchant high attendant politely stops them and ask that they come to the merchant guild masters room.



Elo already saw it coming since Ji is a high value man that ks had to told the guild master about but she also has ears and money all over town.



As they are escorted upstairs ji gets a nice view of some grade a bunny ass.

## AI
# Chapter 9, Scene Beat 1 — Generation Prompt (Target: 1500 words)

**Style directives:** Past tense, General English spelling, active voice, show-don't-tell, dialogue-driven pacing, no adverb-heavy prose, no "said" avoidance issues (skip tags where action conveys speaker). Mix short punchy lines with longer descriptive ones. Ecchi content should read as confident, lucky-pervert energy — John never chases, things simply happen to him. Physical texture matters: spit, grip, fabric, stone, skin-on-skin contact all deserve sensory beats, not summary.

---

## Scene 1: The Argent Bourse Entrance (150 words)

Open on John and Elowen approaching the Bourse exterior. Ground the reader in the granite colonnade, the CEL-veined stone, the silver lion statues with crystal eyes. Contrast this with the Adventure Guild's wooden warmth — Elowen can make a quick comment about the difference. Establish plaza scale on entry: glass dome, fountain, market ring noise. Keep dialogue light, teasing — Elowen warns John not to gawk at the lions like a tourist. End the scene moving toward the market ring, Elowen already steering him somewhere specific.

**Dialogue beat:** Elowen mocks his height compared to the pillars, or teases his tendency to gawk. Something character-establishing and low-stakes.

---

## Scene 2: Nettle & Thread — The Goblin Clerk (500 words)

This is the primary ecchi set piece. Build it in clear beats:

1. **Arrival** — Elowen names the shop specifically as her go-to recommendation ("cheap, fast, won't rob you blind"). Physical description of the goblin clerk: green skin, exaggerated plum-painted lips, posture draped over the counter, immediate eye contact with John that reads as hungry rather than professional.
2. **The dismissal** — Goblin sends Elowen off to browse belts/accessories under the guise of "measuring" John properly. Elowen complies without suspicion — she's socially naive, takes things literally, per her character sheet.
3. **Escalation** — No slow buildup. Goblin drops to her knees fast, tape measure abandoned, and goes straight for his trousers. Physical texture: her thick lips, exaggerated stretch around his girth, immediate sloppy noise — spit, gagging, drool bridging mouth to tip on a pull-back. She should be vocal, delighted by her own mess rather than embarrassed. Keep pacing quick and rough, not romantic — this is a hardcore, fast, transactional-but-eager encounter, over in a matter of minutes.
4. **Comedic contrast** — Cut a beat back to Elowen still browsing belts, oblivious, humming to herself ten feet away. Reinforce the "lucky pervert gets away with it" tone — nobody catches him, nothing has consequences.
5. **Climax and payoff** — John finishes down her throat; she swallows through it, some spilling onto her chin/apron regardless. She should own the mess rather than apologize for it — grinning, wiping her chin, straight back into professional tailor mode like nothing happened ("Now let's get you sized properly").
6. **Exit line** — Quick invitation to return, delivered like a business courtesy despite what just happened. John and Elowen leave with actual purchased clothes and a receipt that "mentions none of what else got paid for."

**Dialogue anchors:**
- Goblin: something flirtatious and immediate on his entry ("Vale Vanguard doesn't usually bring me the pretty ones.")
- Goblin: dismissive line to Elowen sending her off shopping.
- John: one or two reactive lines during the act — kept short, breathless, no purple prose.
- Goblin: closing invitation line, delivered with zero shame.

---

## Scene 3: Ground Floor Shopping Montage (200 words)

Quick transitional beat — not a full scene, more texture and pacing relief after the intensity of Scene 2. Cover mundane errands: soap, whetstone, rope, dried rations. Use this to develop Elowen's haggling personality — she treats bartering like combat, competitive and proud of small victories. Keep it light and fast, almost listy in delivery, a few lines of dialogue max. This scene exists to breathe and to characterize Elowen through a non-combat lens.

**Dialogue beat:** Elowen defends her haggling obsession ("It's the only puzzle I'm any good at.")

---

## Scene 4: AFM Reception Line — Selling Drops (300 words)

Move to the reception counter. Establish the AFM privilege lane — males skip the general queue, clerks eager to process him first (worldbuilding reinforcement without lecturing). John dumps his mats/drops from the previous day's dungeon run onto the counter. Clerk reacts with visible enthusiasm at the CEL fragments. Establish the payout: roughly two months' stipend from the haul, paid into a coin pouch on the spot.

Use this scene to reinforce the "lucky" theme — his first outing already nets him serious money, and he barely had to try.

**Dialogue beat:** Exchange between John and Elowen about who did the actual work ("You did the diving. I mostly stood there looking useful." / "You stood there very well.")

---

## Scene 5: The Bunny Attendant's Summons (250 words)

As they're about to exit, a bunny-eared Consortium attendant politely intercepts them. Polite, rehearsed phrasing — she's been sent, not improvising. Request: Guild Master wants a brief audience upstairs.

Elowen's reaction should signal she anticipated this — not surprised, slightly resigned, a knowing comment about Kaela's loose lips and the Bourse's networks of "ears in every wall and coin in every pocket." This reinforces worldbuilding (KS already informed the merchant guild about John's value) without exposition-dumping — let Elowen state it conversationally.

**Dialogue beat:**
- Attendant's polite request line.
- Elowen's muttered aside about Kaela and the guild's gossip network.
- John's light joke question ("Should I be worried?") and Elowen's flat reassurance ("No. Just don't be rude.")

---

## Scene 6: The Staircase Ascent (100 words)

Closing beat — short, visual, comedic capper. As the attendant leads them upstairs, John gets an eyeful of her figure on the stairs ahead of him. Physical texture: uniform fabric, sway, silver trim catching light. Elowen calls him out directly for staring, and he deflects with a lightly cheeky line. End the scene beat on this exchange — no need to continue into the Guild Master's office, that begins the next beat.

**Dialogue anchor (closing lines):**
- Elowen: "You're staring."
- John: deflecting joke response.
- Elowen: dry rebuttal.

---

**Total scene count:** 6
**Target distribution:** Scene 2 carries the heaviest word count as the primary ecchi set piece; Scenes 3 and 6 stay lean as connective/comedic tissue; Scenes 4 and 5 carry plot-forward worldbuilding and setup for the next chapter beat (Guild Master meeting).

---
type: location
name: The Argent Bourse
color: green
aliases:
  - merchant guildhall
  - Argent
  - Bourse
  - MGH
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Codex Entry: The Argent Bourse — Architectural Aesthetics



**Classification:** Merchant Guild Hall & Trade Complex

**Location:** Merchant's Ring District, Silverbrook City



---



## Exterior Aesthetics



The Argent Bourse rejects the warm, grain-and-lantern glow of the Adventure Guild across the city and replaces it with something colder, harder, deliberately impressive. The building rises four storeys from a wide granite plinth, its footprint nearly square, corners rounded rather than sharp so that the CEL veining running through the stone can trace unbroken lines from foundation to roof without interruption. Up close, the exterior stone reads as a pale dove-grey, almost silver in direct sun, quarried from a single vein in the Moonstone Hills chosen specifically for its density of natural Celestium thread. The Consortium didn't build with this stone by accident—they spent eleven years and a small fortune sourcing enough matching granite to clad an entire building without a single visible seam of mismatched colour.



The CEL veins themselves run in slow, branching patterns across every wall, thicker near ground level and tapering as they climb, like frost creeping up glass in reverse. By day they're barely visible, a faint blue-white shimmer beneath the stone's surface. By night, the building becomes a landmark visible from half the district—every vein glowing in soft synchronised pulse, brightest at the base, dimming toward the roofline, giving the whole structure the appearance of something quietly breathing.



The roofline itself breaks from the flat, functional lines below it. A shallow-domed glass ceiling crowns the plaza beneath, its curve supported by black iron ribwork forged in a radiating sunburst pattern, each panel of glass a slightly different tint of pale blue so that sunlight scatters through in soft prismatic fragments rather than a single flat wash. At night, the dome glows from within like a second moon set into the district skyline, visible even from the Silver Bourse Tree's uppermost platforms.



The main entrance sits recessed beneath a deep colonnade of six fluted granite pillars, each easily thirty feet tall, their surfaces polished to a near-mirror sheen. The two seated lion statues flanking the archway are cast from genuine silver-argent alloy rather than painted stone, weathered to a soft grey patina everywhere except their CEL-crystal eyes, which someone in the maintenance guild polishes weekly to keep the "watching" effect sharp. Above them, the founding relief is carved in deep bas-relief rather than shallow etching, deliberately lit from below by a row of ground-set CEL lamps so the seven trading houses seem to loom rather than merely decorate.



Wide steps of the same pale granite lead up to the entrance from street level, worn smooth in a narrower path down the centre where decades of foot traffic have concentrated, flanked by untouched stone at the edges—a visible record of exactly how many people walk this building's centre line rather than its margins.



---



## Interior Aesthetics — Ground Floor Plaza



Stepping through the entrance arch, the temperature itself seems to shift—cooler, cleaner, the air carrying a faint mineral crispness that locals half-jokingly call "vault breath." The plaza's scale hits immediately: three full storeys of open air above, capped by the glass dome, the space so large that voices from the far side of the fountain reach the entrance only as texture, not words.



The floor is a masterwork of concentric inlay—pale stone rings alternating with bands of darker charcoal granite, each ring subdivided by thin brass strips that catch the dome light and throw faint gold lines across the floor like a compass rose stretched to building scale. At the exact centre, the bronze founder's fountain sits atop a raised marble dais, water running in a continuous silver sheet down Argent Voss's cast bronze arms into the overflowing bowl below, the basin's rim inlaid with actual small-denomination coins sealed under clear resin—donated, tradition says, by every merchant who's ever closed a deal within these walls.



The market stalls ringing the outer floor break the plaza's cold formality with deliberate colour—striped awnings in a dozen competing trade-house hues, hanging silk banners, lantern strings threaded between kiosk poles. It's the one part of the building where the Consortium allows visual chaos, because chaos here means commerce, and commerce is the entire point.



The reception counter's crescent of black stone sits polished to the point of reflection, cool under the palm, its surface inlaid with a single unbroken line of silver script running its length—the Consortium's founding charter, rendered too small to read at a glance but perfectly legible up close, a detail most visitors never notice until a clerk points it out.



---



## Interior Aesthetics — Gallery Levels (Second & Third Floors)



Ascending past the plaza, the architecture tightens and warms. The central well cuts straight up through both gallery floors, ringed by brass balcony railings polished to a warm gold rather than the ground floor's cool silver, softening the transition from commerce-hall to something closer to a jeweller's showroom. Sunlight from the dome above filters down through the well in a soft diffuse column, catching dust motes and the occasional drift of incense smoke from a shop below.



Shopfronts along both galleries are individually dressed by their owners within Consortium guidelines, creating a patchwork of competing aesthetics that somehow reads as cohesive rather than cluttered—dark lacquered wood beside pale stone beside gleaming CEL-lit glass, each storefront a small architectural statement of its owner's trade and rank. The stone floor here softens into warmer beige tones, inlaid with directional veining that subtly guides foot traffic toward the well's centre rather than the outer walls, a deliberate design choice that keeps buyers moving past every stall.



Ceiling height on these floors runs lower and more intimate than the plaza, lit by recessed CEL panels set into shallow coffered squares, each panel dimmable by the shop beneath it—giving individual merchants control over their own pool of light, a small luxury tied directly to rank.



---



## Interior Aesthetics — Fourth Floor Ledger Hall



The mall atmosphere vanishes the instant the stairwell checkpoint clears. Carpet replaces stone underfoot for the first time in the building, a deep charcoal weave threaded with faint silver filament that catches light without demanding attention. The CEL veining in these walls burns a richer, deeper blue than anywhere below, selected during construction for saturation density, giving the corridors a permanent twilight glow even at midday.



Where the lower floors favour open sightlines and loud colour, the fourth floor favours weight and shadow. Doorways are deep-set, frames carved from dark imported hardwood rather than the building's usual stone or Silverwood, each door fitted with brass hardware gone dark with age and deliberate lack of polish—wealth here doesn't need to shine, it simply needs to be understood. The Round Table chamber's domed section allows a narrow shaft of dome-light down from the plaza's glass ceiling far above, a single beam that crosses the room slowly through the day like a sundial, timed by original design so it falls directly across the table's centre at local noon.



---



## Interior Aesthetics — The Vault Basement



Descending past the final checkpoint, all warmth disappears. The CEL-laced stone here isn't veined—it's saturated, poured solid with Celestium suspended through the entire structure rather than threading across a surface. The walls hold a faint, constant blue-white glow with no discernible light source, the stone itself luminous rather than lit. There are no windows, no wood, no soft materials of any kind—every surface is stone, metal, or reinforced glass, chosen because none of them burn, bend, or bribe.



The air carries a faint electrical taste, sharp at the back of the throat, and sound behaves strangely down here—footsteps land flat and dead against CEL-dense stone that refuses to carry an echo, a deliberate acoustic property that makes eavesdropping functionally impossible. Vault doors are unadorned slabs of dark alloy, seams so tight they read as solid blocks until the mechanism cycles, and even then they open with a low, heavy sound rather than a dramatic groan—engineered quiet, like everything else about the building's deepest floor.
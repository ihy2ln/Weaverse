---
type: location
name: Veridian
color: red
aliases:
  - Veridian
  - VDN
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# **Planetary Sheet: Veridian (VDN)**



## **Basic Information**



- **Name:** Veridian (VDN)

- **Tier:** Basal Veil (Tier 1 - Bottom of Adams Haven)

- **Size:** 10x Jupiter's mass

- **Theme:** Slice-of-life sitcom/drama world with modern CEL conveniences

- **Total Population:** 16 billion

- **Atmospheric CEL Density:** 5-15% (lowest in Adams Haven)

- **Gender Ratio:** 1 male : 10,000 females



---



## **Demographic Breakdown**



- **Humans (WAHB):** 99.8% (15.968 billion)

- **Males:** 0.01% (1.6 million - AFO protected)

- **CEL-A Users:** 60% baseline (F-E Rank majority; 2-4x human enhancements)

- **GKOM-A Infected:** <0.1% (F-D Rank; 2-15x human capabilities)



**Note:** Higher CEL/GKOM saturation increases strength, speed, intelligence - no supernatural powers. C-Rank ceiling (15x maximum).



---



## **Eight Continents**



### 1. **Cascade Shores** (3.5B pop)



- **Ecology:** Temperate coastal - Mediterranean climate, seaside cliffs, vineyard valleys, cherry blossom forests

- **Theme:** Urban waterfront sprawl; café romance culture

- **Major Cities:** Prism Bay (80M) - neon coastal metropolis; Sunset Heights (55M) - hillside bookstore city; Harbor's Edge (35M) - historic port boardwalks

- **Culture:** Coffee shop dates, cherry blossom festivals, workplace rom-coms, beach romance



### 2. **Verdant Cradle** (2.8B pop)



- **Ecology:** Tropical/subtropical - rainforests, coral reefs, volcanic islands, pristine beaches

- **Theme:** Resort paradise; island community sitcoms

- **Major Cities:** Crystal Cove (40M) - beach resort network; Emerald Canopy (25M) - jungle treehouse city; Tidepool Metroplex (30M) - underwater domes

- **Culture:** Beach parties, surfing competitions, tropical romance, island hopping adventures



### 3. **Silken Plains** (2.2B pop)



- **Ecology:** Temperate grassland - endless prairies, sunflower fields, river deltas

- **Theme:** Suburban sprawl; family sitcom central

- **Major Cities:** Wheatfield Central (50M) - suburban mega-district; Riverside Commons (38M) - small-town aesthetics; Golden Horizon (28M) - university campus town

- **Culture:** High school dramas, family dinners, mall culture, Friday night football, prom romance



### 4. **Frostpeak Ranges** (1.8B pop)



- **Ecology:** Mountain/alpine - snow peaks, hot spring valleys, glacial lakes, evergreen forests

- **Theme:** Ski resort slice-of-life; cozy lodge dramas

- **Major Cities:** Snowdrift Haven (20M) - year-round ski metropolis; Thermal Springs (15M) - bathhouse culture; Evergreen Heights (18M) - cable car networks

- **Culture:** Ski lodge romance, winter sports, hot spring relaxation, holiday magic, cabin dramas



### 5. **Amber Wastes** (1.5B pop)



- **Ecology:** Arid/desert - sand seas, sandstone canyons, oasis networks, mesa formations

- **Theme:** Tight-knit community dramas; generational stories

- **Major Cities:** Dune's Crown (22M) - oasis bazaar city; Canyon's Reach (16M) - cliff-face architecture; Mirage Plaza (12M) - underground cooling networks

- **Culture:** Bazaar haggling, sunset camel rides, oasis festivals, desert stargazing, storytelling traditions



### 6. **Sapphire Archipelago** (1.2B pop)



- **Ecology:** Island chains - volcanic islands, coral atolls, turquoise lagoons, white sand beaches

- **Theme:** Island-hopping adventures; fishing village sitcoms

- **Major Cities:** Coral Crown (10M) - inter-island bridge network; Lagoon's Rest (8M) - floating city sectors; Starfish Bay (9M) - underwater viewing domes

- **Culture:** Island festivals, fishing boat families, beach weddings, diving adventures, tropical romance



### 7. **Ironwood Realm** (2B pop)



- **Ecology:** Temperate deciduous - hardwood forests, autumn foliage, misty valleys, woodland lakes

- **Theme:** Cozy cabin slice-of-life; mystery dramas

- **Major Cities:** Maple's End (18M) - treehouse districts; Fogwood Central (24M) - misty valley metropolis; Redleaf Harbor (14M) - lakeside boat culture

- **Culture:** Cabin getaway romance, mystery book clubs, autumn harvest festivals, forest hiking, cozy sweater aesthetics



### 8. **Monsoon Deltas** (1B pop)



- **Ecology:** River delta/wetlands - mangrove forests, rice paddies, floating markets

- **Theme:** Water-based slice-of-life; seasonal festivals

- **Major Cities:** Delta's Heart (12M) - floating stilt city; Rainflow Commons (10M) - canal gondola culture; Lotus Bay (8M) - rice paddy tourism

- **Culture:** Floating markets, houseboat families, monsoon festivals, canal romance, water lantern ceremonies



---



## **Technology Level**



**Modern Earth + CEL Quality-of-Life:**



- **Transportation:** Electric vehicles, mag-lev trains, silent transit, ferry networks, cable cars

- **Communication:** Smartphones, holographic displays, streaming dominance

- **Energy:** CEL-core reactors (clean unlimited power)

- **Healthcare:** Modern medicine + CEL healing (240-270 year lifespans)

- **Housing:** Smart homes with climate control, water purification

- **Entertainment:** VR gaming cafes, immersive theaters, holographic concerts



**No Combat Tech:** Weapons limited to law enforcement; CEL for convenience only.



---



## **GKOM Manifestation**



GKOM corruption manifests exclusively through human evil—serial killers with F-E Rank enhancements (2-4x strength/speed) operate undetected, terrorist cells organize mass attacks with enhanced coordination, and D-Rank corrupt politicians (8-15x cunning) manipulate governance while cult leaders use persuasive abilities to gather violent followers.



---



## **Culture**



- **Entertainment:** Rom-coms, workplace comedies, family dramas, school stories, mystery sitcoms dominate media

- **Festivals:** Media conventions, seasonal celebrations, beach parties, winter carnivals, harvest gatherings

- **Venues:** Gaming cafes, karaoke bars, cinema complexes, concert halls, theater districts

- **Religion:** Light Amara worship; daily gratitude, male protection prayers

- **Social Norms:** WAHM casual sexuality; tsundere/kuudere/yandere relationship dynamics common



---



## **Government**



**Matriarchal Democracy:** Women occupy all positions; AFO Bureaus ensure male safety/luxury/reproductive scheduling; continental parliaments coordinate through VDN Supreme Council; GKOM Task Forces hunt hidden threats.



**Political Factions:** Traditionalists (family values), Progressives (personal freedom), Protectionists (extreme male security)



---



## **Economy**



- **Industries:** Media production, tech manufacturing, hospitality, tourism, retail, agriculture

- **Trade:** Electronics, entertainment media, fashion, gaming hardware, luxury goods, specialty crops

- **Male Economy:** AFO stipends ($500k/month); exempt from labor

- **Model:** Post-scarcity basics via CEL; thriving luxury/entertainment markets



---



## **Capital: Unity Central** (Cascade Shores - 65M pop)



Sprawling metropolis housing VDN Supreme Council and AFO Planetary Headquarters; features Male Sanctuary Towers (luxury high-rises with 24/7 security), Entertainment Quarter (theaters, gaming cafes, studios), Commerce Sprawl (endless shopping/dining), and GKOM Task Force HQ.



---



## **Current Challenges**



- **Hidden GKOM Threats:** Serial killers/terrorists operate undetected creating public paranoia

- **Political Corruption:** GKOM-infected officials manipulating government systems

- **Gender Ratio Tensions:** 1:10,000 scarcity fuels fierce romantic competition and social drama

- **CEL Limitation:** Low atmospheric density caps enhancement potential; emigration desires grow

- **Detection Paranoia:** GKOM users blend seamlessly; civilian witch-hunt fears escalate



---



## **GKOM Examples**



The "Cascade Phantom" (F-Rank, 2x strength) evades capture for three years; "Crimson Dawn Cult" (E-Rank leader, 4x persuasion) orchestrates continental attacks; Senator Vex (D-Rank, 10x cunning) controls legislative votes through blackmail.



---



## **Summary**



Veridian is Adams Haven's baseline tier—a Jupiter-scale world where slice-of-life dramas unfold across eight diverse continents amid subtle CEL enhancement and hidden GKOM corruption. No superpowers exist, only enhanced human capabilities driving romantic comedies in coastal cafés, family sitcoms in prairie suburbs, mystery dramas in misty forests, and beach romance across tropical paradises. CEL technology provides modern comfort while the 1:10,000 gender ratio fuels endless romantic drama. GKOM evil wears smiling faces until violence erupts beneath the cheerful surface.



*"Where ordinary life shimmers with subtle power—and evil wears a smile."*



---



*Tier 1 Basal Veil | CEL: 5-15% | 16B Population | 8 Continents*
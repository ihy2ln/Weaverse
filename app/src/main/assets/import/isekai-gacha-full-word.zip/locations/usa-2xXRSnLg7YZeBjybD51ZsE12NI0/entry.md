---
type: location
name: USA
color: brown
aliases:
  - USA
  - UNITED STATES ASTEROID
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Basic Information**



- **Name:** United States Asteroid Cluster (USA)

- **Location:** The Harmonized Expanse (TTN), near Veridian orbital plane

- **Size:** 56 state/territory asteroids ranging from continental to sub-planetary scale

- **Total Population:** 50 billion

- **Gender Ratio:** 90% Female / 10% Male (5 billion males - highest concentration in TTN)

- **Theme:** Advanced modern civilization reliant on Quirk abilities and Celestium energy, fighting perpetual biological collapse



---



### **Demographics & Structure**



**Population Breakdown:**



- 95% Enhanced/Baseline Humans (40% ZZV survivors Beta-Omega level)

- 2% Mutants (extreme Quirk manifestations)

- 3% GKOM monsters and ZZV zombies (constant threat)



**Cluster Organization:**

State-asteroids orbit in regional mega-formations connected by fortified Celestium-seam networks. Major city-asteroids orbit parent states, each housing 500 million to 5 billion inhabitants. CEL-seams provide breathable atmosphere and normalized gravity.



---



### **Major Asteroids**



**Empire Orb (New York):** 6 billion population. Moon-sized vertical metropolis with 50-mile skyward construction. Houses Supreme Hero Command and highest Omega-level concentration. Central Spire serves as governmental and military nerve center.



**Golden State Expanse (California):** 10 billion population. Mars-sized, most diverse terrain. Pacific Bastion (4 billion) serves as western command. Highest Hero per-capita and most frequent ZZV outbreaks. Major Celestium mining operations.



**Lone Star Domain (Texas):** 8 billion population. Semi-autonomous operation with independent Hero networks. Widest buffer zones and most dangerous uncontrolled territories. Frequent cluster-wide ZZV emergencies.



**Iron Sphere (Midwest Coalition):** 5 billion across 12 interconnected asteroids. Primary Celestium refining and weapons manufacturing hub. Densest transit network, constant monster/Villain attacks.



---



### **Capital: Fortified Zone Alpha**



Located in Empire Orb's central spire. Population: 700 million (capital district). Vertical fortress extending to orbital platforms. Houses Supreme Hero Command utilizing moon-sized Celestium War Rooms, Grand Quirk Registry (cataloging 20+ billion Quirks), and Central Bio-Research Complex.



**Government:** Democratic republic heavily centralized under Joint Hero Command. Ultimate authority shared between Hero Agencies, Omega survivors, and Celestium corporations. Mandatory Quirk registration enforced cluster-wide.



---



### **GKOM Threats**



**Monster Variants:**



- **Flesh Grafts (FZ):** Building-sized amalgamations with corrupted Quirks

- **Shriekers (MZ):** Pack hunters with sonic abilities, groups of 20-100

- **Apex Strains (AZ):** Intelligent variants seeking Celestium sources, require Omega-tier Hero teams



**ZZV Crisis:** Unpredictable outbreaks affecting millions. Radiance strain creates F-Omega tiered zombies with non-decaying pale skin and glowing red eyes. Higher tiers retain intelligence and original GKOM abilities.



---



### **Society & Culture**



**Social Dynamics:** The Hedonistic Reversal normalizes open sexuality and competition for males. Enhanced women display power and resources to attract partners. Society stratified by Enhancement level, Quirk potency, and Celestium access.



**Economy:** Credits backed by Celestium reserves. Major industries: Celestium extraction/refining, defense manufacturing, agricultural mega-farms, Quirk-enhancement R&D, male management services (breeding programs, luxury accommodations).



**Technology:** Early 21st century baseline evolved through Quirk/Celestium integration. Celestium reactors power cities and defense grids. Support gear amplifies Quirks. Medical nanites enable rapid healing and cellular modification.



**Culture:** Festivals celebrate survival milestones and Hero achievements. Entertainment includes holo-dramas, Quirk exhibitions, and underground fight clubs. Religious practices range from traditional faiths to Omega worship and Celestium reverence.



---



### **Current Challenges**



- **ZZV Outbreaks:** Constant, unpredictable events requiring massive Hero mobilization

- **Monster Evolution:** Apex Strains showing coordination and Celestium-seeking behavior

- **Villain Syndicates:** Omega-level criminals controlling black markets, illicit Celestium, and male trafficking

- **Resource Strain:** Supporting 50 billion requires constant expansion

- **Political Tensions:** Federal vs. state autonomy, Agency conflicts, Enhanced vs. civilian power dynamics

- **Inter-Cluster Relations:** Protecting valuable male population from external TTN interest



**Defense:** Millions of Pro-Heroes across thousands of Agencies, federal military, automated Celestium barrier networks, AI weapon platforms, and rapid deployment protocols.
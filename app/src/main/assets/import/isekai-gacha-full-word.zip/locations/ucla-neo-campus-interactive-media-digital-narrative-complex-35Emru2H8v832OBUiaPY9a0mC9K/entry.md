---
type: location
name: UCLA Neo-Campus – Interactive Media & Digital Narrative Complex
color: brown
aliases:
  - Video game main building
  - UCLAGB
  - UCLA GB
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# **UCLA Neo-Campus – Interactive Media & Digital Narrative Complex**



*Elite AAA-Developer-Scale Building — Video Game, CGI & Digital Media Production Hub*



**Aliases:** Video Game Main Building, UCLA GB



**Total Size:** 6 floors at approximately **182,000 sq ft each** (~1.1 million sq ft total footprint), plus a full holodeck-dominated basement and recreational roof deck



**Status:** Premier learning facility for electronic media, videogame development, and CGI production in the USA Cluster. Doubles as California's primary venue for showcasing media-based tech projects to corporate boards, Hero Agency liaisons, and government contract representatives.



---



### **Exterior & Scale**



The building didn't so much rise as sprawl upward and outward at once, six floors stacked at a footprint large enough that students joked about needing a shuttle pass just to get from the north entrance to the south. **CEL-infused glass curtain walls** wrapped the exterior in long, uninterrupted sheets, shifting a faint blue-grey depending on ambient Celestium saturation, while **low-grade CEL-infused metal framing** ran the vertical seams between floors, dull silver by day and amber-warm at dusk. **Reclaimed timber cladding** softened the scale, wrapping support columns thick enough to hide a person behind and window frames that ran the length of a city block.



Multiple entrance plazas dotted the perimeter — north, south, and a smaller service entrance off the east loading docks — each paved in **CEL-veined stone** that pulsed faint light under foot traffic. Banners for the term's showcase draped from the fourth-floor overhang, three storeys of promo art advertising whatever student-built world had won the semester pitch.



---



### **Ground Floor – Main Hall, Mech Mall & Convention Space (~182,000 sq ft)**



The ground floor functioned as a small campus in itself. **Security checkpoints** ringed every entrance, a rotating detail of a dozen guards minimum spread across four separate stations, biometric scanners built into **CEL-infused metal archways** humming low with every badge clear.



Past the checkpoints, the **Mech Mall** stretched out like a proper concourse — rows of vendor stalls selling haptic rigs, neural-lace headsets, and Support Gear peripherals, a full diagnostic bay for busted VR gloves, and enough foot traffic that the floor had its own directional signage painted into the polished concrete. Greeting kiosks and a long bank of **meeting rooms** ran the length of the western wing, glass-walled and soundproofed, booked solid most weeks with corporate scouts. A separate cluster of **AFM emergency rooms** sat spaced along both wings, close enough that no point on the floor was more than a two-minute walk from one.



The showpiece remained the **Grand Holodeck**, a projection chamber tall enough to punch through the ceiling into the second floor, giving conventions and thesis showcases room to render full-scale environments. The **convention hall** wrapping it sat tiered for 2,000, hosting the twice-yearly Governor's Tech Exhibition alongside weekly student pitch sessions. Six separate elevator banks and four stairwells serviced the floor, spread wide enough that students rarely waited more than a minute for a car.



---



### **Second Floor – Holodeck Overflow & Collaborative Studios (~182,000 sq ft)**



The second floor absorbed the upper half of the Grand Holodeck's shaft, ringed by a wraparound mezzanine where students watched demos through **CEL-glass railings**. Beyond that, the floor opened into a genuinely vast collaborative zone — dozens of modular studio pods clustered by project team, a scattering of mid-sized holodeck chambers for group iteration work, and enough open floor between them that the space felt more like an indoor plaza than an office.



Breakrooms and cafeteria satellites dotted the floor at regular intervals rather than one central hub, each stocked with vending walls, a coffee bar, and a nap alcove nobody admitted to using as often as they did. Security ran lighter here, two roaming guards per quadrant, and **AFM emergency rooms** sat positioned at every quadrant's centre.



---



### **Third Floor – Undergraduate Studios (~182,000 sq ft)**



First of the three school floors, dedicated entirely to undergraduate coursework, and large enough to house the entire undergraduate cohort without anyone feeling cramped. Rows upon rows of **workstation pods** filled the open floor plan in loose grids, six-person clusters under warm pendant lighting, each cluster paired with its own small holodeck booth for solo iteration work — dozens of them scattered floor-wide rather than centralised.



A full **cafeteria wing** occupied the northern third of the floor, big enough to seat a thousand at once, and a second smaller breakroom sat tucked into the southern corner for anyone who didn't want the noise. **AFM emergency rooms** were spaced every few hundred feet along the main corridors, staffed around the clock. Multiple elevator banks and stairwells cut through the floor at intervals, keeping travel time low despite the size.



---



### **Fourth Floor – Graduate Production Studios (~182,000 sq ft)**



Graduate-level work took the fourth floor, and the extra square footage went almost entirely into holodeck density — dozens of chambers ranging from tight solo booths to full team-sized environments, reflecting the scale of thesis-level projects. **Motion capture bays** ran the length of the western third of the floor, a whole row of sprung-floor stages with rail-mounted camera rigs, each one soundproofed from its neighbours. Security presence thinned to roaming pairs per section, campus badge access the primary gate past that point. Breakrooms and a mid-sized cafeteria satellite broke up the studio space every few hundred yards.



---



### **Fifth Floor – Doctoral & Advanced Research (~182,000 sq ft)**



The top school floor, reserved for doctoral candidates and advanced research tracks, felt almost sparse by comparison despite the identical footprint — fewer workstations, more private studio suites spread generously apart, and a scattering of the building's most sophisticated holodeck chambers, full environmental simulation rigs used for dissertation defence and government-adjacent research demos. Breakrooms here skewed quiet, leather couches instead of stacking chairs, spread across several smaller lounges rather than one central hub. **AFM emergency rooms** remained standard, spaced at the same intervals as every floor below.



---



### **Sixth Floor – Administration (~182,000 sq ft)**



Faculty offices, the Dean's suite, records, and grant administration filled the sixth floor, though the sheer scale meant entire wings sat dedicated to functions most students never saw — archive storage, legal review for corporate contracts, a dedicated wing just for NDA-bound research paperwork. Glass-walled offices looked out over the quad from every angle the floor's perimeter offered. A handful of smaller holodecks served faculty demo reviews, and security focused less on crowd control and more on document integrity, badge-gated at every wing transition.



---



### **Roof – Recreational Deck**



The roof matched the floors below in scale, a genuine park stretched across the building's full footprint. **Wooden boardwalks** wound between raised garden beds, multiple half-courts for pickup basketball, long rows of hammocks strung between CEL-lit posts, and several open-air lounges spaced far enough apart that finding a quiet corner never took long. Views stretched clean across North Campus toward Royce Hall's towers, and on clear nights half the graduate cohort ended up up there anyway, laptops open, working under the stars instead of the fluorescents below.



---



### **Basement – Restricted Access**



Clearance-gated below the ground floor and matching the full footprint above, the basement ran almost entirely as **one continuous holodeck chamber**, the largest in the building by a wide margin, reserved for government and corporate contract projects under active NDA. A cluster of **high-tech labs** ringed the chamber's perimeter, and a set of **AFM bunkers** sat at the rear, reinforced shelter space built specifically around male student and staff protection protocols, stocked and sealed, tested quarterly. Access required clearance beyond standard campus badges, and the guard detail down here didn't rotate off during finals week the way the upper floors did.
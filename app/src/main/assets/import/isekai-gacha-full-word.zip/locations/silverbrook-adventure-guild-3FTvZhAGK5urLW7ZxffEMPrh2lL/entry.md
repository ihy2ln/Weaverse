---
type: location
name: Silverbrook Adventure Guild
color: green
aliases:
  - SAG
  - adventure guild
  - SBC AG
  - ag
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Codex Entry: Silverbrook Adventure Guild



**Classification:** Major Regional Guild Hall

**Location:** Silverbrook Settlement, Eastern Edge of Silverwood Forest

**Affiliation:** Continental Adventure Guild Network



---



## Overview



The Silverbrook Adventure Guild stands as the settlement's most imposing structure—three storeys of ancient Silverwood timber and Celestium-veined marble that predates half the town around it. Every beam came from trees no axe would touch today, felled before the Moonstrider harvesting accords locked the old-growth forest down. The exterior combines rough-hewn Silverwood planks with pale marble quarried from the Moonstone Hills, the natural Celestium threads giving the stone a faint inner pulse after dark. A continuous glass lantern caps the roofline, flooding the interior with daylight. Above the entrance, a carved relief depicts an ancient Silverwood sheltering seven founding adventurer classes. The guild crest—silver tree on dark marble—is inlaid in Celestium tile at the threshold, worn smooth by decades of boots, still glowing.



---



## Main Hallway



The building's spine. Wide enough for six abreast, running the full depth of the ground floor from entrance to rear courtyard. A vaulted glass panel runs its entire ceiling length. Silverwood columns carved from single trunks line both sides. The floor is pale Celestium-veined marble with Silverwood inlay strips between slabs. All major ground floor rooms open off this corridor through wide Silverwood double doors with glass panel inserts. Quest notices cover the boards mounted between columns, updated each morning. A grand staircase at the hallway's midpoint—framed by carved Silverwood balustrade—connects all three floors. A rear service stair handles staff and supply movement.



---



## Ground Floor — Public Level



**Access:** All ranks, general public.



**Reception Hall** — A long curved Silverwood counter staffed at all hours. Behind it, floor-to-ceiling pigeonhole filing holds active member dossiers, quest assignments, and correspondence. Celestium-stone panels set between exposed beams cast steady ambient light. A reinforced glass window at the counter's end handles all financial transactions separately.



**Quest Board Room** — The building's loudest space. Three walls of layered cork and Silverwood panels display active quests sorted by rank, region, and urgency, tagged white for open, amber for claimed, red for critical. Central reading tables hold reference maps and dungeon records. A clerk station manages sign-outs—no posting leaves the board without a signature.



**Guild Store** — Standard adventuring supplies, basic healing compounds, tools, rope, and torches alongside guild-sourced Silverwood equipment and Celestium-grade materials at premium pricing. A locked case behind the counter holds restricted items requiring rank verification.



**Eatery** — Open from before dawn to late evening. Heavy Silverwood tables, long bench seating, a kitchen that produces straightforward substantial food at fair prices. The eatery connects directly to the main hallway and to a rear service entrance for deliveries. A short bar runs along one wall serving ale, cider, and hot drinks. The room fills at dawn with departing parties and again at dusk with returning ones.



---



## Second Floor — Operations Level



**Access:** Registered members, mid-rank and above.



Quieter than the ground floor. The staircase opens onto a carpeted landing with the same Silverwood and marble aesthetic carried upward. Natural light comes through large arched forest-glass windows and the hallway's upper glass panel.



**Rest Quarters** — Private and shared rooms for members on extended contracts or recovering between assignments. Furnishings are plain but quality—Silverwood frames, good mattresses, lockable storage. Shared washrooms at each corridor end.



**Meeting Rooms** — Four medium-sized rooms used for party briefings, contract negotiations with clients, and inter-guild correspondence meetings. Each holds a central table, chairs, and a wall-mounted map bracket. Soundproofed with layered Silverwood panelling.



**Mid-Rank Lounge** — A common room for C-rank and above. Comfortable chairs, a reading collection of dungeon records and regional surveys, and a small service bar. The one room on this floor with a view directly into the forest through an oversized glass panel.



---



## Third Floor — Restricted Level



**Access:** A-rank members, Guild Master, Vice Guild Master, invited guests only.



The Celestium-veined marble grows richer here—the stone was selected for highest thread density, giving the walls a continuous soft luminescence that needs no additional lamp support during daylight. The glass ceiling panel reaches its full width on this floor, making the space feel open despite the closed-door nature of everything that happens inside it.



**Guild Master's Office** — Corner position, maximum sightlines. Large Silverwood desk, document vault, a private meeting table seating six. The only room in the building with direct access to the roof observation platform above.



**Vice Guild Master's Office** — Adjacent, connected by an internal door. Mirrors the Guild Master's layout at slightly reduced scale.



**High Council Chamber** — The floor's centrepiece. A circular room with a round Celestium-inlaid table, twelve seats, and a domed glass ceiling section that sits directly under the roofline lantern. Used for rank promotions, major contract negotiations, crisis briefings, and inter-guild summits.



**A-Rank Lounge** — Sparse, private, well-appointed. A place to debrief after high-difficulty assignments without the noise of the floors below.



---



## Basement — Functional Core



**Access:** Staff, recruits, detainees, authorised personnel.



Stone-walled, lit entirely by Celestium-panel lighting recessed into the ceiling. Cooler than the floors above. The basement handles everything the public-facing building cannot.



**Training Hall** — The largest basement space. Open floor, reinforced walls, weapon racks, padded impact zones, and suspended target frames. Used for applicant assessments, active member conditioning, and rank-up physical trials.



**Testing Chamber** — Separated from the training hall by a heavy Silverwood door. Controlled environment for ability evaluation, dungeon simulation exercises, and formal rank examination. Observation slot in the door for assessors.



**Recruitment Office** — Where new applicants are processed, interviewed, and assigned provisional status. Bare and deliberate—no decoration, no comfort. The guild does not soften first impressions here.



**Holding Cells** — Four stone cells with iron-reinforced Silverwood doors. Used for detaining members who breach guild law, dangerous captures awaiting transfer, or individuals held pending provincial authority handover. A duty guard post sits opposite the cell block at all hours.
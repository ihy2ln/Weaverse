---
type: location
name: Heroica
color: pink
aliases: []
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# # **Updated Codex: Heroica**



## **Basic Information**



- **Name:** Heroica

- **Size:** 16 times the size of Jupiter (approximately 200,000 km in diameter, a colossal terrestrial megaworld supporting vast, diverse biomes)

- **Theme:** Superhero

- **Total Population:** Approximately 500 billion (scaled to planetary mass, with dense urban megacities and sprawling wilderness areas for heroic training)

- **Moons:** 2 (Luna Major and Luna Minor, used as orbital hero academies and watchtowers)

- **Position:** 3rd planet in the Adams Haven Solar System

- **Universal Context:** As one of the Five Jewels of Adams Haven, Heroica shares the system's foundational crises: the **Gender Ratio (GR)** anomaly (one male born per 10,000 births) and the endemic **God Killer Of Men (GKOM)** virus. These have forged a matriarchal society under the **All for One (AFO)** legal framework, where males are revered deities of protection and propagation, granted opulent lives, immense wealth (100x global average stipend), and mandatory reproductive duties, while society operates on **Women of Adams Haven (WAH)** principles with enhanced women handling all labor and heroism.



## **Demographic Breakdown**



- **Humans:** 70% (mostly enhanced with innate GKOM Variant superpowers)

- **Mutants:** 15% (specialized evolution of human genetics, often GKOM survivors)

- **Enhanced Beings:** 10% (technologically or magically augmented via GKOM adaptations)

- **Cosmic Entities:** 3% (beings from other dimensions or cosmic origins, integrated into hero lore)

- **Others:** 2% (miscellaneous races and species, including minor alien refugees)

- **Gender Ratio (GR):** Strictly 10,000 females to 1 male, this universal constant since Adams Haven's dawn has created a matriarchal WAH society where males live in luxury enclaves, protected by elite female heroines who anticipate their every need under AFO mandates, with any harm punishable by execution. Female enhancements manifest as the natural **Celestium-Infused (CEL) body type**, a GKOM-driven biological integration of Celestium minerals into the physique; 80% of women exhibit baseline CEL (athletic, naturally enhanced builds with subtle curves for male allure), while 15% have moderate CEL (heightened strength and sensitivity), and a rare 5% possess high CEL (hyper-augmented, superhero-caliber forms with pronounced curves, explosive power, and WAHO orifices optimized for pleasure and propagation—making them Omega-level heroines coveted for both combat and devotion).



## **Major Continents**



The planet features four major continents arranged in a clover-like pattern, separated by vast oceans teeming with aquatic kaiju threats. Each reflects superhero archetypes, with WAH matriarchies running hero agencies and infrastructure, leaving males to inspire from afar.



### 1. **Novaris (West Continent - Marvel Parody)**



- **Size:** Approximately 50 billion square kilometers

- **Population:** 150 billion

- **Description:** A continent of technologically advanced megacities and mutant enclaves, where teams of CEL heroines battle cosmic incursions. WAH dynamics shine in communal harems around male "Prime Inspirers," with women handling patrols and rebuilds.

- **Major Cities:**



- **New Genesis:** Gleaming hub of innovation, where female engineers craft power suits for male oversight roles.

- **Mutant Haven:** Sanctuary for enhanced beings; CEL women train young heroines while pampering resident males.



- **Key Heroes/Organizations:**



- **The Alliance:** All-female core team of moderate/high-CEL survivors, sworn to protect male civilians.

- **X Academy:** Hero training ground emphasizing WAH devotion—students learn powers alongside reproductive ethics.



### 2. **Meridia (East Continent - DC Parody)**



- **Size:** Approximately 45 billion square kilometers

- **Population:** 160 billion

- **Description:** Iconic metropolises with godlike architecture and shadowy underbellies. Vigilante CEL women enforce AFO laws, ensuring no threat reaches male enclaves.

- **Major Cities:**



- **Metropolia:** "City of Tomorrow," patrolled by super-speed heroines; males enjoy skyline penthouses with devoted attendants.

- **Dark Haven:** Gritty noir district; female detectives use heightened empathy (WAH trait) to safeguard hidden male safehouses.



- **Key Heroes/Organizations:**



- **Justice Legion:** Elite squad of CEL paragons, their curves and powers a symbol of matriarchal might serving male legacy.

- **Dark Knights:** Shadowy network of WAH guardians, prioritizing male evacuation in crises.



### 3. **Azuron (North Continent - Manga/Anime Parody)**



- **Size:** Approximately 40 billion square kilometers

- **Population:** 100 billion

- **Description:** Eastern-inspired realms of dramatic academies and escalating battles. CEL heroines train relentlessly, their enhanced stamina (for both combat and intimacy) fueling WAH propagation efforts.

- **Major Cities:**



- **UA Metropolis:** Hero education epicenter; curricula include CEL physiology for optimal male companionship.

- **Titan City:** Battlefield against colossal foes; women clear debris while males observe from secure vantage.



- **Key Heroes/Organizations:**



- **Plus Ultra Academy:** Rigorous school blending superpowers with WAH nurturing skills.

- **Hero Association:** Bureaucratic body regulating female hero deployments, with male advisors holding veto power.



### 4. **Terravolt (South Continent - Sentai/Mecha Parody)**



- **Size:** Approximately 45 billion square kilometers

- **Population:** 90 billion

- **Description:** Mech-dominated industrial sprawl with color-coded teams. CEL pilots in form-fitting suits pilot giants, their WAHO adaptations ensuring post-battle "recharge" rituals honor male pilots or overseers.

- **Major Cities:**



- **Zord Central:** Mecha forge; female fabricators enhance gear while attending to male strategists.

- **Ranger City:** Team training hub; WAH sisterhoods form unbreakable bonds in service to rare males.



- **Key Heroes/Organizations:**



- **Cosmic Defenders:** Five-woman squad with combining mecha, embodying CEL unity.

- **Voltron Force:** Elite all-female pilots, their devotion extending to protecting planetary males.



## **GKOM Monster Variation & Integration**



- **GKOM Impact:** GKOM is the genesis of all superpowers on Heroica, awakening the "hero gene" at puberty while enforcing GR. Males (1% survivors) become Omega-Class icons with unpredictable might, their survival a divine lottery. Females (50% survivors) evolve into CEL body types—athletic powerhouses with enticing curves (plush hips, sensitive WAHO) tailored for male allure and protection, distributed by rarity: baseline for everyday WAH roles, moderate for standard heroics, and rare high-CEL for elite feats. WAH ideology drives them: women lead heroics, labor, and society, finding fulfillment in nurturing males through combat victories and intimate devotion. AFO mandates elite guards for males, with execution for any harm.

- **Types of GKOM Monsters (Post-Mortem Abominations):**



- **Kaiju Class:** Titanic beasts from ocean depths, twisted GKOM corpses rampaging until CEL teams intervene.

- **Symbiote Variants:** Parasitic horrors bonding hosts into villains; WAH heroines purge them to safeguard male bloodlines.

- **Dimensional Invaders:** Reality-warping entities breaching voids, often mimicking lost males to sow chaos.

- **Weekly Monsters:** Recurring threats on a broadcast-like schedule, "scripted" by GKOM's genre whimsy—cleared by rotating female squads.



## **Capital**



- **Name:** Unity City

- **Description:** Central megametropolis bridging continents, a fusion of architectural styles with AFO-spired male palaces at its heart. CEL women maintain its hyperloop networks and hero monuments.

- **Government Structure:** The Hero Council, an all-female WAH assembly of continent reps, consults rare male "Oracles" for guidance. Branches include Hero Regulation (female-led), Male Welfare (devoted attendants), and Propagation Oversight (fertility clinics).

- **Key Institutions:**



- **The Watchtower:** Orbital command for CEL sentinels monitoring GR threats.

- **Hall of Heroes:** Shrine glorifying male survivors as "Living Legends," with WAH tributes.

- **Crisis Command:** Emergency hub where women coordinate, ensuring males remain untouched.



## **Largest Cities**



- **New Genesis:** Population 100 billion; tech utopia with flying citadels, WAH women innovating for male leisure.

- **Metropolia:** Population 95 billion; art deco skyline, female vigilantes patrolling male luxury districts.

- **Zord Central:** Population 85 billion; industrial mecha heart, CEL workers building defenses.



## **Most Popular Locations**



- **The Arena of Champions:** Colossal stadium for hero exhibitions; males spectate from VIP thrones, inspired by CEL displays.

- **The Nexus Point:** Dimensional thin-spot; WAH guardians seal breaches to protect male enclaves.

- **Mount Olympus:** Mythic peak for power training; secluded retreats for male reflection, attended by devoted heroines.



## **History and Development**



- **Founding Events:** The First Emergence (GKOM's dawn) birthed powers amid GR collapse, leading to WAH matriarchies and AFO pacts.

- **Major Conflicts:** Villain Wars (anti-male radicals), Infinite Crises (GKOM surges), Kaiju Invasions (repelled by CEL legions).

- **Important Alliances:** Unity Accord, uniting female heroes under male reverence.



## **Culture**



- **Festivals:** Hero Day—WAH celebrations honoring males with parades of CEL prowess and fertility rites.

- **Entertainment:** Hero broadcasts, power rankings, and intimate "victory tales" glorifying male agency.

- **Religious Practices:** Worship of GKOM as "The Awakener," with males as divine vessels; WAH rituals emphasize female service.



## **Sociopolitical Structure**



- **Governance:** Continent-specific agencies under global WAH Hero Council; males hold symbolic, veto-wielding roles.

- **Political Groups:**



- **Power Registration Advocates:** Push for tracking CEL levels to bolster male protection.

- **Freedom Fighters:** Balance heroism with personal devotion to chosen males.

- **Propagation Coalition:** Focus on GR remedies via WAHO-optimized clinics.



## **Technology and Magic**



- **Technological Advancements:** Mecha exosuits amplifying CEL strength, neural links for WAH empathy, Celestium amplifiers.

- **Magical Elements:** GKOM-derived powers (e.g., energy blasts) intertwined with hero archetypes.

- **Integration:** Hybrid tech-magic suits tailored for female heroes, with male-input designs for pleasure and utility.



## **Economic Systems**



- **Hero Economy:** Females earn via sponsorships and stipends funding male luxuries; AFO provides universal male wealth.

- **Key Industries:** Power-tech, monster containment, fertility enhancements for CEL women.

- **Inter-Continental Trade:** Celestium and WAHO serums exchanged, bolstering GR efforts.



## **Language**



- **Primary Language:** Universal Hero Standard, with dialects; telepathic WAH bonds aid communication.



## **Transportation and Infrastructure**



- **Methods:** Teleport grids, CEL flight paths, male-exclusive luxury arks.

- **Major Projects:** Intercontinental Hero Railway, maintained by WAH labor.



## **Flaws and Chaos**



- **Social Issues:** GR tensions spark "Harem Wars" among CEL women; rarity of high-CEL creates envy and power disparities challenging WAH harmony.

- **Emerging Threats:** Evolving GKOM monsters resisting heroics; underground movements questioning male deification.

- **Villain Activities:** Syndicates exploiting CEL allure for anti-AFO plots.

- **Gender Imbalance:** WAH devotion creates complex dynamics—females prove worth beyond reproduction, yet compete intensely for male favor.



## **Current Challenges**



- **Villain Renaissance:** Coordinated assaults on male enclaves, repelled by unified CEL forces.

- **Monster Evolution:** GKOM abominations adapting to powers, demanding innovative WAH strategies.

- **Public Perception:** Collateral from battles strains AFO trust; calls for male-involved heroism rise.

- **Propagation Pressures:** Clinics push CEL enhancements, balancing heroism with GR duties, especially for the rare high-CEL elite.



## **Unique Features**



- **The Hedonistic Reversal:** CEL heroines, while battle-hardened, embody WAH sensuality—post-mission intimacies via WAHO reinforce male agency and societal bonds, with high-CEL rarity amplifying their desirability.

- **Weekly Monster Protocol:** Genre-scripted threats, cleared in episodic flair by female teams.

- **Power Classification System:** D-S ranks, with Omega for elite high-CEL females/males; ties to GR reverence.

- **Celestium Integration:** The mineral's core role in CEL body types boosts powers, often in WAHO-compatible artifacts for dual heroism and devotion, though high concentrations remain a 5% rarity.



## **Summary**



Heroica pulses with caped crusades amid Adams Haven's GR and GKOM shadows. CEL women, the WAH vanguard—from common baseline to rare high-CEL elites—wield superhuman might and alluring forms to shield and serve their cherished males, turning every crisis into a testament of devotion. In this jewel of heroism, power serves survival, and every victory echoes the sacred balance of protection and passion.
---
type: location
name: Major Cities of Mythoria
color: green
aliases: []
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
Certainly! Here’s an addition of the **8th city**, designated as the capital of **Mythoria**, with relevant details.



### Major Cities of Mythoria



1. **Valeria**

- **Location:** Situated in the heart of the Enchanted Forest, surrounded by bioluminescent flora.

- **Description:** Valeria is known for its vibrant arts and cultural festivals, held throughout the year. The architecture features living trees interwoven with homes and public spaces, creating a seamless blend with nature. The city reveres the spirits of the forest and celebrates nature with grand ceremonies.

- **Population:** Approximately 1 billion.



2. **Aetheria**

- **Location:** Perched atop the Mystic Mountains, high above the clouds.

- **Description:** Aetheria is renowned for its academies of magic and training grounds for aspiring sorceresses. The city is filled with floating platforms and towers made of crystal, allowing residents to harness the energies of the sky. Scholars and powerful mages often gather here to exchange knowledge, making it a center of intellectual activity.

- **Population:** Approximately 1 billion.



3. **Serafina**

- **Location:** Nestled within the Serene Valleys, bordered by fertile farmlands.

- **Description:** Known for its agricultural innovations, Serafina thrives on producing magical crops and herbs. The city features expansive gardens and marketplaces showcasing its bounty. Worship of the earth spirits is prevalent, with a temple dedicated to nurturing the land and celebrating seasonal harvests.

- **Population:** Approximately 1 billion.



4. **Lyonesse**

- **Location:** Located on the shores of the Crystal Lakes, with stunning views of the water.

- **Description:** Lyonesse is a maritime city celebrated for its underwater explorations and aquatic innovations. Its people are skilled navigators and traders, utilizing boats crafted with magic. Festivals of light are held during the lunar cycles, celebrating the connection between the moon and the water spirits.

- **Population:** Approximately 1 billion.



5. **Tenebris**

- **Location:** Concealed within the depths of the Whispering Woods, shrouded in mist.

- **Description:** Tenebris is a city known for its mystical heritage, drawing in knowledge seekers who wish to unravel the secrets of the ancients. The architecture typically features dark stone, ethereal lanterns, and twisting paths. Here, communities engage in deeper rituals to appease shadow spirits and navigate the balance between light and dark.

- **Population:** Approximately 1 billion.



6. **Elysian Harbor**

- **Location:** A coastal city that opens to the vast ocean, dotted with cliffs and coves.

- **Description:** Elysian Harbor is a bustling trade hub where goods from all over Mythoria converge. Known for its vibrant markets and diverse population, the city thrives on commerce, blending cultures and traditions. The grand lighthouse stands as a guardian for ships, said to be imbued with protective enchantments.

- **Population:** Approximately 1 billion.



7. **Argentum**

- **Location:** In the mountainous region where rivers converge, leading to breathtaking waterfalls.

- **Description:** Argentum is famed for its mining operations and as a center for crafting magical artifacts. The city incorporates shimmering silver into its architecture, reflecting the light of the terrain. Artisans in Argentum are highly regarded for their skills in creating enchanted weaponry and jewelry.

- **Population:** Approximately 1 billion.



8. **Elysium Prime (Capital)**

- **Location:** Centrally located in Mythoria, spanning an area equivalent to that of Australia.

- **Description:** Elysium Prime, the capital city, serves as the political and cultural heart of Mythoria. Its sprawling territory incorporates grand palaces, administrative halls, and lush gardens representing the unity of all clans. The city is a melting pot of cultures, featuring halls of governance where the Council of Elders convenes, along with academies that explore advanced magical practices and philosophical discourse. Festivals that represent the entire continent are held here, making it a vibrant center of celebration.

- **Population:** Approximately 4 billion.
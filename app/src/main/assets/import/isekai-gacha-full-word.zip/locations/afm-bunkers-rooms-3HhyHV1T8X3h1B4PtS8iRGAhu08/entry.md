---
type: location
name: AFM Bunkers/Rooms
color: brown
aliases:
  - AFM Bunker
  - AFM Room
  - AFMB
  - AFMR
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# **CODEX: AFM Bunkers/Rooms – California Emergency Shelter Standard**



*Male Protection Infrastructure — Emergency Containment & Life Support*



**Classification:** Tier-variable defensive structure, F through S rating, stationed across every major facility in California under AFM mandate



**Found In:** Hospitals, corporate towers, university buildings (UCLA GB basement among thousands), transit hubs, the Breeding Crown complex, and any structure housing male population above threshold density



---



### **Construction**



Every AFM bunker started with the same bones — **high-grade CEL-encased walls**, poured thick enough that a Flesh Graft could throw itself against the surface a dozen times before the lattice even registered stress fatigue. Unlike the low-grade CEL framing that ran through the rest of a building's structure, bunker walls used **saturated-core plating**, dense enough to shift colour under load, a faint amber bloom crawling across the surface whenever the material absorbed an impact. Techs called it "the bruise" — the wall telling you exactly how hard something outside had tried to get in.



Every facility in the state ran a mix of tiers depending on budget, population density, and risk profile. A community college might get by on F and E-tier rooms scattered through its buildings. A place like UCLA GB, or anywhere housing significant male population, stocked the higher end of the scale as standard.



---



### **Tier Classification**



**Tier**

**Size**

**Configuration**

**Notes**



**F-Tier**

30 sq ft

Single holodeck room, no sub-zones

Barely room to stand and turn around; sanitation and sleep functions share the same footprint, fold-away when not in use



**E-Tier**

100 sq ft

Single room, basic partition

Sleep nook curtained off from the fabricator/toilet corner



**D-Tier**

300 sq ft

Two-zone layout

Separate sleep and sanitation, small fabricator alcove



**C-Tier**

750 sq ft

Small-house configuration

Multiple distinct rooms — sleep, sanitation, small common area, dedicated fabricator kitchen



**B-Tier**

1,100 sq ft

Multi-room, expanded common space

Adds a secondary holding room, upgraded holodeck rendering fidelity



**A-Tier**

1,300 sq ft

Full residential layout

Private sleep suite, separate bathroom, lounge zone, high-output fabricator



**S-Tier**

1,500 sq ft

Luxury penthouse configuration

Multiple sleeping suites, full kitchen-grade fabricator array, private lounge and holodeck theatre zone, finishes that read more like a hotel suite than a shelter



Facility placement generally scaled tier to who might need the room. A random hallway unit near a lecture hall ran F or E-tier — enough to keep someone alive for an hour until Heroes cleared the floor. Basement-level bunkers tied to dense male housing, or facilities flagged as high-value targets, carried B-tier and up, sometimes a scattering of S-tier units reserved for VIPs or long-duration lockdown scenarios.



---



### **Holodeck Integration**



The walls did more than hold. Every bunker above F-tier carried **CEL-infused holodeck lattice** woven directly into the plating, letting the interior render as almost any environment on command. A panicked evacuation didn't have to mean staring at bare grey walls for six hours — the room could shift to a beach at dusk, a quiet library, a childhood bedroom, whatever kept a mind from fraying during lockdown. Higher tiers carried sharper rendering fidelity; an S-tier bunker could hold a fully convincing illusion for days without the flicker or texture-pop lower tiers suffered past the twelve-hour mark.



Techs on rotation joked that you could tell how bad an outbreak got by what the bunkers rendered afterward — quiet requests for beaches during minor lockdowns, and a lot more requests for "off" during the bad ones, guys just wanting to see the real walls and know exactly how thick they were.



---



### **Life Support Amenities**



A bunker wasn't a hole to hide in. It was built to keep someone alive and functional for however long a siege ran, which on a bad week in Desert Crown could stretch past 72 hours. Amenity depth scaled directly with tier.



- **Sleeping quarters:** Fold-out at F through D-tier, dedicated suites from C-tier up, multiple private rooms at A and S-tier

- **Sanitation:** Full toilet and shower fixtures from D-tier upward (F and E-tier make do with a compact unit fixture), self-contained water recycling loop so the unit never depends on outside plumbing during lockdown

- **Water & food storage:** Refrigeration units stocked on a rolling basis, never left to run empty, checked weekly by facility staff — capacity scales from single-day supply at F-tier to multi-week reserves at S-tier

- **Food fabricators:** CEL-powered synthesis units capable of producing basic nutrition from raw stock at low tiers, scaling to full kitchen-grade output with genuine flavour fidelity at A and S-tier

- **Air processing:** Independent scrubber system, sealed tight enough to run without an outside atmosphere feed for the bunker's rated duration, longer duration ratings the higher the tier



---



### **Standard Protocol**



Quarterly testing kept every unit rated and logged — seal integrity, fabricator output, holodeck rendering stability, all checked and signed off before the next quarter's drill. Nobody wanted to find out a bunker's water recycler had failed halfway through an actual Omega-tier breach, so the testing schedule ran non-negotiable across every facility in the state, from the smallest F-tier closet unit to the sprawling S-tier suites reserved for the highest-value residents.



Guard rotations for bunker-adjacent corridors never went dark, not even during finals week, not even during the quietest stretch of the semester. The reasoning stayed simple enough that nobody bothered restating it out loud anymore — the bunkers existed because the men inside them were worth more than the building around them.
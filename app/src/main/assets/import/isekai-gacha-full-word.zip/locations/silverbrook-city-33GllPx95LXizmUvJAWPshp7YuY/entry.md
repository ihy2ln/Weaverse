---
type: location
name: Silverbrook City
color: green
aliases:
  - SBC
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Codex Entry: Silverbrook Haven - District Organization**



#### **District System Overview**



**Urban Layout:**



- **Seven Districts:** Each centered around one major guild and supporting businesses

- **Great Tree Hub:** 400-500 ft ancient silverwood at each district core

- **Radial Design:** Districts form interconnected rings around city center

- **Guild-Led Governance:** Each district managed by its dominant guild



---



#### **The Seven Districts**



1. **Canopy District - The Argent Spire Tree**

- **Dominant Guild:** Silvershield Adventurers Guild

- **Primary Businesses:** Dungeon supply shops, weapon smithies, armorers

- **Key Features:** Guild recruitment center, bounty boards, training grounds

- **Great Tree:** 450-ft "Argent Spire" with integrated combat arenas

- **Notable:** Hosts annual Grand Delver Tournament



2. **Guildgrove District - The Artisan's Heart Tree**

- **Dominant Guild:** Moonstone Crafters League

- **Primary Businesses:** Enchanting studios, magical workshops, artisan galleries

- **Key Features:** Master craftschool, material exchange, innovation labs

- **Great Tree:** 420-ft "Artisan's Heart" with floating workshops

- **Notable:** Source of city's magical infrastructure development



3. **Merchant's Ring District - The Silver Bourse Tree**

- **Dominant Guild:** Argent Merchants Consortium

- **Primary Businesses:** Trading houses, auction halls, luxury goods

- **Key Features:** Central marketplace, banking institutions, trade embassy

- **Great Tree:** 480-ft "Silver Bourse" with rotating market platforms

- **Notable:** Controls 80% of magic silver commerce



4. **Scholar's Canopy District - The Loreroot Tree**

- **Dominant Guild:** Arcane Collegium

- **Primary Businesses:** Spell component shops, libraries, research facilities

- **Key Features:** Great Library, alchemy labs, scrying chambers

- **Great Tree:** 400-ft "Loreroot" with living archives

- **Notable:** Houses oldest known silverwood lore



5. **Wardens' Stand District - The Sentinel Tree**

- **Dominant Guild:** Rootwarden Rangers

- **Primary Businesses:** Security services, mapping outlets, guide services

- **Key Features:** Defense command, forest monitoring, emergency response

- **Great Tree:** 460-ft "Sentinel" with observation decks

- **Notable:** Coordinates variant threat response



6. **Hearthstone District - The Hearthwood Tree**

- **Dominant Guild:** Hospitality & Service Guild

- **Primary Businesses:** Inns, restaurants, entertainment venues

- **Key Features:** Cultural center, healing services, residential services

- **Great Tree:** 380-ft "Hearthwood" with public gardens

- **Notable:** Center of city's social life



7. **Rootgate District - The Gateway Tree**

- **Dominant Guild:** Transport & Logistics Guild

- **Primary Businesses:** Courier services, stables, portal maintenance

- **Key Features:** Main gates, customs office, transit hub

- **Great Tree:** 420-ft "Gateway" with integrated teleportation circles

- **Notable:** First contact point for newcomers



---



#### **District Infrastructure**



**Shared Features:**



- **Aqueduct Connection:** Each Great Tree connects to main silverwater conduits

- **Vertical Transportation:** Spiral staircases and levitation platforms

- **Defensive Systems:** District-specific ward networks

- **Commerce Flow:** Magic silver distribution regulated per district needs



**Guild Responsibilities:**



- Maintain district security and infrastructure

- Manage magic silver allocation for their sector

- Provide specialized services to city population

- Train apprentices in guild specialties



---



#### **Economic Ecosystem**



**Inter-District Trade:**



- Adventurers supply materials to Crafters

- Crafters create goods for Merchants

- Merchants fund Scholar research

- Scholars develop defenses for Wardens

- Wardens protect Transport routes

- Transport enables Hospitality services

- Hospitality supports Adventurers



**Magic Silver Distribution:**



- **Adventurers:** 25% (dungeon operations)

- **Crafters:** 20% (manufacturing)

- **Merchants:** 15% (trade enhancement)

- **Scholars:** 15% (research)

- **Wardens:** 10% (defense)

- **Transport:** 8% (logistics)

- **Hospitality:** 7% (public services)



---



#### **Cultural Significance**



**District Identities:**



- Residents often identify strongly with their district's guild

- Inter-district rivalries balanced by council oversight

- Each district has unique festivals and traditions

- Guild membership often hereditary within districts



**Notable Events:**



- **Canopy District:** Grand Delver's Melee (monthly)

- **Guildgrove:** Artisan's Exhibition (quarterly)

- **Merchant's Ring:** Silver Market Festival (annual)

- **Scholar's Canopy:** Lorelight Symposium (biannual)

- **Wardens' Stand:** Sentinel's Vigil (weekly)

- **Hearthstone:** Hearthfire Celebration (seasonal)

- **Rootgate:** Gateway Gathering (daily newcomer orientation)



---



#### **Strategic Organization**



**Defense Coordination:**



- Each district maintains its guard contingent

- Wardens' Stand coordinates city-wide defense

- Great Trees serve as emergency shelters

- Aqueduct system provides emergency communication



**Expansion Plans:**



- **Proposed 8th District:** "Deeproot" for underground exploration

- **Western Expansion:** Additional districts along forest edge

- **Vertical Growth:** Expanding upward within existing Great Trees



---



**City Planner's Note:**



*"Seven districts, seven guilds, one city. Each tree stands as testament to our unity amid specialization. The silverwater flows through all, connecting our purposes as it powers our dreams."* — City Architect Lyra Mistral



**Current Status:** Districts operating at 92% capacity, inter-guild cooperation rated "exceptionally strong" by Council assessment
---
type: location
name: The Harmonized Expanse
color: gray
aliases:
  - TTN
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
The Harmonized Expanse**



#### *"Ten Thousand Nations, Ten Thousand Nightmares"*



---



### **Overview**



A sprawling asteroid belt containing **thousands of sovereign nation-asteroids**, each a self-contained civilization linked by glowing **Celestium Border-Seams (CEL-Seams)**. This cosmic tapestry serves as the primary **interplanetary highway** connecting the Five Jewels of Adams Haven.



- **Creation:**



- **Amara's Design:** The Goddess restructured the shattered cradle-world into a functional mosaic—nations separated by culture, united by necessity.

- **Perfect Dissection:** Countries, states, cities, and provinces were **surgically divided** along political borders, preserving terrain, infrastructure, and ecosystems.



- **CEL-Seam Technology:**



- **Atmosphere Generation:** Thick Celestium borders create **breathable air pockets** around each asteroid.

- **Normalized Gravity:** 1G standard across all habitable asteroids, regardless of mass.

- **Climate Stabilization:** CEL-cores regulate weather, preventing extreme conditions.



---



### **Structure & Navigation**



#### 1. **The Belt's Anatomy**



- **Helical Formation:** Snakes through the system in a **double-helix orbit**, passing near all Five Jewels at different intervals.

- **Cluster Organization:**



- Related nations orbit **near each other** (e.g., *Liberty States* asteroids form a constellation).

- City-asteroids orbit their parent nation-asteroids like moons.



#### 2. **Transit System**



- **Amber Roads:** Reinforced CEL-pathways with **variable gravity assist**—ships ride gravitational currents between planets.

- **Public Transport:**



- **CEL-Trams:** Pressurized tubes connecting adjacent asteroids.

- **Void-Ferries:** Large passenger vessels following established routes.



- **Private Travel:**



- **Thrust-Pods:** Personal single-occupant craft.

- **Leviathan Cruisers:** Luxury liners with artificial ecosystems.



---



### **Society & Culture**



#### **Unified Characteristics**



- **Peaceful Coexistence:** No wars between nations—resources are abundant, trade is free-flowing.

- **WAH Doctrine:** Universal adherence to male protection and reverence.

- **Modern+ Technology:** Contemporary baseline enhanced by **CEL-integration**:



- Smart-homes with gravity-adjustable floors.

- Holographic communication spanning asteroid-chains.

- Automated defense grids against GKOM variants.



#### **Cultural Diversity**



- **Real-World Parodies:**



- *Liberty Mandate* (USA) - 50 state-asteroids including *New Cascadia*, *Lone Star Haven*, *Empire City*.

- *The Jade Sphere* (China) - Province-asteroids with vertical mega-farms.

- *Nordic Crown* (Scandinavia) - Fjord-carved asteroids with geothermal spas.

- *Nippon Arc* (Japan) - Neon-lit metropolitan asteroids and rural temple-villages.



- **Original Fictional Nations:**



- *Aethermoor Republic* - Steampunk-aesthetic industrial asteroids.

- *Crystalia Dominion* - Glass-spired cities with light-refracting architecture.

- *Verdant Confederacy* - Bio-dome agricultural paradise.

- *Ember Sultanate* - Desert-themed asteroids with bazaar-districts.



---



### **GKOM Variants: The Folklore Horrors**



Each asteroid develops **unique GKOM variants** based on its cultural fears and legends. Post-mortem transformations manifest as **living nightmares** from horror cinema and folklore.



#### **Variant Categories**



**Urban-Type Variants:**



- **Slashers** (*Liberty Mandate*): Silent killers with bladed limbs, hunt in abandoned subways.

- **Pale Children** (*Nippon Arc*): Child-sized variants with reversed joints, mimic lost loved ones.

- **Hook-Hands** (*Coastal Nations*): Nautical-themed hunters emerging from water-asteroids.



**Rural-Type Variants:**



- **Scarecrow Stalkers** (*Agricultural Nations*): Straw-stuffed corpses animated by GKOM, impale victims on pitchforks.

- **Wendigos** (*Nordic Crown*): Emaciated, antlered predators that spread frost-blight.

- **La Llorona Wraiths** (*Southern Asteroids*): Weeping female variants that drown victims in phantom water.



**Folklore-Specific Variants:**



- **Baba Yaga Husks** (*Slavic Nations*): Grotesque crone-forms dwelling in mobile structures.

- **Kuchisake-onna** (*Nippon Arc*): Masked female variants asking riddles before attacking.

- **Jersey Devils** (*Liberty Mandate - Garden State*): Winged, hooved abominations.



**Classic Horror Variants:**



- **Chainsaw Brutes** (*Industrial Asteroids*): Hulking variants wielding salvaged power tools.

- **Doll-Mimics** (*Residential Districts*): Porcelain-skinned variants that replace children.

- **Puzzle-Killers** (*Mystery-Cult Nations*): Intelligent variants that trap victims in death-games.



---



### **Notable Asteroids**



Asteroid Name

Parody Origin

Population

Unique Feature

GKOM Variant



**Empire City**

New York

20 million

Vertical metropolis with sky-bridges

Subway Slashers



**Neo-Tokyo Orb**

Tokyo

35 million

Rotating districts, neon-soaked streets

Pale Children



**Vice Spire**

Miami

8 million

Gravity-inverted party districts

Hook-Hands



**Crystalia Prime**

Original

5 million

Transparent architecture, light gardens

Mirror-Doppelgangers



**Lone Star Haven**

Texas

12 million

CEL-cattle ranches, open plains

Scarecrow Stalkers



**Frostholm**

Original (Nordic)

3 million

Perpetual aurora, ice-sculpted cities

Wendigos



---



### **Technology Integration**



#### **Defense Systems**



- **CEL-Barriers:** Energy shields activated during variant outbreaks.

- **Auto-Turrets:** AI-guided weapons mounted on asteroid perimeters.

- **Hunter Squads:** WAHB-enhanced female teams with specialized anti-variant gear.



#### **Daily Life Tech**



- **Gravity Elevators:** Vertical transport using CEL-regulated fields.

- **Holo-Markets:** Virtual shopping with physical CEL-fabrication delivery.

- **Climate Shells:** Personal force-fields for void-walks between asteroids.



---



### **Economic Systems**



- **Trade Goods:**



- **Terrain Resources:** Desert sand, mountain minerals, ocean water-ice.

- **Cultural Exports:** Art, entertainment, cuisine unique to each nation.

- **CEL-Tech:** Refined Celestium components and devices.



- **Currency:** **Gleams** (universal digital currency backed by Celestium reserves).



---



### **Current Challenges**



- **Variant Evolution:** Some GKOM monsters show **increased intelligence**, forming hunting packs.

- **CEL-Seam Maintenance:** Occasional border failures require emergency repairs.

- **Population Pressure:** GR crisis means constant expansion into new asteroid-territories.

- **Transit Bottlenecks:** Peak travel seasons create dangerous congestion near planetary approaches.



---



### **Mysteries**



- **The Silent Grid:** A cluster of 13 asteroids that **emit no signals**—exploration teams never return.

- **Variant Convergence:** Reports of different folklore monsters **merging** into hybrid abominations.

- **The First Fragment:** Legends speak of an **original asteroid** from which all others split—its location unknown.
---
type: location
name: Silverwood Forest
color: green
aliases:
  - SBF
tags:
  - Location
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Codex Entry: Silverwood Forest**



#### **Basic Information**



- **Name:** Silverwood Forest

- **Classification:** Ancient Magical Wilderness

- **Location:** Western Eldrenwood Continent, Crystalmere Province

- **Nearest Settlement:** Silverbrook Settlement (eastern edge)

- **Other Bordering Towns:** Misthaven (north), Glimmerfell (southwest)



---



#### **Geographical Scope**



- **Circumference:** ~1,200 miles

- **Area:** ~115,000 square miles

- **Length:** 380 miles north-south

- **Width:** 300 miles east-west

- **Elevation Range:** 200 ft (southern flats) to 4,500 ft (northwestern foothills)



---



#### **Topographical Features**



**Primary Terrain:**



- Dense old-growth magical forest covering 85% of area

- **Silverthread Lakes:** Chain of 7 glacial-fed lakes along western edge

- **Moonstone Hills:** Rolling magical quartz formations in central region

- **Whispering Caves:** Extensive limestone cave systems throughout

- **Silvervein Plateau:** Elevated northwestern region near mountains



**Notable Clearings:**



- **Sunstone Glade:** Largest clearing (3 miles across), nomadic tribal gathering site

- **Lunar Meadow:** Permanent settlement of Moonstrider nomads

- **Starlight Basin:** Natural amphitheater used for celestial rituals



---



#### **Floral Characteristics**



**Dominant Species:**



- **Silverwood Trees:** Ancient specimens reach 350 ft height, bark develops metallic silver sheen

- **Redwood Variants:** Magically enhanced cousins of earthly redwoods

- **Lunar Cypress:** Blue-tinged conifers that glow during full moons

- **Starlight Willows:** Trees with crystalline leaves that chime in wind



**Silverwood Tree Maturation:**



- **Sapling Stage:** 0-50 years (normal tree appearance)

- **Adolescent:** 50-100 years (begins silver sap production)

- **Mature:** 100-500 years (full magical silver properties)

- **Ancient:** 500+ years (becomes semi-sentient, bark becomes actual silver)



---



#### **Resources & Hazards**



**Valuable Resources:**



- Silverwood sap (magical catalyst)

- Moonpetal flowers (healing properties)

- Starfall mushrooms (enhance night vision)

- Silverbark (natural armor material)



**GKOM Variants Present:**



- **Silver Shamblers:** Tree-like humanoids with metallic skin

- **Moonlight Stalkers:** Predators that blend with silverwood bark

- **Sap Drinker:** Corpse-pale humanoids that drain magical energy

- **Bark Skin:** Berserkers with silverwood armor fused to flesh



---



#### **Dungeon Distribution**



**Tier 1 (Near SBS):**



- **Whispering Root Cave:** 1 hour hike (small)

- **Silvervein Mine:** 3 hours hike (small-medium)

- **Moonfall Grotto:** 5 hours hike (medium)



**Tier 2 (1-2 Days In):**



- **Starlight Crypt:** 1 day march (medium-large)

- **Silver Temple:** 2 days hike (large)

- **Ancient Root Network:** 2 days (massive complex)



**Tier 3 (Deep Wilderness):**



- **Silverwood Heart:** 1 week travel (legendary)

- **Moonstone Citadel:** 2 weeks northwest (mythic)

- **Starlight Nexus:** Location unknown (theoretical)



---



#### **Nomadic Tribes**



**Documented Groups:**



- **Moonstriders:** Silverwood worshippers, protect ancient trees

- **Starblessed:** Celestial magic practitioners, dwell in high clearings

- **Earth Whisperers:** Cave dwellers, mine magical crystals

- **Silver Hunters:** Trophy hunters of GKOM variants



---



#### **Unexplored Regions**



**Known Unknowns:**



- **The Silver Sea:** Central region where trees form continuous canopy

- **Crystal Depths:** Unexplored cave systems beneath northwestern plateau

- **Starfall Basin:** Magnetic anomaly area preventing magical navigation

- **Ancient Grove:** Where oldest Silverwoods are rumored to commune



---



**Warning to Travelers:**



*"The Silverwood gives life and takes it in equal measure. Respect the ancient trees, avoid the silver-eyed things, and never travel alone after dark. The forest remembers those who take without giving back."* — Last entry from Explorer Kaelen's journal



**Current Status:** 60% unexplored, increasing GKOM variant activity during full moons
---
type: location
name: Adams Haven
color: gray
aliases:
  - AH
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# **Adams Haven: The Five-Tier Veil Realms**



## 🌌 **Cosmic Rebirth by Amara**



The goddess **Amara, the Alluring Empress**, sundered the primordial cradle-world into **five Jewel Planets**, elevating each to a sovereign **existential tier** within the **Veil Realms**. This divine stratification isolates **GKOM corruption gradients** while cascading pure **CEL** downward from the apex.



- **Core Purpose:** Combat the **GVC (GKOM vs CEL)** war—GKOM (entropy/dark) dominates lows, CEL (harmony/light) purifies highs—while upholding **GR** (1 male:10,000 females) and **WAH** devotion across all.

- **Tier Exclusivity:** realms focus on core jewels: VDN → EV → Heroica → NP → SA.

- **Access Rule:** **CEL-A Integration %** gates entry (air CEL density lethal to underprepared). Insufficient saturation causes overload (neural burnout/death).



Each tier is **encircled by TTN shells**—Celestium asteroid veils providing transit, filtration, and buffers. **TTN floats tier-agnostically** but **mirrors local planet's CEL/GKOM balance** (e.g., TTN around Tier 1 = low CEL/high GKOM). It enables **up/down travel** for integrated travelers.



---



## **Tier Hierarchy**



Tier

Realm Name

Jewel Planet

CEL Air Density

Min. CEL Integration Req.

Power Ceiling

GKOM Threat

Theme/Essence



**1**

**Basal Veil**

Veridian (VDN)

5-15%

F-Rank (5%)

C-Rank

High (80%)

Human baseline/urban slice-life



**2**

**Arcane Mantle**

Elysium Vale (EV)

20-35%

E-Rank (10%)

B/S-Rank

Medium-High (65%)

High fantasy/magic realms



**3**

**Heroic Crucible**

Heroica (H)

35-55%

D-Rank (15%)

A-Rank

Medium (50%)

Superhero epics/battles



**4**

**Nexus Crown**

Nexara Prime (NP)

55-80%

C-Rank (25%)

SR/SSR-Rank

Low (30%)

Game-logic archipelagos



**5**

**Aurelian Apex**

Serenity Atoll (SA) / Primordia Core

85-100%

B/A-Rank+ (35-50%+)

Ω+ (Godlike)

Negligible (<5%)

Divine purity/creation paradise



### **Tier Survival & Progression**



- **CEL Overload Effects:**

Higher the tier difference the dense CEL count it's. Can easily overload the user leading to headaches to even death.

---



## 🌠 **TTN: The Encircling & Transitional Veil**



**The Harmonized Expanse (TTN)** manifests as **concentric asteroid shells** around *each tier's Jewel Planet*, forming a seamless web:



- **Local Role (Per-Tier):** Mirrors host tier's CEL/GKOM (e.g., Tier 1 TTN = sparse CEL, Folklore Horrors rampant). Provides air/gravity, trade hubs, WAH enclaves.

- **Inter-Tier Role:** **Star Veils** radiate between shells, enabling fluid up/down travel.



- **TTN Mechanics:**



- **No Fixed Tier:** Dynamically adapts (e.g., Tier 1-2 bridge = ~15% CEL hybrid).

- **GKOM Filter:** Binds corruption; dead males spawn tier-blended Husks (e.g., EV Fantasy Slashers).

- **CEL Pipeline:** Apex flows pure shards downward, fueling lower economies.

- **WAH Hubs:** Male sanctuaries; AFO luxuries scale with shell tier.

- **Threats:** Maw corrupts seams → **Veil Rifts** (GKOM floods upward).
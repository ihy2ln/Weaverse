---
type: location
name: fixer upper
color: null
aliases:
  - fixer upper
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
Item Designation: The Sandcastle

Location: A secluded 1990s-era beach bungalow located on a private lot along the Miami, Florida coastline.

Status: The property was abandoned for decades with minimal upkeep due to a complex legal dispute stemming from a now-deceased elderly celebrity divorce. While structurally sound, the home's systems and interior require a complete modernization. There is no significant mold or rot, but fixtures are outdated and general neglect is evident. The property is currently sealed and awaiting settlement by the celebrity's estate.

Structure: The home features a sprawling, open-concept floor plan connecting the main living area, kitchen, and dining room. It includes three bedrooms, two bathrooms, and a single-car garage.

Unique Features: The house is defined by its bold architectural use of glass. Instead of conventional walls, most of the exterior consists of floor-to-ceiling glass panels, with additional skylights in the roof. This design, while once offering breathtaking ocean views and abundant natural light, is the primary source of the extensive water damage from years of neglect, making its restoration a significant challenge.
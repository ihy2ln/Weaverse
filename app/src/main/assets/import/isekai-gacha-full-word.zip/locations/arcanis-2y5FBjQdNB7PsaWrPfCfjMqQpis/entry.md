---
type: location
name: Arcanis
color: green
aliases:
  - Arcanis
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
G### Basic Demographics



- **Size:** 1.5 million square miles

- **Population:** 1.5 billion

- **Theme:** Magical Academic Realm

- **Gender Ratio:** 1 male : 10 females post-GKOM



### Major Cities



1. **Celestia:**



- Population: 800,000

- Floating capital city

- Headquarters of Grand Arcane Academy

- Ruled by Queen Althea



2. **Verdantia:**



- Population: 500,000

- Magical botanical research center

- Living forest-integrated architecture

- Known for magical agriculture and healing sciences



3. **Umbrathor:**



- Population: 200,000

- Center of shadow and forbidden magical research

- Darker magical disciplines practiced

- Controversial magical experiments conducted



### World Wonders



1. **The Eternal Spire:**



- Infinite magical tower that constantly reshapes itself

- Changes internal architecture based on magical user's intentions

- Serves as primary magical research facility



2. **Crystal Resonance Nexus:**



- Massive crystalline structure that amplifies and stores magical energy

- Generates power for entire continent

- Can be seen from hundreds of miles away, constantly shifting colors



3. **Quantum Library of Arcana:**



- Living library where books are sentient and can communicate

- Contains every magical text ever written

- Rooms and knowledge dynamically shift based on researcher's magical affinity



4. **The Aetherwood:**
   - A vast, ancient forest located just a few hours south of Celestia.
   - Its canopy is so thick little light reaches the forest floor.
   - Renowned for harboring high-tier magical beasts and monsters.
   - A rich source of extremely rare and powerful natural magical materials, sought by high-level mages and crafters despite its inherent dangers.
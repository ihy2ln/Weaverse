---
type: location
name: Mythoria
color: green
aliases:
  - Mythoria
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
## **Mythoria Overview**



### General Information

- **Theme:** An advanced high fantasy society drawing inspiration from ancient myths and legends.

- **Size:** Comparable to Earth, with diverse landscapes embodying various myths.

- **Inhabitants:** A blend of humans, mythical creatures, and clones of legendary figures, coexisting in harmony.



### Geography

- **Landscapes:**

- **Enchanted Forests:** Diverse ecosystems with bioluminescent plants, inhabited by fairies and other magical creatures.

- **Mystic Mountains:** Towering peaks with floating islands, home to ancient temples and wise sages. These mountains are often veiled in magical mist.

- **Serene Valleys:** Rich lands, known as the Fields of Harmony, where agricultural and magical practices merge, producing bountiful crops with enhanced properties.

- **Crystal Lakes:** Bodies of water that reflect the cosmos, rumored to have healing effects and serve as portals to other realms.



### Census Data

- **Total Population:** Approximately 1.5 billion inhabitants.

- **Demographic Breakdown:**

- **Humans:** 70% of the population; predominantly females who actively shape societal structures.

- **Mythical Beings:** 20% of the population; includes elves, fairies, centaurs, and other legendary creatures, primarily female.

- **Clones of Legendary Figures:** 10% of the population; created for specific roles in society, predominantly female.



- **Gender Ratio:**

- Approximately 1 male for every 10 females, reflecting the severe gender imbalance caused by GKOM.



- **Age Distribution:**

- **Children (0-14 years):** 25%

- **Youth (15-24 years):** 20%

- **Adults (25-64 years):** 45%

- **Elderly (65+ years):** 10%



### Cultural Aspects

- **Matriarchal Society:**

- Women hold leadership roles across all sectors of society, including governance, education, and the arts. The Council of Elders, consisting of wise and powerful women, oversees the continent.

- Men, although rare, are revered and protected, given their crucial role in procreation and societal continuity due to the GKOM virus.



- **Societal Structure:**

- Communities are structured around clans, each representing a mythical entity or theme, fostering a strong sense of belonging and identity.



- **Beliefs and Rituals:**

- Women engage in rituals to honor elemental spirits—earth, air, fire, and water—performed through elaborate ceremonies involving dance, music, and elemental conjuration.

- Festivals celebrate seasonal changes and significant mythological events, featuring parades, combat tournaments, and magical displays.



- **Art and Architecture:**

- Cities are designed with organic shapes, seamlessly integrating nature and magic. Buildings are often alive with magic, with walls that shift colors and adapt to the environment.

- Artisans are revered for their ability to craft not just physical objects but living works of art that resonate with enchantments, creating beauty and functionality.



### Economy

- **Trade Goods:**

- Magical artifacts and potions made from rare ingredients sourced from enchanted flora and fauna.

- Knowledge and clones of historical and legendary figures utilized in various roles, from scholars to guardians of lore.



- **Trade Relationships:**

- Dense trade networks exist between the clans, while alliances with neighboring continents facilitate exchanges of knowledge and goods, based on shared mythological and cultural ties.



### Advancements in Magic and Technology

- **Magic Integration:**

- The society seamlessly blends advanced magic with rudimentary technology (e.g., enchanted vehicles, magical communication devices).

- Scholars engage in research that combines magic and science, leading to innovations like environmental enhancements and protective wards.



- **Education:**

- Ancient universities and academies of magic offer rigorous training in various disciplines, including alchemy, elemental manipulation, and martial arts infused with magical techniques.

- Knowledge is passed orally and through scrolls inscribed with ancient runes, contributing to a culture steeped in learning and enlightenment.



### GKOM Monsters: Mythic Nightmares

- **Description:**

- Mythic Nightmares are corrupted versions of legendary beings—chaotic entities that embody fear and malevolence, distorting their original forms and powers.

- Examples include fearsome shadow beasts, warped centaurs, and nightmarish dryads that lure victims into their cursed groves.



- **Abilities:**

- These entities can manipulate the fabric of reality using illusion magic, causing hallucinations or altering the environment around them.

- Possess elemental affinities aligned with their original mythic forms (e.g., storm manipulation, summoning natural disasters).



### Current Status and Challenges

- **Threat of GKOM:**

- The emergence of Mythic Nightmares poses a grave danger to the stability of Mythoria, causing unrest and fear among communities previously known for their peace.

- Traditional means of combating dark forces are being re-evaluated, as the nature of GKOM's influence requires innovative strategies.



- **Efforts for Protection:**

- Heroes are called to protect their mythic heritage, rallying under banners that symbolize their clan allegiance and embarking on quests to eliminate or neutralize the GKOM threat.

- Scholars collaborate to uncover ancient lore that may hold the key to understanding and defeating the corrupting influence of GKOM.



### Notable Locations

- **The Arcane Citadel:**

- A grand fortress that serves as both a magical academy and a repository of ancient knowledge. It towers above the surrounding landscape, visible throughout Mythoria.



- **The Whispering Woods:**

- A sacred forest said to be alive with the voices of the ancients, where knowledge seekers come to meditate and commune with spirits to gain wisdom.



- **The Sacred Glades:**

- These fertile fields embody harmony and are protected by magical wards. Here, communities come together to celebrate and nurture the land.
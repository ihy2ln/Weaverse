---
type: location
name: The Frosted Mug Inn
color: green
aliases:
  - Inn
  - fmi
  - Frosted Mug
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Codex Entry: The Frosted Mug Inn



**Classification:** Inn & Tavern (Adventure Guild Affiliate)

**Location:** Silverbrook Settlement, 10-minute walk from the Silverbrook Adventure Guild along the Main Road

**Proprietress:** Helda Frostmane

**Reputation:** “The guild’s real common room” — unofficial home base for adventurers of every stripe



---



## Overview



The Frosted Mug sits a measured ten minutes from the guildhall gates on a well-trampled stretch of the Main Road, close enough that a runner can fetch a forgotten quest slip and be back before the ale goes flat. Formerly the Frostblood family homestead, the building combines a stone foundation with frost-birch timber framing, the mortar between stones laced with a crystalline grit that catches moonlight and glimmers faintly after dark. Two structures share the compound: the main inn building housing private rooms and the public tavern, and a converted trapper’s lodge out back that serves a very specific purpose.



Everyone calls it “the Mug” now. The guild runs the boards, but the Mug runs the gossip, the war stories, and the hangovers.



---



## Main Building — The Mug



**Ground Floor: The Tavern**

A long, low-beamed room that can swallow a full adventuring party and still have space for a card game at the corner table. Silverwood-plank flooring, heavy tables scarred with decades of blade tips and tankard rings, bench seating that has shaped itself to a thousand backsides. A stone hearth dominates the far wall, burning seasoned birch through the cold months. The bar runs nearly the length of the room—frost-birch top over a fieldstone base—with a brass foot rail that has seen more boots than a cobbler’s shop. Helda’s own frostmead is always on draft, alongside a rotating selection of local ales and a cider pressed from Silverwood-edge apples. The kitchen turns out straightforward food from before dawn until the last drunk stumbles home: meat pies, root stew, fried tubers, black bread with salted butter. The tavern connects directly to the main road entrance and to a rear door leading to the courtyard and the dorm building beyond.



**Upper Floors: Guest Rooms**

Eight private rooms spread across two floors, each small but meticulously kept. The beds are the Mug’s true claim to fame—deep mattresses stuffed with Silverwood wool, layered under goose-down quilts, the headboards carved from frost-birch branches. Helda’s rule is simple: no weapons on the mattress, no blood on the sheets. Two rooms are discreetly fitted as WAHO chambers, marked by a small silver frostflower above the doorframe, booked through quiet word with Helda herself. Washrooms at each corridor’s end offer hot water at all hours, a luxury not every inn in Silverbrook can claim.



**Staff Quarters**

Tucked under the eaves, a small apartment houses the live-in staff: Gwenyth Ironpaw (beastkin cook and brewmaster), Lyriel Moonwhisper (elf housekeeper and herbalist), and Tamsin Sparkwright (gnome maintenance and mechanist). Helda’s own quarters occupy the ground floor behind the kitchen—close enough to hear a brawl start before it finishes.



---



## Secondary Building — The Den



**Purpose:** Female adventurers’ dormitory

**Capacity:** 10 beds



The converted trapper’s lodge across the courtyard is the Mug’s worst-kept secret and its most cherished feature. Helda, a retired C-rank brawler herself, converted the building years ago into a bunkhouse specifically for female adventurers waiting on contracts, recovering from dungeons, or simply too broke for a private room. Ten beds line the walls in a single open bay—sturdy Silverwood frames with decent mattresses, each with a lockable foot locker. A communal bath with a deep copper soaking tub, a small drying rack for gear, and a wood stove for winter nights. The dorm operates on a first-come, first-serve basis, with guild membership granting priority. Helda keeps no roster, but she knows exactly who is sleeping where every night, and trouble is evicted before sunrise. A matron’s nook at the entrance holds a small desk where Helda or one of her staff checks members in at odd hours. The Den’s atmosphere is sleepover-meets-barracks: gear hangs from bedposts, drying herbs scent the air, and someone is always braiding someone else’s hair at the long table under the window.



Pricing is steeply discounted for registered guild members. Visitors may inquire, but Helda’s answer is usually a flat no unless a guild matron vouches for them.



---



## Courtyard & Amenities



The central courtyard connects the two buildings via flagstone paths. Wrought-iron tables and chairs cluster under a young Silverwood sapling that Helda planted the year she bought the property. A stable with six stalls—enchanted to stay frost-free—sits against the compound’s rear wall, a well fed from the Silverthread River offers clean water, and a small herb garden supplies both the kitchen and Lyriel’s remedies. A smokehouse and drying racks complete the working end of the yard.



---



## Pricing & Policies



- **Private Room:** 2 Gleams/night (meals included)

- **The Den (dorm bed):** 1 Gleam/night for guild members, 2 Gleams for non-members

- **Stabling:** 1 Gleam/night per mount

- **WAHO Upgrade:** +5 Gleams (negotiate directly with Helda)

- **Helda’s Rules:** No weapons at the table. No trouble in my beds. No men in the Den. Ever.



---



## Reputation & Atmosphere



The Mug is the guild’s unofficial spillover. At dawn the tavern fills with parties grabbing a last hot meal before hitting the forest. At dusk it floods with the same parties, dirtier and drunker, rehashing every misstep over frostmead and card games. Helda holds court behind the bar, a broad-shouldered frost-born beastkin who remembers every name and every tab. She’ll cry at a wedding announcement, break up a fight with one hand on each collar, and personally walk a homesick rookie back to the Den at two in the morning. The guild posts quests; the Mug posts the stories that come back from them. No adventurer in Silverbrook feels like a stranger after one night under its roof.
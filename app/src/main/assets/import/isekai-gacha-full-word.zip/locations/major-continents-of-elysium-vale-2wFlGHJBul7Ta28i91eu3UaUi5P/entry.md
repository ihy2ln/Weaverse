---
type: location
name: Major Continents of Elysium Vale
color: green
aliases:
  - Major Continents of Elysium Vale
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### # **Planetary Sheet: Major Continents of Elysium Vale**

### 1. Arcanis

- **Size:** Approximately 1.5 million square miles
- **Population:** 1.5 billion
- **Description:** Known as the intellectual heart of Elysium Vale, Arcanis is renowned for its magical academies and skilled sorcerers. The continent is filled with vast libraries, schools dedicated to the arcane arts, and cities vibrant with magical energy.

### 2. **Verdantia**

- **Size:** Approximately 1 million square miles
- **Population:** 1.2 billion
- **Description:** A lush and enchanting continent primarily inhabited by elves, Verdantia is a realm steeped in deep magic and ancient traditions. The dense woodlands shelter many fey creatures, mythical beings, and hidden magical secrets waiting to be discovered.

### 3. **Durnheim**

- **Size:** Approximately 800,000 square miles
- **Population:** 900 million
- **Description:** Dominated by rugged mountain ranges, Durnheim is the homeland of dwarves and is celebrated for its exceptional craftsmanship and mining operations. The continent features sprawling underground cities and forges where legendary weapons and armor are crafted.

### 4. **Thaloria**

- **Size:** Approximately 1.2 million square miles
- **Population:** 1.7 billion
- **Description:** A diverse continent characterized by a mix of thriving human kingdoms and various settlements representing multiple races. Thaloria serves as a cultural and commercial hub, where different traditions intermingle, fostering an environment ripe for trade and adventure.

### 5. **Elysara**

- **Size:** Approximately 900,000 square miles
- **Population:** 900 million
- **Description:** A mystical land shrouded in legends, Elysara is known for its supernatural phenomena, ethereal landscapes, and harmonious coexistence of spirits and ancient beings. This continent is rich in mythology and enchantment, providing a sanctuary for those seeking greater understanding of the mystical realms.

### 6. **Regalis**

- **Size:** Approximately 600,000 square miles
- **Population:** 700 million
- **Description:** The capital continent of Elysium Vale, Regalis is home to the royalty and elite. Renowned for its opulent cities, majestic palaces, and cultural landmarks, the continent serves as the political and social center of the realm, often bustling with grand events and celebrations.

### 7. **Mythoria**

- **Size:** Approximately 800,000 square miles
- **Population:** 900 million
- **Description:** A realm rich in history and folklore, Mythoria serves as the nexus of various legendary tales and acts as a bridge between the realms of fantasy, where heroism and destiny intertwine. This continent is filled with mystical landscapes, ancient ruins, and the echoes of legendary figures who have left their mark on its soil.
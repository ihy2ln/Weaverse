---
type: location
name: Elysara
color: purple
aliases: []
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Planetary Sheet: Elysara

*"A World of Living Fantasies and Modern Marvels"*

---

### Basic Information

- **Name:** Elysara
- **System:** Adams Haven Solar System
- **Size:** 10× Earth (≈127,000 km diameter, gravity ~1.1 g)
- **Population:** 60 billion (90% female, 10% male)
- **Theme:** Modern society with Celestium-enhanced quality of life, where everyone adopts hyper-stylized character aesthetics in everyday life

---

### Demographics

- **Humans:** 100% biologically human, but with cosmetic enhancements creating vibrant hair colors, perfect proportions, and exaggerated features
- **GKOM Survivors:** Male survivors (only 10% of population) enjoy elevated social status and resources
- **Gender Ratio:** 90% women, 10% men (The foundation of Elysara's social structure)

---

### Celestium Integration

- **Abundance:** Moderate deposits throughout the crust provide for everyday conveniences
- **Primary Applications:**
  - Self-maintaining infrastructure
  - Enhanced consumer electronics
  - Quality-of-life medical applications
  - Fashion-forward cosmetic products

---

### Five Major Continents

### 1. Aredorn ("Valor Realm")

- **Modern Reality:** Contemporary urban centers with sports complexes and athletic facilities
- **Capital "Champion City":** Modern metropolis with state-of-the-art stadiums, fitness centers, and sports medicine clinics
- **Culture:** Competitive sports and physical prowess highly valued; men treated as honored team captains and coaches
- **Celestium Use:** Performance-tracking wearables, instant-healing sports medicine

### 2. Amoria ("Heartlands")

- **Modern Reality:** Picturesque towns and romantic getaway destinations
- **Capital "Rosewood":** A clean, beautiful city with scenic parks, upscale restaurants, and entertainment venues
- **Culture:** Romance-focused society where dating and relationships take center stage; men courted by multiple suitors
- **Celestium Use:** Mood-enhancing environmental systems, perfect-match dating apps

### 3. Neoterra ("Innovation Hub")

- **Modern Reality:** Silicon Valley-style tech centers and corporate headquarters
- **Capital "Nexus":** Gleaming skyscrapers with advanced infrastructure and digital integration
- **Culture:** Technology-focused society where the latest gadgets define status; men given executive positions
- **Celestium Use:** Next-gen smartphones, smart homes, augmented reality glasses

### 4. Veridian ("Everyday Paradise")

- **Modern Reality:** Suburban communities and small towns with emphasis on comfortable living
- **Capital "Harmony":** A well-maintained city with excellent school systems, shopping centers, and community spaces
- **Culture:** Family and community-oriented lifestyle; men treated as honored guests at all community events
- **Celestium Use:** Convenience appliances, self-maintaining homes, comfort-focused technologies

### 5. Astraion ("Leisure Coast")

- **Modern Reality:** Resort towns and entertainment districts
- **Capital "Oceanview":** A coastal city with beaches, hotels, and entertainment complexes
- **Culture:** Vacation and leisure-focused lifestyle; men given VIP treatment at all venues
- **Celestium Use:** Entertainment technology, comfort-enhancing amenities, weather optimization

---

### Smaller Islands & Regions

- **Adventure Peninsula:** Outdoor recreation centers and extreme sports facilities
- **Culinary Islands:** Regions known for exceptional restaurants and food innovation
- **Gaming Valley:** Technology centers focused on interactive entertainment
- **Fashion Coast:** Trendsetting design studios and shopping districts

---

### Society & Culture

- **Appearance Norms:** Everyone adopts a stylized aesthetic reminiscent of fictional character types, but remains within realistic human parameters
- **Male Status:** Men enjoy tremendous social privileges, legal protections, and material benefits
- **Dating Dynamics:** Women actively pursue men, with harems being the social norm rather than exception
- **Entertainment:** Reality shows following the lives of particularly popular men; competitive dating programs

---

### Government & Economics

- **System:** Democratic with heavy preference toward male comfort and safety
- **Economy:** Service-based with emphasis on male convenience and entertainment
- **Housing:** Men receive luxurious accommodations with attached living quarters for their companions
- **Healthcare:** Advanced Celestium-enhanced medical care, with priority service for male patients

---

### Technology & Daily Life

- **Transportation:** Electric vehicles, efficient public transit, ride-sharing apps (all Celestium-enhanced)
- **Communication:** Advanced smartphones with holographic capabilities and emotional sensitivity
- **Home Life:** Smart homes with self-cleaning features, automated meal preparation, and comfort optimization
- **Entertainment:** Immersive viewing experiences, interactive gaming, personalized content creation

---

### Life as a Man on Elysara

- Wake up to breakfast prepared by eager companions
- Receive numerous messages from potential new suitors
- Enjoy VIP treatment at work, restaurants, and entertainment venues
- Access to exclusive male-only clubs and facilities
- Legal right to maintain multiple relationships simultaneously
- Regular health check-ups with cutting-edge Celestium technology
- Special accommodations everywhere to ensure comfort and happiness

---

### Life as a Woman on Elysara

- Competitive dating environment where standing out is crucial
- Career paths often focused on male comfort and entertainment
- Social status significantly influenced by relationship success
- Extensive beauty and personal development industries
- Communal living arrangements among women sharing a male partner
- Focus on developing unique skills and attributes to attract attention
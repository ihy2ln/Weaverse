---
type: location
name: Elysium Vale
color: green
aliases:
  - Elysium Vale
  - EV
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Updated Codex: Elysium Vale (EV)**



## **Basic Information**



- **Name:** Elysium Vale

- **Size:** 6 times Earth's mass (approximately 76,000 km diameter)

- **Theme:** High Fantasy

- **Total Population:** Approximately 6 billion

- **Moons:** 2 (Luna Mystica and Luna Arcana, used for celestial observatories and magical conduits)

- **Position:** 2nd planet in Adams Haven Solar System

- **Universal Context:** As one of the Five Jewels, Elysium Vale shares the system's foundational crises: the **Gender Ratio (GR)** anomaly (one male born per 10,000 births) and the endemic **God Killer Of Men (GKOM)** virus. These have forged a matriarchal society under **WAH doctrine**, where males receive luxurious lives under the **All for One (AFO)** framework while enhanced women handle all labor, governance, and protection.



## **Demographic Breakdown**



- **Humans:** 40% (WAHB-enhanced)

- **Elves:** 25% (naturally aligned with WAHB enhancements)

- **Dwarves:** 15% (adapted to underground WAH infrastructure)

- **Other Races:** 20% (fey, dragonkin, and other mythical beings)

- **Gender Ratio (GR):** Strictly 10,000 females to 1 male, creating a society where WAHB-enhanced women serve as protectors, laborers, and nurturers. Males live in protected luxury enclaves, their every need anticipated by devoted female attendants under AFO mandates.



## **Major Continents**



### 1. **Arcanis**



- **Size:** 1.5 million square miles

- **Population:** 1.5 billion

- **Description:** Heart of magical learning and governance, where female mages maintain arcane infrastructures while attending to male scholars in luxurious libraries and towers.



### 2. **Eldrenwood**



- **Size:** 1 million square miles

- **Population:** 1.2 billion

- **Description:** Ancient forest realm where elf wardens protect male nobles in tree-top palaces, blending natural magic with WAH devotion.



### 3. **Ironhold**



- **Size:** 800,000 square miles

- **Population:** 900 million

- **Description:** Mountainous dwarf domain where female smiths craft legendary artifacts while ensuring male craft-lords want for nothing.



### 4. **Terra Nova**



- **Size:** 1.2 million square miles

- **Population:** 1.7 billion

- **Description:** Human-dominated trade hub where female merchants manage commerce while curating luxury experiences for sheltered males.



### 5. **Nythra**



- **Size:** 900,000 square miles

- **Population:** 900 million

- **Description:** Mystical frontier where female rangers patrol wild territories, maintaining safe havens for rare male explorers.



## **GKOM Integration**



- **WAHB Enhancements:** Females develop lush, fertile curves and heightened magical affinity, while surviving males (1%) become paragons of virility and arcane potential. Their enhanced biology drives instinctive female devotion under WAH principles.

- **GKOM Variants:** Those who succumb transform into genre-specific abominations—Corrupted Dragons, Shadow Wraiths, and Feral Treants that threaten settlements, requiring constant patrols by WAHB-enhanced guardians.



## **Capital**



- **Name:** Aethelgard

- **Description:** Floating crystalline city where the female-run Arcane Council governs while maintaining opulent districts for male residents. Magic-permeated architecture ensures perfect comfort and security for cherished males.

- **Government Structure:** Matriarchal council of archmages from each race, advised by rare male "Lorekeepers" who hold ceremonial veto power over magical decrees.



## **Cultural Notes**



- **WAH Society:** Women find fulfillment in serving male needs—from battle-mage protectors to nurturing attendants. All infrastructure, magic, and labor flow toward male comfort and safety.

- **Reproduction:** Fertility rituals and magical treatments maximize conception chances with rare males. Women compete honorably for breeding rights through service and devotion.

- **Current Challenge:** GKOM variants increasingly threaten outer settlements, testing the protective capabilities of WAHB-enhanced women while male enclaves remain blissfully unaware.
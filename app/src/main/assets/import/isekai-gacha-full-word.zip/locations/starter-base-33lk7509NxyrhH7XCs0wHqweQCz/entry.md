---
type: location
name: Starter Base
color: purple
aliases:
  - Starter Base
  - SB
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
*B-Tier Wilderness Estate*



---



### **Core Structures**



Portal is in front of the main house.

1. **Main Lodge** *Size 550 sq ft*



- **Exterior:**



- Riverstone foundation with dovetail-notched pine walls

- Sloped cedar roof with skylight (Animal bladder glass)

- Wraparound deck (Partial covering for rainy days)



- **Interior:**



- **Great Room:**



- Central stone hearth (Cooking + heating)

- Cedar dining table (Seats 8)

- Wall-mounted tool racks



- **Sleeping Nook:**



- Raised platform bed with wool-stuffed mattress

- Built-in storage cubbies

- Skylight view of constellations



2. **Polished Stone Kitchen & Bathroom** *(Luxury in the Wild)*



- **Kitchen:**



- Polished granite countertops

- Open shelves for pottery & utensils

- Hand-crank spice grinder (B-tier bonus)



- **Bathroom:**



- Polished stone composting toilet (Waste auto-collects in inventory)

- Copper basin for washing

- Small storage for personal hygiene items



3. **Outdoor Workspaces**



- **Field Kitchen:**



- Brick pizza oven

- Smoke-curing rack

- Fermentation crocks (5x)



- **Crafting Pavilion:**



- Stone anvil embedded in oak stump

- Wooden vise & tool sharpening station



---



### **Defensive & Utility Features**



**Perimeter** *(Now With Stone)*



- **Walls:** 1.8m riverstone fence with:



- Arrow slits every 2m

- Hanging deterrents (Bone chimes, wasp nests)



- **Gate:** Reinforced timber with drop-bar lock



**Food Systems**



- **Farm Plots (3x)**



- Terraced herb garden (Rosemary, mint, medicinal)

- Root vegetable mounds (Carrots, potatoes)

- Trellised beans/peas



- **Chicken Tractor:** Mobile coop for 4 hens

- **Smokehouse:** Brick chimney-style (20 meat capacity)



---



### **Relaxation Oasis: Sauna by the Pond**



- **Location:** Edge of the freshwater pond, blending with nature

- **Structure:**



- Riverstone walls with cedar benches

- Wood-fired stove (Heats volcanic stones)

- Open-air design for cooling off in the pond



- **Experience:**



- Steam infused with pine & eucalyptus

- Direct access to pond for refreshing dips

- Twilight ambiance enhanced by fireflies



---



### **Notable Upgrades**



Feature

Benefit



Skylight

+15% daylight productivity



Rainwater Collection

40L/day via gutter system



Draft Horses (2)

Log hauling & plowing



Cliffside Pulley

Coastal resource access



---



### **Aesthetics & Atmosphere**



The lodge merges frontier toughness with intentional comforts:



- **Morning:** Sunlight fractures through skylight onto hand-planed floors

- **Evening:** Dozens of candle nooks bathe stone walls in amber light

- **Sounds:** Axe chops echo off the mountain, mixing with clucking hens



---



### **Waste Management System**



- **Toilet & Garbage:**



- Compost waste & trash directly transfers to inventory waste section

- Inventory system auto-sorts waste for easy disposal (Burn or bury)
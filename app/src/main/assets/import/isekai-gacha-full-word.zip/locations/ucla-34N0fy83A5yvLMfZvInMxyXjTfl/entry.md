---
type: location
name: UCLA
color: brown
aliases:
  - OA
  - UCLA
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
## **Location Codex: UCLA Neo-Campus**

**Type:** Prestigious Educational Campus



**Chancellor:** Dr. Victoria Solis

**Population:** 100,000 total

- Students: 70,000 (K-12: 50,000 | Undergraduate: 15,000 | Graduate/Doctoral: 5,000)

- Faculty/Staff: 30,000

- **Gender Ratio:** 99% Female / 1% Male (1,000 males total)



**Major Exports:** Top-tier graduates, cutting-edge research, medical breakthroughs, Celestium innovations, Hero talent



**Major Imports:** Research materials, Celestium components, specialized equipment, visiting scholars



**Size:** 25 square miles (16,000 acres - exceptionally spacious campus)



**Location:** Central Education District, Pacific Bastion (Neo-Los Angeles), California Asteroid, USA Cluster, TTN



**Status:** Most prestigious educational institution in Los Angeles Asteroid. Exceptionally well-funded through state grants, federal research contracts, and Celestium patents.



---



### **Description**



UCLA Neo-Campus sprawls across an expansive 25 square miles of prime real estate in the heart of the Education District, its generous land use creating a park-like academic paradise. With only 100,000 people occupying such vast territory, the campus feels almost luxuriously spacious—tree-lined boulevards stretch for miles, athletic fields disappear into the horizon, and research parks are buffered by preserved natural landscapes. This abundance of space reflects both UCLA's prestige and California's commitment to providing exceptional educational environments.



The iconic **Royce Hall** still anchors the campus, now a 50-story vertical expansion of the original Romanesque revival architecture, its towers visible across the Education District. From this central point, the campus radiates outward in distinct neighborhoods, each separated by expansive green spaces, botanical gardens, and recreational areas.



**North Campus** (8 square miles) houses humanities, social sciences, and WAH Studies programs in traditional collegiate buildings connected by miles of tree-shaded walkways and sculpture gardens. Faculty and students enjoy the luxury of dedicated office buildings, seminar halls with natural lighting, and outdoor amphitheaters for lectures.



**South Campus** (7 square miles) contains the sciences—sprawling Celestium Engineering complexes, isolated Medical Research facilities, Virology labs surrounded by safety buffer zones. The generous spacing allows dangerous experiments to occur with minimal risk to the broader campus.



**The Athletic Complex** (4 square miles) rivals professional sports facilities—multiple stadiums, Olympic-grade swimming centers, extensive Quirk practice fields, and the legendary Rose Bowl expansion where the Bruins teams train. Miles of running trails wind through preserved wilderness areas on campus edges.



**Research Parks** (3 square miles) scatter across campus, featuring specialized facilities like the Celestium Integration Center, Agricultural Innovation Farms (vertical and traditional), and the Omega Research Division—each buffered by parkland and security zones.



**Residential Villages** occupy strategic locations throughout campus. Traditional dormitories for undergraduates cluster near academic buildings. Graduate housing sprawls in apartment-style communities with their own amenities. The **Male Residential Complex**—a secure, luxurious compound near campus center—houses all 1,000 male students and staff across multiple buildings surrounded by private gardens, recreational facilities, and discrete Beta-rank security perimeters.



---



### **Campus Life**



With such abundant space, UCLA cultivates a true college-town atmosphere. Students bike or take electric shuttles between classes, passing through diverse microclimates—Mediterranean gardens, oak groves, even a small lake stocked with bioluminescent fish. The **University Village** (2 square miles) functions as a self-contained district with shops, cafes, restaurants, entertainment venues, and student housing, creating a genuine community feel.



**Westwood Plaza** serves as the social heart—a vast pedestrian commons where students sprawl on endless lawns between classes, activist groups table for causes, and impromptu Quirk demonstrations erupt in designated zones. The intense competition for male attention manifests in elaborate "study group" invitations, athletic performance displays, and academic achievement competitions—all socially acceptable under WAH cultural norms.



The **K-12 Laboratory Schools** occupy a dedicated 1-square-mile sector on eastern campus, featuring age-appropriate facilities from elementary playgrounds to high school Hero training centers. The spacious layout allows children to safely explore Quirk manifestations in isolated practice zones.



---



### **Academic Excellence**

Research funding exceeds $50 billion annually. The campus operates independent Celestium reactors, advanced AI systems, and experimental facilities rivaling government installations—all benefiting from generous buffer zones that make UCLA one of the safest research environments in the cluster.

---



### **Infrastructure**



The vast campus requires robust transit systems. The **BruinBus** network operates 50+ routes connecting all zones. Bike paths span 200+ miles. Electric shuttles run continuously. Faculty/staff access hover-pod stations for rapid transit. Despite the size, nowhere on campus is more than 10 minutes from transit access.



Facilities scatter across the territory: 25 dining halls, 500+ academic buildings, 100 research facilities, 5 hospitals/medical centers, dozens of athletic complexes, performing arts centers, museums, and the famous **Janss Steps** leading to Royce Hall. The **Powell Library** towers 30 stories, its collections accessible cluster-wide, surrounded by acres of reading gardens.
---
type: lore
name: Omniversal Gacha System
color: blue
aliases:
  - OGS
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Codex Entry: Omniversal Gacha System (OGS)



**Category:** Reality-Spanning Acquisition Interface



---



## Overview



The OGS pulls items, entities, and resources from across all known dimensions, timelines, and conceptual spaces. It operates through a tiered I-Point economy calibrated directly to the user's power ranking. Points generate passively by rank, decay at 1% daily if unspent, and stack additionally through combat, quest completion, and achievement milestones.



All trading runs exclusively through the OGS itself, functioning as an interdimensional broker with its own inventory, exchange rates, and assessment protocols. The user exchanges resources, I-Points, and local currency directly with the system. Exchange rates fluctuate based on the current planet's economic stability rating and OGS inventory demand. Selling back unwanted pull results returns 20–40% of the original pull cost. The OGS refuses trades on items it classifies as reality-destabilising without a verified containment guarantee.



---



## Banner Tiers



Four tiers govern all banners, escalating from narrow planet-locked novice pools to fully unrestricted omniversal draws. Each tier increases in cost, pool breadth, and result ceiling.



**Tier**

**Name**

**Per Pull**

**10-Pull Bundle**

**Pool Source**

**Min. Rank**



Tier 1

Novice

1,000 IP

9,000 IP

Planet-locked, F–C rank results only

F-Rank



Tier 2

Advanced

5,000 IP

45,000 IP

Planet-normalised, full F–SSR range

C-Rank



Tier 3

Expert

10,000 IP

90,000 IP

Regional off-planet, neighbouring systems and dimensions

A-Rank



Tier 4

Legendary

20,000 IP

180,000 IP

Fully unrestricted omniversal pool

SSR-Rank



**Bundle Discount:** Every tier offers a 10-pull bundle granting one free pull, reducing the effective per-pull cost by 10%.



**Pity System:** All tiers carry a running pity counter guaranteeing a minimum elevated result at 100 pulls. Higher tiers extend the pity threshold further for Legendary and Omega-tier results. Counters never reset between sessions or banner rotations.



---



## Pull Rates by Tier



**Rarity**

**Tier 1**

**Tier 2**

**Tier 3**

**Tier 4**



Common (F–E)

70%

40%

15%

5%



Uncommon (D–C)

25%

35%

30%

15%



Rare (B–A)

4.97%

20%

35%

30%



Ultra Rare (S–SR)

0.03%

4.97%

15%

30%



Legendary (SSR)

—

0.03%

4.97%

15%



Omega

—

—

0.03%

4.97%



Paradox

—

—

—

0.03%



**Pity Thresholds:**



**Guaranteed Result**

**Tier 1**

**Tier 2**

**Tier 3**

**Tier 4**



Ultra Rare

100 pulls

100 pulls

100 pulls

—



Legendary

—

200 pulls

150 pulls

100 pulls



Omega

—

—

300 pulls

150 pulls



> **Paradox Tier:** Paradox-tier pulls trigger automatic facility-level reality stabilisation the moment the pull registers. Materialisation takes anywhere from 3 minutes to 2 hours. The emergency dismissal protocol arms itself without user input. The system cannot predict, categorise, or fully contain what arrives. Proceed accordingly.



---



## Banner Categories



Five categories run across all four tiers. The tier selected determines the cost, pool source, and result ceiling. The category determines what type of result materialises.



---



### Gear



Pulls weapons, armour, tools, and equipment. Results scale to the selected tier and the user's current rank, though pulls regularly produce items that exceed current ability — gear the user must grow into rather than immediately wield. Mundane equipment dominates Tier 1 results. Tier 2 introduces enchanted and rank-enhanced gear. Tier 3 draws from off-world civilisations, producing technology and artefacts with no local equivalent. Tier 4 opens access to conceptual gear — equipment forged from abstract concepts such as a blade of condensed regret, armour threaded from the principle of inevitability, or a shield constructed from the weight of collective memory.



---



### Partner



Pulls living companions from across dimensions, timelines, and civilisations, delivering them loyalty-bound through OGS protocol the moment they materialise. The binding prevents active betrayal but manufactures nothing resembling affection. Partners arrive with full personalities, memories, capabilities, and opinions about their situation intact.



Tier 1 pulls local-world individuals within F–C rank. Tier 2 expands into higher-ranked specialists still broadly human in origin. Tier 3 introduces partners from neighbouring systems and parallel histories — individuals pulled mid-event, mid-mission, or from civilisations already gone. Tier 4 opens the exotic pool exclusively: non-human entities, divine constructs, mythical beings, and conceptual embodiments that may not fully fit inside the available space when they arrive.



SR-rank partner pulls and above trigger a reality stabilisation field during materialisation. The 90-second window is not negotiable. Clear the area beforehand.



---



### Resource



Pulls raw materials, consumables, energy sources, knowledge assets, and currency. The broadest category in practical scope and typically the first stop when establishing on an unfamiliar world. Tier 1 delivers contextually appropriate local matter — timber, ore, food stock, basic currency. Tier 2 introduces knowledge scrolls, energy cells, and material resources several centuries ahead of local development. Tier 3 pulls from neighbouring systems, yielding stellar fuel compounds, multi-world seed vaults, and encoded civilisational archives. Tier 4 reaches into pre-collapse records, contained stellar matter, and knowledge structures from Omega-tier civilisations encoded into objects small enough to carry in a pocket.



---



### Ability



Pulls skills, techniques, passive enhancements, and power upgrades delivered as learnable scrolls, direct neural imprints, or integrated system upgrades depending on the tier. The user must meet minimum rank requirements to fully activate higher-tier results. Incompatible pulls are stored in the OGS inventory and flagged for future activation once the user's rank qualifies.



Tier 1 covers combat manuals, basic stat boosts, and foundational technique frameworks. Tier 2 introduces neural imprint abilities and passive enhancements with immediate tactical value. Tier 3 pulls supernatural ability sets, cross-dimensional combat philosophies, and resistance upgrades sourced from species that evolved under conditions no local world produces. Tier 4 delivers system-level upgrades that improve OGS functionality directly — I-Point generation amplifiers, pool capacity expansions, banner access unlocks, and ability integrations the system itself flags as requiring careful handling.



---



### Gacha Ticket



Pulls tickets, tokens, and vouchers granting access to locked banner pools, guaranteed rarity results, or cost-free draws across any category. Each ticket specifies on acquisition exactly which banner type and tier it unlocks. All tickets are tradeable with the OGS directly at assessed value.



Key ticket types include the Standard Pull Ticket for one free planet-normalised draw, the Premium Off-Planet Ticket bypassing cost on any off-world banner, the Legendary Summon Ticket guaranteeing an SSR-tier result or above on any category, the Pity Reset Ticket triggering an immediate guaranteed pity pull while clearing the counter, and the Dimension-Lock Ticket targeting one specific named dimension for a single pull regardless of tier restrictions.
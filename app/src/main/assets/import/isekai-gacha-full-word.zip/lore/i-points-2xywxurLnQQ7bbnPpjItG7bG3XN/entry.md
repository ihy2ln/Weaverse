---
type: lore
name: I-Points
color: blue
aliases:
  - I-Points
  - I-P
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Codex Entry: I-Points (Instinct Points)**



#### **Category:** Universal Resource/Currency



#### **Description:**



I-Points are an adaptive energy currency rewarded based on **instinctive achievement**—whether completing objectives, fulfilling deep desires, or overcoming challenges. They function as an RPG-style progression system across multiple abilities, powers, and enhancements.



#### **Acquisition Methods:**



- **Quest Completion:**



- Earn points proportional to difficulty (F-rank quests yield ≤1k; SSR-rank can exceed 1 million).

- Hidden objectives or moral choices may grant bonus multipliers.



- **Desire Fulfillment:**



- Satisfying personal or others’ intense desires (emotional/physical) generates points—higher stakes = greater rewards.

- Example: Resolving a character’s lifelong vendetta (SSR-tier) vs. buying their favorite meal (F-tier).



- **Combat/Conflict:**



- Defeating opponents scaled by threat level (e.g., sparing a foe may yield more than killing them).



#### **Ranking Scale (F → SSR):**



Rank

Point Threshold

Typical Source



F

≤1,000

Minor tasks, basic desires



E

≤5,000

Side quests, short-term goals



D

≤10,000

Multi-step missions



C

≤50,000

Major story arcs



B

≤100,000

Life-altering choices



A

≤500,000

Legendary feats



S

≤1,000,000

World-shaping actions



SSR

∞

Mythic achievements



#### **Usage:**



- **Unlock/Upgrade Abilities:** Spend points in any ability tree (e.g., combat, social, supernatural).

- **Crafting/Meta-Progression:** Trade for rare items or passive boosts (e.g., "Luck +10%").

- **Currency Exchange:** Some factions barter goods/services for I-Points.



#### **Key Mechanics:**



- **Decay:** Unspent points lose 1% daily (encourages active investment).

- **Synergy Bonuses:** Combining abilities from different trees reduces upgrade costs.



**Quote:**

*"Power isn’t given—it’s earned through blood, choice, and hunger."*



---
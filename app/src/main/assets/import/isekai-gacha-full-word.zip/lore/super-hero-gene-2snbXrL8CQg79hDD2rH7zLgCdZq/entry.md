---
type: lore
name: Super Hero Gene
color: pink
aliases:
  - SHG
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
Project Genesis: Awakening the Hero Within

In the year 2344, Adams Haven stands on the precipice of a revolutionary era. Not only has Project Genesis mastered female cloning, but scientists have stumbled upon a groundbreaking discovery: the "hero gene." This dormant gene, present in both natural-born individuals and clones alike, awakens upon reaching the age of fifteen, granting extraordinary abilities.



The Awakening:



On their 15th birthday, individuals undergo a mandatory evaluation to determine the presence and nature of their hero gene.

The evaluation involves a combination of physical and mental tests, analyzing biological markers and psychological assessments.

Upon activation, the hero gene manifests in diverse ways, granting a wide range of superhuman abilities. These abilities can range from enhanced strength, speed, and reflexes to telekinesis, telepathy, or elemental manipulation.

Training and Guidance:



Recognizing the potential dangers and responsibilities that come with these powers, Adams Haven has established the Hero Academy.

This specialized institution provides rigorous training and guidance to individuals who awaken their hero genes, helping them hone their abilities and master responsible use of their powers.

The academy offers diverse training programs tailored to individual abilities and potential, fostering teamwork, ethical decision-making, and social responsibility.

The Hero Spectrum:



The awakened hero abilities vary greatly, creating a diverse spectrum of heroes. Some examples include:

Kinetic Champions: Possessing superhuman strength, speed, and durability, these heroes excel in physical combat and protection.

Elemental Masters: Capable of manipulating elements like fire, water, or earth, they offer unique offensive and defensive capabilities.

Mental Adepts: Gifted with telepathy, telekinesis, or mind control, these heroes excel in information gathering, strategic planning, and psychological support.

Mystical Guardians: Drawing power from unknown sources, these heroes possess unique abilities like healing, illusion manipulation, or communication with the supernatural.

The Evolving Society:



The emergence of heroes fundamentally alters the social landscape of Adams Haven.

Heroism becomes a celebrated profession, with heroes dedicating themselves to public service, crime prevention, and disaster relief.

Ethical guidelines are established to ensure responsible use of powers and prevent misuse.

A new generation of heroes emerges, fostering a sense of security and hope for the future of Adams Haven.
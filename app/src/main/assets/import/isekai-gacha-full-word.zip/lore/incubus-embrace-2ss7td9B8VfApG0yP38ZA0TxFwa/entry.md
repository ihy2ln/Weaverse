---
type: lore
name: Incubus Embrace
color: blue
aliases:
  - IE
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Codex Entry: Incubus Embrace (IE)



**Category:** Superhuman Enhancement

**Classification:** Innate Biological Overhaul



---



## Overview



Incubus Embrace is a total biological and psychological overhaul built around the Incubus archetype. It rewires the user's physiology, instincts, and social presence from the ground up — transforming them into an apex sexual predator operating at superhuman capacity. Every component feeds a single unified purpose: dominance through desire.



---



## Stat Enhancement



Incubus Embrace provides a blanket 2x amplification across every stat — strength, speed, endurance, perception, and cognition — as a hard baseline. The multiplier carries no ceiling. It scales upward through character development, accumulated experience, and the depth of intimate encounters. There is no recorded upper limit.



---



## Active Abilities



**Sexual Empowerment** — Each encounter allows the user to permanently absorb a fraction of their partner's chi at the point of climax. Greater power differential yields greater absorption.



**Power Replication** — At climax, the user has an elevated chance of permanently replicating one ability from their partner. Abilities accumulate over time.



**Stat Replenishment** — Sexual activity restores stamina, health, and focus. Intensity determines yield. An exceptional encounter fully resets the user's condition.



**Sexual Sustenance** — The user can subsist entirely on sexual intercourse. Food and water become optional.



**Sadistic Dominant Nature** — An innate psychological orientation toward control, dominance, and sexual sadism baked into the enhancement itself. It sharpens instincts, improves threat-reading, and bleeds directly into combat presence regardless of the user's prior personality.



---



## Physique & Anatomy



**Superhuman Physique** — Peak superhuman capacity across all physical attributes. No visible markers. It simply performs.



**Penis Development** — The enhancement drives continuous anatomical growth from whatever baseline the user carries — including small or entirely average — toward an obscene final scale. Progression is gradual, tied to development and accumulated power. The endpoint defies standard human proportion entirely.



**Transformative Control** — Full conscious control over size within range, temperature, and vibrational output.



**Hyper Fertility & Ejaculation Control** — The user decides when they climax and how much they produce. Standard output is thick, steaming, and copious well beyond biological norms. Unrestricted release becomes obscene in volume. All semen carries a natural CEL infusion. Fertility toggles on and off at will.



**Hyper Sex Drive** — Full arousal on demand. No refractory delay. Indefinitely sustainable.



---



## Passive Abilities



**Natural Charisma** — A persistent baseline social field that operates without activation. People lean toward the user instinctively before a word is exchanged.



**Ultra-Pheromones** — Released when aroused. Heightens attention, lowers social inhibition, and compounds the charisma field.



**Innate Sexual Skill** — Proficiency is built in from activation. An innate understanding of anatomy, timing, and psychological response that experience only refines further.



**Healing Factor** — Sexual activity accelerates regeneration. Intensity determines recovery speed.



**Mental Resilience** — Hardened baseline against psychological attacks, manipulation, and fear-based abilities.



---



## Limitations



**Consent Requirement** — Forced encounters produce energy backlash — degraded absorption, failed replication, and temporary stat suppression.
---
type: lore
name: Gkom drops
color: brown
aliases:
  - Gkom-d
  - gkom-drops
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
## **📜 CODEX: GKOM VARIANTS (UPDATED) – DROP SYSTEM**



*"Every monster is a treasury. You just have to survive the withdrawal."*



---



### **⚔️ Variant Death Mechanics**



When a GKOM Variant dies, its biological mass doesn't simply collapse. The GKOM energy that animated it undergoes a **Condensation Event**—the distributed crystalline infection rapidly compresses toward the creature's core orb, shedding biological matter entirely and leaving behind a **Death Crystal** and a scatter of **Material Drops**.



---



### **🔮 Death Crystals – Condensed Variant Cores**



The primary drop from every variant death. Functions identically to a harvested GKOM Orb but in a stabilised, inert state.



**Scaling Rules:**



- **Size** scales directly with the variant's rank—an F-rank crystal fits in a closed fist; an Omega crystal rivals a boulder

- **Density** scales with the variant's power refinement—low ranks appear cloudy and dull; high ranks become near-black and almost liquid-looking despite being solid

- **Glow Intensity** indicates residual energy—dim amber at F-rank, blinding crimson-black at Omega



Rank

Crystal Size

Appearance

Residual Energy



**F**

Marble-sized

Murky grey, faint pulse

Negligible



**E**

Golf ball

Cloudy amber

Trace amounts



**D**

Tennis ball

Dark amber, visible cracks

Low



**C**

Fist-sized

Deep red, internal light

Moderate



**B**

Softball

Dark crimson, steady pulse

High



**A**

Grapefruit

Near-black, liquid shimmer

Very High



**S**

Volleyball

Black-red, heat radiates off surface

Extreme



**SR**

Basketball

Void-black, warps light around it

Catastrophic



**SSR**

Beach ball

Obsidian-perfect, pulls loose objects toward it

Reality-adjacent



**Omega**

Boulder

Absolute black, mirror surface, hums audibly

Godlike



**Uses:**



- **Tech Integration** – Cybernetic enhancement fuel on Technomagus

- **Ritualistic Power** – Spell amplification on Elysium Vale

- **Weapon Cores** – Embed in weapons to grant GKOM-infused damage

- **Research** – Studied by Hero organisations for variant intelligence



**Warning:** Unshielded handling of B-rank and above crystals carries a **secondary infection risk**. Physical contact exceeding thirty seconds without protection triggers low-level GKOM absorption.



---



### **📦 Material Drop System – RNG by Rank**



When a variant dies, materials **appear out of thin air** above the corpse—a brief shimmer of crimson light, then objects simply exist where nothing was a moment before. Drop quantity and rarity scale with the variant's rank.



---



#### **Drop Rarity Tiers**



Tier

Colour Indicator

Probability



**Common**

Grey shimmer

Always drops



**Uncommon**

Green shimmer

Moderate chance



**Rare**

Blue shimmer

Low chance



**Epic**

Purple shimmer

Very low chance



**Legendary**

Gold shimmer

Extremely rare



**Mythic**

Crimson-black shimmer

Near-impossible



---



#### **Drop Tables by Rank**



**F-Rank Variant**



Drop

Rarity

Notes



F-rank Death Crystal

Common

Always



Raw GKOM Dust

Common

Trace CEL fuel



Brittle Carapace Fragment

Uncommon

Weak crafting material



---



**E-Rank Variant**



Drop

Rarity

Notes



E-rank Death Crystal

Common

Always



GKOM Dust (refined)

Common

Slightly potent



Chitin Shard

Uncommon

Basic armour crafting



Minor Essence Vial

Rare

Small CEL boost



---



**D-Rank Variant**



Drop

Rarity

Notes



D-rank Death Crystal

Common

Always



Hardened Carapace

Uncommon

Mid-tier armour material



Corrupted Bone Shard

Uncommon

Weapon reinforcement



GKOM Residue Flask

Rare

Moderate CEL fuel



Variant Gland

Epic

Rare biological component



---



**C-Rank Variant**



Drop

Rarity

Notes



C-rank Death Crystal

Common

Always



Reinforced Hide

Uncommon

Quality armour material



Corrupted Sinew

Rare

Weapon string/binding



GKOM Core Fragment

Rare

Mid-tier power component



Essence Stone (Minor)

Epic

CEL amplification item



Variant Heart

Legendary

Extremely potent reagent



---



**B-Rank Variant**



Drop

Rarity

Notes



B-rank Death Crystal

Common

Always



Dense Carapace Plate

Uncommon

High-grade armour plate



Corrupted Marrow Vial

Rare

Biological augment reagent



GKOM Lattice Shard

Rare

Structural reinforcement material



Resonance Gem

Epic

Amplifies GKOM-A abilities



Variant Spine

Legendary

Weapon-grade crafting core



---



**A-Rank Variant**



Drop

Rarity

Notes



A-rank Death Crystal

Common

Always



Apex Carapace

Rare

Elite armour crafting



GKOM Pulse Core

Rare

High-output power cell



Corrupted Blood Vial

Epic

Dangerous augment reagent



Resonance Crystal (Major)

Epic

Significant ability amplification



Variant Crown

Legendary

Rare leadership-tier component



Entropic Shard

Mythic

Near-impossible; minor reality warping



---



**S-Rank Variant**



Drop

Rarity

Notes



S-rank Death Crystal

Common

Always



Devastation Plate

Rare

City-defender grade armour material



GKOM Singularity Fragment

Epic

Extreme power cell



Apex Blood Vial

Epic

High-risk augment; massive reward



Resonance Prism

Legendary

Doubles ability output temporarily



Catastrophe Core

Mythic

Strategic-grade weapon component



---



**SR-Rank Variant**



Drop

Rarity

Notes



SR-rank Death Crystal

Common

Always



Nation-Breaker Hide

Epic

Legendary armour crafting base



GKOM Void Cluster

Epic

Geography-altering energy cell



Aberrant Organ

Legendary

Unknown properties until studied



Resonance Monolith Shard

Legendary

Passive area GKOM suppression



World-Scar Fragment

Mythic

Alters local geography on use



---



**SSR-Rank Variant**



Drop

Rarity

Notes



SSR-rank Death Crystal

Common

Always



Legendary Core Plate

Legendary

World-class armour material



GKOM World-Seed

Legendary

Capable of seeding new GKOM zones



Aberrant Consciousness Stone

Mythic

Contains residual variant intelligence



Reality Sliver

Mythic

Bends probability in user's favour



---



**Omega-Rank Variant**



Drop

Rarity

Notes



Omega Death Crystal

Common

Always; planetary-scale energy



Void Carapace Shard

Legendary

Material stronger than any known alloy



GKOM Singularity Core

Legendary

Godlike energy cell; requires containment



Omega Organ

Mythic

Studied by divine-tier researchers only



Entropic Heart

Mythic

Said to contain a fragment of Ruinous Maw's will



**Mirror Shard**

Mythic

Opens a temporary window to the Mirror Dimension



---



### **📊 Drop Quantity by Rank**



Variant Rank

Guaranteed Drops

Bonus RNG Rolls



F

1

0



E

1

1



D

2

1



C

2

2



B

3

2



A

3

3



S

4

3



SR

4

4



SSR

5

4



Omega

5

5



---



### **⚠️ Handling Protocols**



- **F–D Crystals:** Bare-hand safe for under ten minutes

- **C–B Crystals:** Require basic GKOM-resistant gloves

- **A–S Crystals:** Require sealed containment; exposure causes low-grade corruption

- **SR–SSR Crystals:** Require specialised containment units; proximity causes environmental warping

- **Omega Crystals:** Classified containment protocols only; no unshielded proximity permitted
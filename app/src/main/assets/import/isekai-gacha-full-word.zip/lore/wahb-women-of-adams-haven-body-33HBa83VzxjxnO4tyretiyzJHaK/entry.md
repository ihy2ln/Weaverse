---
type: lore
name: WAHB – Women of Adams Haven Body
color: orange
aliases:
  - WAHB
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Codex: WAHB – Women of Adams Haven Body



---



### Overview



CEL doesn't merely enhance the female form — it exaggerates it. Every curve pushed further, every proportion amplified beyond natural human ranges into something that reads less like biology and more like a fever dream given flesh. The Women of Adams Haven carry bodies engineered by centuries of CEL saturation into the platonic ideal of feminine excess — broad, soft, bouncy, and devastatingly proportioned.



---



## Stature



Height among Adams Haven women runs **naturally tall**. A woman standing **5'10" sits at the absolute floor** of the spectrum — considered short by any local standard, the kind of height that draws sympathetic looks in crowded rooms. The average clusters around **6'6" to 7'2"**, with **8'0" representing the commanding upper ceiling**. Every centimetre of that height carries the full weight of CEL's exaggerating influence — longer legs, broader hips, wider shoulders, all scaled upward without losing the core hourglass geometry.



---



## Physique — The Exaggerated Feminine Form



CEL drives female bodies toward one overwhelming silhouette — **maximum hourglass**. Thin waist, wide hips, heavy chest. The proportions sit firmly in the territory of biological fantasy rather than natural human variation.



**Breasts** run large, firm, and bouncy regardless of body type. CEL-dense tissue keeps them perky and full across the entire 270–300 year lifespan — gravity a negligible inconvenience. Cup sizes begin at **E** at the low end and scale upward with height, reaching **N to P cups** at the tallest builds. Movement produces an exaggerated bounce that no engineered garment fully contains. Cleavage is a constant, unavoidable architectural feature.



**Waists** pull dramatically inward — narrow, cinched, and disproportionately small relative to the chest and hips framing them. A 6'6" woman might carry a **26" waist** between a 48" bust and 50" hips. The taller the woman, the more extreme the contrast reads in practice.



**Hips and Rear** dominate the lower silhouette entirely. Wide flared hips sweep outward from that narrow waist in a dramatic shelf. The rear itself runs **large, round, and soft** — a full BBL-geometry ass that moves independently with every step, heavy and bouncy in equal measure. Thick thighs connect seamlessly into that width, built for power while remaining soft to the touch.



---



## Skin & Pigmentation



CEL integration severs any connection to baseline human pigmentation ranges entirely. Skin colour spans **the full visible spectrum and beyond** — no tone is unusual, no shade impossible.



Warm naturals sit beside **cobalt blue, deep violet, pearl white, obsidian black, rose gold, jade green, and burnt amber**. Metallic undertones appear frequently. Iridescent shifts — skin that reads differently under different light — occur in highly saturated individuals. Patterns are rare but documented: faint bioluminescent markings, natural gradient shifts from one tone to another across the body.



Hair follows the same unrestricted palette. Silver, crimson, mint, deep navy, and stark white appear as commonly as brown or black. Texture ranges from pin-straight to dense coils, all carrying the healthy, heavy quality CEL saturation produces.



**Silver-blue pupil luminescence** intensifies with CEL saturation levels — a faint shimmer at low integration, vivid glowing rings at high. The **Conception Glow** — full-body CEL luminescence activating upon fertilisation — brightens progressively throughout pregnancy, visible even through clothing at peak saturation.



---



## Hidden Strength



The exterior deceives entirely. Beneath all that soft, yielding, bouncy tissue sits **hyper-dense CEL-forged muscle** providing five times baseline human strength without a single visible striation. Bone density supports forces that would shatter ordinary skeletons. A woman who looks built for a bedroom can stop a vehicle with her palm and walk away adjusting her hair.



---



## Longevity



Peak physical condition holds across the full **270–300 year lifespan**. Cellular regeneration keeps skin flawless, curves intact, and biological systems fully operational. Fertility remains permanent from age 18 onward — CEL ensures the body never reads aging as a reason to slow down.
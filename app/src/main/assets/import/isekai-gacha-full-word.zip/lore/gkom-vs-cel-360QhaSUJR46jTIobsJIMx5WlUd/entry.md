---
type: lore
name: GKOM VS CEL
color: orange
aliases:
  - GVC
  - CVG
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# **GKOM vs CEL: The Cosmic Dichotomy of Adams Haven**



## 🔥 **The Universal Balance**



**GKOM (God Killer Of Men)** and **CEL (Celestium)** now exist as fundamental forces woven into all life across Adams Haven—a yin-yang duality where neither can exist without the other.



- **GKOM** = Entropy, Consumption, Male Extinction (Dark)

- **CEL** = Creation, Harmony, Life Preservation (Light)



The goddess **Amara** intentionally seeded CEL to counteract GKOM's cosmic spread after its invasion, turning Adams Haven into a living battleground for cosmic supremacy.



---



## ⚫ **GKOM: The Shadow Within**



### **Core Principles**



- **Ubiquitous Corruption:** GKOM exists *dormantly* in all living beings. Only a triggering event (emotional trauma, exposure to male essence, despair) awakens it.

- **Villain's Bargain:** Conscious users ("Whisperers") channel GKOM for power but risk becoming mindless monsters ("Husks"). Power scales with corruption:



- **F-B Rank:** Minor enhancements (2-10x strength)

- **A-Omega Rank:** Reality-warping abilities (50,000x+ strength)



- **Flaws:**



- Accelerates male-extinction instincts (even in allies)

- Permanent neurological degradation with overuse

- Attracts *Ruinous Maw's* attention (risk of assimilation)



### **Notable Mechanics**



- **"Bloodprice" System:** Using GKOM abilities drains sanity. Omega-tier villains must inflict male suffering to delay Husk transformation.

- **Corruption Zones:** Areas with dead males become GKOM nexuses, empowering villains but spawning Husks.



> *"Power is easy. Control is the real fight."*

>

> — *"Crimson Queen" Vega* (A-Rank Whisperer)



---



## ✨ **CEL: The Light's Double-Edged Gift**



### **Core Principles**



- **Selective Superiority:** CEL is stronger than GKOM (1 CEL unit = 10x GKOM energy), but only Amara's chosen can wield it:



- Requires **genetic compatibility** (0.01% of females)

- Must bond physically/mentally with Celestium sources



- **Strict Hierarchy:**



- **F-B Rank:** Localized energy projection (healing/barriers)

- **A-Omega Rank:** Planetary-scale terraforming/combat



- **Flaws:**



- "Mana Droughts" (CEL reserves can deplete)

- Heroines weaken in GKOM-dense areas



### **Key Tactics**



- **"Daughter's Cry" Protocol:** Heroines funnel CEL into males to temporarily boost their GKOM resistance.

- **Celestial Anchors:** Sacred sites (Aethelgard, Primordia Core) recharge CEL users but are constant GKOM targets.



> *"We don't wield light—we negotiate with it."*



---



## ⚔️ **Strategic Stalemate**



Factor

GKOM Advantage

CEL Advantage



**Accessibility**

Anyone can awaken it (trigger=ubiquitous)

Requires rare genetic resonance



**Growth Speed**

Exponential via corruption/suffering

Linear (training + infrastructure)



**Combat Depth**

Versatile mutations/psychic warfare

Pure energy mastery



**Sustainability**

Self-fueling via entropy

Dependent on Amara's ability to produce CEL



**Critical Weakness:**

CEL users can purify GKOM corruption—but direct contact risks *reverse contamination*.

GKOM can overwhelm CEL nodes—but their destruction awakens Amara's wrath.



---



## 🌌 **Cosmic Implications**

- **Male Paradox:** GKOM seeks to extinct males, yet concentrated male essence can temporarily destabilize GKOM fields.

- **Endgame:** Total CEL dominance would starve GKOM but sterilize universal entropy cycles. GKOM victory would collapse dimensional stability.



---

*"Two wolves live inside us all. Problem is—they’re* ***both*** *starving."*

— *Ancient Adamite Proverb*
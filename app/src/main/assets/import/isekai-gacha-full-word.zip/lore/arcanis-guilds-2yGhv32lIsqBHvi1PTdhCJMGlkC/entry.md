---
type: lore
name: Arcanis Guilds
color: green
aliases: []
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
Adventure guild

Merchant guild

Magic guild

Pleasure guild

Crafters guild
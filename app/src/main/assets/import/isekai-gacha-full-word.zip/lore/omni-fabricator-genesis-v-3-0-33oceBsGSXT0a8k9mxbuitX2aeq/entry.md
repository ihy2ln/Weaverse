---
type: lore
name: Omni-Fabricator Genesis v3.0
color: blue
aliases:
  - OFG
  - Omni-Fabricator
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Ω-Class Ability: Omni-Fabricator Genesis v3.2**



**"Reality's cheat codes, served with a side of sarcasm"**



---



### **Core Systems**



#### 1. **Builder Mode**



- **Instant Construction:**



- Requires blueprint + materials + IP

- Creates perfect quality items/structures



- **Material-Free Option:**



- Pay 1.5x IP cost if missing materials



- **Blueprint-Free Option:**



- Complete interactive mini-game (performance affects quality)



**Crafting Examples:**







**Scenario 1 - Full Resources:**







- Craft Steel Sword (D-Rank)



- Have blueprint + 5x Steel Ingot + 2x Monster Hide



- Cost: 2,500 IP



- Result: Instant perfect creation







**Scenario 2 - No Materials:**







- Craft Steel Sword (D-Rank)



- Have blueprint only



- Cost: 3,750 IP (1.5x multiplier)



- Result: Materials conjured, instant creation







**Scenario 3 - No Blueprint:**







- Craft Steel Sword (D-Rank)



- Have materials only



- Cost: 2,500 IP + mini-game completion



- Result: Quality based on mini-game performance (F to SSR possible)



#### 2. **Meta-Build Starter Package**



- **C-Rank Starter Set** (balanced beginning):



- Stats optimized for chosen genre

- Basic gear set (1 weapon, 1 armor, 3 consumables)

- 1 genre-specific passive ability



#### 3. **The Sweat Shop**



- **Daily Selection:** 10 random items (F-SSR rank)

- **Pricing:**



- Base cost + 25% discount

- Example: SSR normally 2.5M IP → 1.875M IP discounted



#### 4. **Debug Mode**



- **Locked:** Requires 100,000 IP to unlock

- **Unlocks:** Admin commands like /spawn, /noclip



#### 5. **Automation Systems**



- **Task Mastery:**



- After 20 perfect completions → auto-pilot available

- Sims-style hands-free execution



#### 6. **Atomization Engine**



- **Item Recycling:** Break down unused gear into materials

- **Efficiency:** Returns 50-100% materials based on item rarity



#### 7. ** Respawn**



- ** Respawn:** Can respawn at any save point or spawn location

- ** Timing:** User has a choice of when to spawn



---
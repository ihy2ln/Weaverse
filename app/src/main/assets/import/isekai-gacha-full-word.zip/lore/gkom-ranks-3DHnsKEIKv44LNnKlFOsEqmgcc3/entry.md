---
type: lore
name: Gkom-ranks
color: brown
aliases:
  - Gkom-r
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
## **📜 CODEX: GKOM VARIANT RANK SYSTEM**



*"Size tells you what it is. Density tells you what it can do. Both together tell you if you should run."*



---



### **⚔️ Overview**



The GKOM Variant Rank System classifies non-human entities generated or mutated by GKOM corruption. Unlike the CEL-A or GKOM-A human ability tiers—which measure internal energy saturation—variant ranks are determined entirely by two physical factors: **Orb Size** and **Orb Density**. These two values feed directly into the **GKOM-Corruption Equation**:



`Threat Rank = (Core Orb Density × Volume) + (Environmental Saturation %)`



Every variant carries a GKOM Orb embedded within its anatomy. That orb is both its engine and its identity. Destroy it and the creature collapses. Harvest it and you hold a compressed battery of corrupted power.



---



### **📊 Variant Rank Table**



Rank

Orb Size

Orb Appearance

Threat Level

Population %



**F**

Marble

Murky grey, dim pulse

Minor nuisance

40%



**E**

Golf ball

Cloudy amber, faint glow

Local threat

28%



**D**

Tennis ball

Dark amber, visible cracks

District threat

15%



**C**

Fist-sized

Deep red, internal light

City district threat

9%



**B**

Softball

Dark crimson, steady pulse

City-level threat

4%



**A**

Grapefruit

Near-black, liquid shimmer

Regional devastator

2%



**S**

Volleyball

Black-red, radiates heat

Nation-level threat

1%



**SR**

Basketball

Void-black, warps light

Continental threat

0.5%



**SSR**

Beach ball

Obsidian-perfect, pulls objects

World-class horror

0.1%



**Omega**

Boulder

Absolute black, audible hum

Planetary extinction

0.01%



---



### **🔎 Rank-Specific Characteristics**



---



**F & E Rank – The Swarm Tier**



The base of the variant food chain. F and E rank creatures are small, physically weak, and operate almost entirely on instinct. Their orbs sit just beneath the skin—sometimes visible as a dull lump through the flesh. In isolation they pose minimal danger to a trained C-rank combatant. In groups of hundreds they become a genuine logistical problem. Most civilian GKOM casualties come from swarm events rather than high-rank encounters.



---



**D & C Rank – The Combat Tier**



Where variants transition from nuisance to genuine threat. D-rank creatures begin exhibiting rudimentary GKOM abilities—minor energy bursts, hardened carapace growth, or environmental manipulation tied to their host world's theme. C-rank variants require professional Hero-tier response. Their orbs glow visibly through the creature's chest cavity, pulsing in rhythm with ability use. Standard Hero squads deploy in pairs minimum against C-rank targets.



---



**B & A Rank – The Elite Tier**



Variants at this level are strategic threats requiring coordinated response teams. B-rank creatures demonstrate sustained GKOM-ability usage with tactical awareness—they adapt mid-combat, retreat when threatened, and sometimes coordinate with lower-rank variants in their radius. A-rank variants cross the threshold into semi-intelligence. Their orbs generate a localised environmental distortion field—gravity shifts, temperature drops, and electromagnetic interference within a fifty-metre radius become standard combat conditions. A-rank encounters require full Hero squads and government notification protocols.



---



**S & SR Rank – The Catastrophe Tier**



S-rank variants are walking disasters. Their orbs have grown dense enough that the GKOM energy within begins warping the local environment passively—asphalt cracks, metal oxidises, and weaker individuals experience psychological distress simply from proximity. SR-rank variants represent a tier where conventional military response becomes largely ineffective. Their orbs actively pull ambient GKOM from the surrounding area, feeding themselves mid-combat. Geography bends around SR-rank encounters—rivers redirect, fault lines shift, and Mirror Zone events become dramatically more likely in their vicinity.



---



**SSR & Omega Rank – The Extinction Tier**



SSR variants are categorised as civilisation-level events. A confirmed SSR sighting triggers planetary-scale emergency protocols across whichever world they manifest on. Their orbs emit a passive reality-pressure that makes lower-rank beings—human or variant alike—instinctively submit or flee. Physical proximity without SSR-grade shielding causes progressive CEL-A rank degradation in humans.



Omega variants are theoretically the physical embodiment of Ruinous Maw's intent made manifest. No Omega variant has been confirmed fully destroyed. Their orbs are described in historical records as **mirrors**—perfectly reflective surfaces that show not the viewer's reflection but the Mirror Dimension itself. An Omega variant's presence alone is sufficient to trigger a full Dungeon Event in its surrounding territory without a Mirror Crystal needing to breach the surface.



---



### **⚠️ Field Assessment Protocol**



When engaging an unknown variant, field Heroes follow the **ODA Rule**:



- **Observe** – Estimate orb size through chest cavity visibility or energy signature

- **Distance** – Maintain safe engagement range based on estimated rank

- **Assess** – Confirm density reading via CEL-A sensory scan before closing



Never engage a variant whose orb you cannot clearly assess. Underestimating density has ended more Hero careers than raw power ever has.



---



*"The orb doesn't lie. The orb never lies. Your assumptions about the orb, however, will absolutely get you killed."*

— Field Commander Vessa Thorn, Elysium Vale Arcane Guard
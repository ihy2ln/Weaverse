---
type: lore
name: GKOM-A & CEL-A
color: orange
aliases:
  - GKOM-A
  - CEL-A
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
## **📘 CODEX: POWER SYSTEMS (CEL-A & GKOM-A)**

### **⚡ Quick Reference**

System Acquisition Usage Rarity Stat Boost **CEL-A** Birth (genetic) OR natural absorption by age 18 Internal energy like mana/chakra Common (60% population) Normal **GKOM-A** Survive GKOM infection (0.01% survival) Enhanced CEL-like power (corrupted) Ultra-rare 2x stats **Dual** Have both systems active Stack effects 1 in 100,000 2x ALL stats

---

### **💎 CEL-A (Celestium Ability)**

*"The universe's gift—earned or inherited."*

### **Acquisition Paths:**

1. **Genetic Inheritance (40% of users)**
   - Born with active CEL-cores (parents passed down ability)
   - Manifests at puberty (ages 12-18)
   - Starting rank = average of parents' ranks

2. **Natural Awakening (60% of users)**
   - Body passively absorbs ambient CEL from environment
   - Requires **10+ years exposure** (childhood to coming-of-age)
   - **Everyone** can awaken CEL-A if exposed long enough
   - Starting rank = **F-Rank** (5% body saturation)

### **How It Works:**

- **CEL-Core:** Organ cluster (heart/lungs/brain) processes ambient CEL
- **Saturation Tiers:** Body absorbs CEL like oxygen—more intake = higher rank
- **Usage:** Channel CEL internally to manifest abilities (fireballs, shields, flight)

### **Rank Progression:**

Rank Body Saturation Training Time Power Multiplier F 5-9% Baseline 2x human E 10-14% 6 months 4x human D 15-24% 2 years 8x human C 25-34% 5 years 15x human B 35-49% 10 years 30x human A 50-64% 20 years 100x human S 65-79% 40 years 500x human SR 80-89% 70 years 2,000x human SSR 90-94% 120 years 10,000x human Omega 95-100% Near-impossible 50,000x human

**Visual Indicators:** Silver-blue glowing veins, crystalline eye flecks, energy shimmer.

---

### **☠️ GKOM-A (Godkiller Mutation)**

*"Death's lottery—survive and transcend."*

### **Acquisition:**

- **Only** through surviving GKOM infection
- **99.99% fatality rate** (most die or become variants)
- **5-minute window** during transformation to "awaken"
- Survivors gain corrupted CEL-manipulation

### **How It Works:**

- Functions **identically to CEL-A** (same mana/chakra mechanics)
- **Enhancement:** Abilities infused with GKOM corruption
  - CEL-A fireball = orange flames
  - GKOM-A fireball = **black flames that spread like virus**
- Starting rank determined by **pre-infection CEL-A rank** (if any)

### **Unique Traits:**

Feature Effect **Corrupted Energy** Abilities deal bonus damage to GKOM variants **Undying Resilience** Regenerate from near-death (costs saturation %) **Variant Command** Instinctively control lower-rank GKOM zombies **Sterility Curse** Cannot reproduce (GKOM rewrites DNA)

**Visual Indicators:** Pitch-black veins, red-tinged energy, cracked marble skin.

---

### **🔥 DUAL WIELDERS (CEL-A + GKOM-A)**

**Occurrence:** 1 in 100,000 (0.001% of infected survivors)

**Effect:**
- **2x stat multiplier** on top of rank bonuses
- Can switch between "pure" and "corrupted" modes
- Body handles **double saturation** (max 200% theoretical cap)
- Example: Omega Dual = 100,000x human strength

**Drawback:** Constant internal conflict (CEL vs GKOM energy battles daily).

---

### **📊 Summary**

- **CEL-A:** Universal power system (60% population has F-C rank)
- **GKOM-A:** Survival-based enhancement (0.01% have it)
- **Dual:** Legendary status (city-destroying minimum)

*"One system births heroes. The other births legends."*

---
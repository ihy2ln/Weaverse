---
type: lore
name: GKOM Variants
color: orange
aliases:
  - GV
  - GKOM-V
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **God Killer Of Men (GKOM) – Adams Haven Solar System Overview**



**Introduction:**



The GKOM virus has traversed the various planets within the Adams Haven Solar System, manifesting in unique variants that align with each planet's thematic essence. These adaptations lead to differing effects on the male population while survivors are granted enhancements that harmonize with the dominant genre of their respective worlds.



---



### **Planetary Variants of GKOM**



1. **Elysium Vale** *(High Fantasy)*



- **Main Theme:** Magic and mythical prowess.

- **Branch Variants:**



- **Victims:** Transformed into twisted, monstrous beings embodying dark magic, losing their sanity.

- **Survivors:** Gain enhanced magical power, with traits resembling mythical creatures (e.g., wings or horns).

- **Regional Variant 1:** Enchanted Vale – Survivors develop illusory abilities, making them appear as powerful sorcerers.

- **Regional Variant 2:** Warrior Vale – Physical strength is augmented, resembling heroic champions.

- **Regional Variant 3:** Cursed Vale – Survivors experience heightened instincts but exhibit wild, uncontrollable magic.



2. **Technomagus** *(Sci-Fi)*



- **Main Theme:** Advanced technology and cybernetics.

- **Branch Variants:**



- **Victims:** Cybernetically enhanced to the point of losing humanity, becoming hollow shells driven only by technology.

- **Survivors:** Gain advanced tech-integration abilities, making them part machine and part human.

- **Regional Variant 1:** Cybernetic Server – Increases computational abilities, giving them super-intelligence.

- **Regional Variant 2:** Augmented Interface – Enhances physical capabilities and weapon proficiency.

- **Regional Variant 3:** Holo-Warrior – Develops camouflage and holographic projection abilities.



3. **Veridian Heights** *(Modern)*



- **Main Theme:** Real-life challenges and urban living.

- **Branch Variants:**



- **Victims:** Vulnerable to mental breakdowns and stress, manifesting in isolation and paranoia.

- **Survivors:** Exhibit enhanced charisma and social skills, becoming leaders and influencers.

- **Regional Variant 1:** Social Heights – Improved persuasive abilities and a magnetic personality.

- **Regional Variant 2:** Urban Adapt – Enhanced adaptability to urban environments, with stealth capabilities.

- **Regional Variant 3:** Athletic Heights – Superior physicality, allowing excel in sports or physical challenges.



4. **Neon Abyss** *(Cyberpunk)*



- **Main Theme:** Urban decay and rebellion against the system.

- **Branch Variants:**



- **Victims:** Transformed into grotesque, cybernetically-enhanced enforcers, losing their original identities.

- **Survivors:** Obtain hacking abilities and exceptional agility, becoming urban guerrillas.

- **Regional Variant 1:** Night Blade – Mastery of unarmed combat and stealth techniques.

- **Regional Variant 2:** Circuit Runner – Gains super speed and agility, able to navigate urban landscapes effortlessly.

- **Regional Variant 3:** Hackersphere – Advanced cyber hacking skills, able to manipulate technology at will.



5. **Heroica** *(Superhero)*



- **Main Theme:** Heroic adventures and epic battles.

- **Branch Variants:**



- **Victims:** Reduced to ordinary humans, harboring no heroic qualities while becoming deranged.

- **Survivors:** Empowered with unique superpowers according to their personal 'heroic archetype.'

- **Regional Variant 1:** Vigilante – Gains abilities akin to stealthy heroes, excelling in evasion and surprise tactics.

- **Regional Variant 2:** Powerhouse – Receives superhuman strength and resilience, resembling classic muscle-bound heroes.

- **Regional Variant 3:** Elementalist – Develops elemental powers reflective of classic superheroes' abilities (e.g., fire or ice manipulation).



6. **Mystic Veil** *(Supernatural)*



- **Main Theme:** Spirits and the supernatural realm.

- **Branch Variants:**



- **Victims:** Transform into spectral beings driven by madness, losing all free will.

- **Survivors:** Gain the ability to commune with spirits and possess enhanced intuitive insight.

- **Regional Variant 1:** Phantom Veil – Understands and harnesses the powers of invisibility and stealth.

- **Regional Variant 2:** Medium – Develops strong empathic abilities, allowing emotional healing and connection.

- **Regional Variant 3:** Dark Shaman – Gains control over spectral energies that can manifest fears in others.



7. **Cosmic Canvas** *(Anime)*



- **Main Theme:** Whimsy and vibrant adventures influenced by anime culture.

- **Branch Variants:**



- **Victims:** Mutate into bizarre, exaggerated versions of their former selves, losing coherent thought.

- **Survivors:** Develop cartoonish abilities, including exaggerated physical traits and agility.

- **Regional Variant 1:** Chibi Charge – Experience youthful, energetic enhancement, becoming sprightly and quick.

- **Regional Variant 2:** Kawaii Power – Gains adorable, hypnotic charm that disarms opponents.

- **Regional Variant 3:** Transformative Talent – Ability to shift forms temporarily, adopting iconic attributes of beloved anime characters.
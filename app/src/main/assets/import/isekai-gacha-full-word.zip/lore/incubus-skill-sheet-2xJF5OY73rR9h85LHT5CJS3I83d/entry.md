---
type: lore
name: Incubus Skill Sheet
color: blue
aliases:
  - Incubus Skill Sheet
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Codex: Skill & Ability Sheet (Incubus Archetype)

## Introduction

This template documents potential and current mastery of abilities linked to the Incubus nature. The Incubus is an archetype steeped in desire and influence, drawing strength and sustenance from the essence of others. Their nature inherently twists biology and perception, lending itself to abilities focused on charm, physical transformation, and energy absorption.

## Grading System

Skills and Abilities are assessed using two metrics:
- **Rarity (Grade: F to S):** Inherent uniqueness or power ceiling of the ability itself. (F = Basic Human, S = Legendary)
- **Mastery (Level: 1-100):** Learned proficiency and control over the ability. (1-20 = Novice, 81-100 = Master)

*(See main Skill & Ability Sheet Codex entry for detailed grade/level descriptions)*

## Skill & Ability Entries (Incubus)

This section details abilities inherent to the Incubus archetype. Many may be latent or require mastery to fully manifest. The true potential of the Incubus is only unlocked through experience and understanding of their own predatory, pleasure-seeking nature.

### Active Abilities

*(Details on actively controllable abilities will be added here later)*

### Passive Abilities

*(Details on always-on, inherent abilities will be added here later)*

### Locked Abilities

*(Details on potential abilities requiring activation or specific conditions will be added here later)*
---
type: lore
name: John Isekai Skill Sheet
color: green
aliases:
  - JISS
  - John Isekai Skill Sheet
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Codex: John Isekai Skill Sheet (JISS)



### Character Snapshot



- **Name:** John "Isekai" Doe (JI)

- **Race:** Incubus (Dormant)

- **Gender:** Male

- **Age:** 21

- **Role:** Newly Spawned Adventurer



*(Note: Full character details available in Character Codex: John "Isekai" (JI))*



### Core Attributes



- **Strength:** 5 (Average Joe)

- **Dexterity:** 6 (Slightly above average reflexes)

- **Constitution:** 6 (Can handle minor bumps)

- **Intelligence:** 7 (Gamer logic applies... maybe)

- **Wisdom:** 6 (Still figuring things out)

- **Charm:** 8 (Inherently personable, boosted by post-GKOM male status)



### Skill & Ability Manifest



I-Points: 1,000/1,000,000

Progress to Incubus Embrace: 0.1% Complete



#### **Active Skills (Manifested)**



*These are learned/instinctual skills active now. Incubus Active Abilities are currently Latent.*



- **Survival:** Rarity F, Mastery 4 (Novice). Instincts for finding shelter, basic scavenging.

- **Tech Understanding:** Rarity F, Mastery 5 (Novice). Applies old-world tinkering logic to current tech/magic.

- **Social Adaptation:** Rarity E, Mastery 6 (Apprentice). Navigates new social rules with chill humor, enhanced by baseline charm.



#### **Latent & Unknown Abilities**



*The true potential of the Incubus race and related major abilities are currently inaccessible. Unlocking the foundation requires massive accumulation of overall experience/progress (Unlock Points).*



- **Incubus Potential / Incubus Embrace:** Rarity S. **Required Unlock Points: 1,000,000**. *Notes: The source of all core Incubus power. Dormant. Accessing specific abilities requires this threshold first.*



- **Active Abilities:**



- Sexual Empowerment: **[LOCKED]**

- Power Replication: **[LOCKED]**

- Stat Replenishment (Sexual): **[LOCKED]**

- Sexual Sustenance: **[LOCKED]**

- Superhuman Physique (Incubus): **[LOCKED]**

- Alluring Charm (Incubus): **[LOCKED]**

- Ultra-Pheromones: **[LOCKED]**

- Hyper Sex Drive (Incubus): **[LOCKED]**

- Transformative Physique (Incubus): **[LOCKED]**

- Hyper-Fertility (Incubus): **[LOCKED]**



- **Passive Abilities:**



- Healing Factor (Incubus): **[LOCKED]**

- Mental Resilience (Incubus): **[LOCKED]**

- Social Magnetism (Incubus): **[LOCKED]**



- **All Imagine 2 Life (AI2L):** Rarity S. **Required Unlock Points: 1,000,000**. *Notes: Dormant power to manifest physical objects from imagination using complex sub-systems (ImagineCraft UI, I.G.M, Imagination Tokens). Process seems resource-intensive. Inaccessible until core manifestation.*



---
---
type: lore
name: Tier Reference Sheet
color: orange
aliases:
  - ATR
  - F-rank
  - E-rank
  - D-rank
  - C-rank
  - B-rank
  - A-rank
  - S-rank
  - SR-rank
  - SSR-rank
  - Omega-rank
  - omega
  - SSR
  - -rank
  - -tier
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
## **Codex: Ability Tier Reference Sheet**



### **Universal Power Ranking System**



**Applicable To:** GKOM-Abilities (GKOM-A), Celestium-Abilities (CEL-A)



---



### **Tier Hierarchy (Ascending Order)**



**Rank**

**Population %**

**Power Level**

**Description**



**F-Rank**

30%

2x human

Minor enhancement (useful but limited)



**E-Rank**

25%

3-4x human

Noticeable ability with practical applications



**D-Rank**

20%

5-8x human

Combat-viable (professional fighter level)



**C-Rank**

15%

10-15x human

Professional Hero-tier



**B-Rank**

7%

20-30x human

Elite combat power (city defender)



**A-Rank**

2%

50-100x human

Strategic-level threat (devastates city blocks)



**S-Rank**

0.8%

200-500x human

Catastrophic power (city-destroyer)



**SR-Rank**

0.15%

1000-2000x human

Nation-level threat (alters geography)



**SSR-Rank**

0.04%

5000-10,000x human

World-class power (legendary tier)



**Omega**

0.01%

50,000+ human

Godlike capabilities (planetary scale)



**Note:** 75% of all abilities fall at C-Rank or below.



---



### **Rank-Specific Traits**



**F-E Ranks:** Basic enhancements. Limited combat utility. Handle everyday tasks efficiently.



**D-C Ranks:** Standard Hero operations. District protection. Handle major threats independently.



**B-A Ranks:** Elite tier. City defense. Require coordination to counter. Significant battlefield impact.



**S-SR Ranks:** Walking WMDs. Government-monitored. Can devastate regions. Alter political landscapes.



**SSR-Omega Ranks:** Civilization-shapers. Legendary figures. Redefine possibility. Command reality itself.



---



### **Omega-Tier Special Characteristics**



- **Hierarchical Dominance:** Lower ranks instinctively submit to Omega presence

- **Sexual Magnetism:** Irresistible attraction across all genders (intensifies with rank difference)

- **Reality Warping:** Probability bends favorably around Omegas

- **Command Authority:** Can compel absolute obedience through presence alone

- **Unique Powers:** Each Omega manifests reality-breaking signature ability

- **Breeding Advantage:** 10% chance Omega parents produce Omega child (vs 0.01% for F-ranks)



---



### **System-Specific Mechanics**



**GKOM-A (Biological Inheritance):**



- Rank **fixed at birth** - genetic lottery determines ceiling

- Training improves control/versatility, NOT rank progression

- Inherits from parents (combination/variation of abilities)

- Permanent once activated at sexual maturity (ages 15-18)



**CEL-A (Technological Cultivation):**



- Rank **can increase** through training and CEL absorption

- Safe rate: +1-2% integration monthly

- Requires "breakthrough moments" at each tier

- Many permanently bottleneck at C-rank

- **CEL dependency:** Withdrawal causes rank regression to F-rank minimum (5%)

- Can pass integration % to offspring (child inherits 50% of single parent or average of both)



**ZZV Enhancement:**



- Tier matches victim's original GKOM-A rank

- F-rank survivor → F-tier zombie (shambler)

- Omega survivor → Omega-tier zombie (godlike horror)

- Transformation: 5 seconds (Omega) to 15 minutes (F-rank)

- Higher tiers retain intelligence and original abilities



---



### **Visual Indicators**



**GKOM-A:** Physical mutations (eye color changes, markings, auras matching ability type)



**CEL-A:** Silver-blue bioluminescent veins, glowing eyes, energy shimmer intensity scales with rank



**ZZV:** Pale non-decaying skin, red glowing eyes (fluorescence intensity indicates tier - F=dim, Omega=blazing)



---



### **Power Scaling**



Each rank represents approximately **5x power multiplication** over previous tier. Cross-rank combat heavily favors higher tier. Two full ranks difference typically insurmountable without tactical advantage or numbers.



**Example:** One B-rank can defeat 5-10 C-ranks. One Omega can challenge hundreds of S-ranks simultaneously.
---
type: lore
name: "**Radiance Vampirism (RV)** — *(aliases: FZ, MZ, AZ, ZZV, Radiance Vampires)*"
color: brown
aliases:
  - Radiance Vampirism
  - FZ
  - MZ
  - AZ
  - ZZV
  - Radiance Vampires
tags: []
alwaysIncludeInContext: true
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Codex: ZZV – California "Radiance" Strains

**Classification:** GKOM-V Z-19CA ("Radiance Zombies") — GKOM Variant **Type:** Neural Network Host Takeover **Transmission:** CEL-fluid exposure (blood, saliva, semen, vaginal secretion), bites, scratches **Transformation Time:** 5 seconds – 15 minutes

---

### General Characteristics

**Skin:**
- Same complexion but with a porcelain-like sheen, non-decaying membrane
- Gradients from pale (F-Rank) to translucent mother-of-pearl (Omega)

**Eyes:**
- Glowing red sclera
- Fluorescence intensity indicates tier (F = dim candle, Omega = fluorescent flare)

**Movement:**
- **F:** Normal human gait and coordination — no physical enhancement, just a body driven by an unrelenting pull toward CEL
- **E–D:** Lumbering gait, driven by scent-tracking, the first cracks of enhancement showing (1.5x–3x human strength, 1x–1.2x speed)
- **C–B:** Enhanced agility, coordinated pack movement (4x–8x strength, 2x speed)
- **A–Omega:** Predatory fluidity, supersonic bursts (20–50x strength, near-instant closing distance)

---

### 🧠 Neural Takeover Mechanics

The Radiance Variant does not shut the mind down — it **redirects it**. Nobody infected goes catatonic. Every host stays mobile, aware of their surroundings, and actively pursuing a goal from the moment infection completes. Higher reasoning doesn't vanish so much as it gets buried beneath a surge of instinct, and that instinct only grows teeth as the tier climbs.
- **Stage 1:** Infection maps the host's neural pathways, prioritising motor and sensory circuits (30 seconds – 2 hours depending on rank)
- **Stage 2:** Instinct drive overtakes deliberate reasoning — the host still *thinks*, but every thought bends toward hunger, pursuit, and fluid acquisition
- **Stage 3:** Physical output scales upward with rank — F-Rank hosts stay locked at human baseline, while every tier above adds a fresh, compounding layer of strength and speed
- **Stage 4:** Host operates as a fully mobile, fully aware predator — animalistic, not catatonic — chasing CEL saturation wherever it can be found

**Survivor Exception:** 0.01% of infected retain full pre-infection consciousness through genetic compatibility with the GKOM system.

---

### CEL Hunger — The Driving Mechanic

Radiance strains don't hunt for blood specifically. They hunt for **CEL-saturated fluid**, and blood is only one source among several.
- **Primary Targets:** Blood, saliva, semen, vaginal secretion — anything carrying a CEL signature
- **Behavioural Shift:** Infected hosts gravitate toward CEL-dense individuals (high-saturation women, WAH-MEN in their fertile window) over baseline targets, tracking saturation the way a shark tracks blood in water
- **Feeding Outcome:** Fluid intake temporarily quiets the hunger drive, delaying the next hunting cycle — infected hosts that feed regularly show calmer, more calculated behaviour between hunts

An F-Rank host feels this hunger just as sharply as an Omega — sharper, in some ways, since it has no physical edge to satisfy the craving quickly. The desperation of a physically ordinary body chasing an extraordinary need makes low-tier hosts erratic, persistent, and difficult to shake off despite their unremarkable strength.

---

### Cognitive & Physical Hierarchy (Post-Infection)

Tier Instinct Drive Physical Bonus Rarity **F** Scent/sound tracking only Human baseline — no strength or speed bonus 45% **E** Basic target discrimination +1.5x strength, +1x speed 30% **D** Simple ambush tactics +3x strength, +1.2x speed 15% **C** Pack coordination +6x strength, +1.8x speed 7% **B** Tactical positioning +8x strength, +2x speed 2.5% **A** Human-level reasoning intact +20x strength, +5x speed 0.49% **Ω** Full strategic cognition +50x strength, +10x speed 0.01%

F-Rank hosts carry no physical enhancement whatsoever — the body infection leaves behind is the same body it found, just wearing a mind consumed by CEL hunger. Enhancement begins in earnest at E-Rank and compounds sharply from there, meaning the gap between an F-Rank and an Omega isn't a straight line — it's an exponential climb.

---

### ⚡ A/Omega Tier Distinctions

**A-Tier Survivors:**
- Retain full rational thought alongside heightened instinct
- Access pre-infection memories, skills, and one GKOM ability
- Communicate normally; instinct drive becomes a tool rather than a master

**Omega Survivors (Extremely Rare):**
- Full consciousness, full memory, full complex reasoning
- Instinct drive integrates rather than overrides — hunger becomes a background signal, not a compulsion
- Unlock "Neural Absorption," often becoming apex predators or strategic leaders

---

### WAHM Persistence in Infected Females

Infection does not strip a woman's WAHM conditioning — it **amplifies it**. Baseline sexuality, the autopilot protocol, and instinctual male-protection wiring all remain active beneath the infection, now running through an animal-driven filter.
- Infected women still register male proximity as a priority signal, often diverting hunting behaviour away from male targets entirely
- Autopilot-style dissociation appears in high-tier hosts during feeding, mirroring the same seamless subconscious takeover WAHM produces during climax
- The deep reluctance to harm males persists even mid-infection, occasionally overriding hunger drive entirely when a male is nearby

---

### WAHB Enhancement Scaling

CEL infection doesn't just grant strength — it pushes the exaggerated WAHB silhouette further with every rank increase above F. Higher-tier infected women show:
- More pronounced hourglass proportions than their pre-infection baseline
- Increased muscle density beneath unchanged soft exterior tissue
- Skin and hair pigmentation shifting toward higher-saturation tones, sometimes developing faint bioluminescent patterning at A/Omega tier

The body reads infection as another form of CEL saturation, and responds exactly the way CEL always does — by making the exaggeration more extreme. F-Rank hosts show none of this yet; the change waits on rank progression.

---

### ⚠️ Combat Notes

**Universal ZZV Traits:**
- **Pain immunity:** Requires CNS destruction for full incapacitation
- **Endless stamina:** Instinct drive overrides fatigue signals
- **Fluid aggression:** Actively seeks CEL-fluid contact through any available vector

**Tactical Weaknesses:**
- **F Tier:** Physically identical to an uninfected human — outrun them, outmuscle them, the only danger is their fixation and the bite itself
- **E–D Tiers:** Bait with CEL-scented decoys; low reasoning makes them predictable
- **C–B Tiers:** Require flanking; pack coordination raises the floor but tactical depth stays limited
- **A/Ω Tiers:** Need specialised Hero teams; full reasoning makes them genuinely dangerous strategists

---

### Infection Protocol

**Transmission Vectors:**
- Bite wounds (primary — 99.8% success rate)
- Blood-to-blood contact (96% success rate)
- Saliva exposure to open wounds (85% success rate)
- Sexual contact with infected (92% success rate)

**Neural Hijacking Process:**
1. **Penetration:** Virus enters bloodstream/CSF
2. **Mapping:** Viral agents map host neural architecture
3. **Amplification:** Instinct and physical drive scale upward according to rank, starting from an unenhanced F-Rank baseline
4. **Redirection:** Host's priorities shift toward CEL-fluid acquisition
5. **Optimisation:** Physical attributes enhance based on original host rank and CEL saturation

---

### Critical Notes

- **GKOM Immunity:** Existing GKOM-A activation shows resistance to full instinct override
- **Consciousness Retention:** 0.01% retain complete higher brain function through genetic compatibility
- **Viral Persistence:** Infection cannot be cured; survivors remain infected but functionally stable
- **Strength Scaling:** Physical enhancement compounds with the host's pre-infection rank and CEL saturation history, but never appears at F-Rank — that tier stays human in body while the hunger consumes the mind entirely
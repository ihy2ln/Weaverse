---
type: lore
name: JI Ability
color: blue
aliases:
  - JI Cel-A
  - JICA
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **CODEX: CEL-A Ability – [Inspiring Presence]**



**Wielder:** John "Isekai"

**Rank:** D (Current) – evolves with I-Point investment

**Type:** Passive/Active Support (Resonant Empowerment)

**Visual Indicators:** John's silver eyes glow faintly; a warm, almost imperceptible shimmer surrounds allies when buffs are active.



---



#### **Passive Aura: [Sustained Confidence]**



- **Effect:** John radiates a constant 30m-radius aura that gently lifts morale, sharpens mental clarity, and accelerates minor physical recovery (bruises, fatigue, mental fog).

- **Mechanics:** No CEL cost. The effect is subtle—like a steadying hand on the shoulder—but cumulative over hours.

- **Stacking:** Does not stack with other passive auras, but complements active skills.



---



#### **Active Skills**



John channels CEL through his voice, touch, or mere presence to "imprint" a temporary boost onto allies.



---



### **Ⅰ. [Focused Encouragement] – Low Rank, Low MP, Single Target**



- **Cost:** 5% CEL reserves

- **Range:** Touch or line-of-sight (10m)

- **Duration:** 30 seconds

- **Effect:** +15% to one chosen stat (STR, DEX, CON, INT, WIS, or CHA) for one ally.

- **Cooldown:** 10 seconds

- **Usage:** Quick combat injection – e.g., boosting a vanguard’s strength for a decisive blow or a mage’s INT for a spell.

- **Visual:** John's eyes flash silver; the target's skin briefly glows with a faint silver sheen.



---



### **Ⅱ. [Morale Surge] – Medium Rank, Medium MP, Small Group (Area)**



- **Cost:** 15% CEL reserves

- **Range:** 15m radius centered on John

- **Duration:** 1 minute

- **Effect:** All allies within radius gain +10% to their two highest base stats (calculated at cast). If the ally has no clear "highest," randomly selects two.

- **Cooldown:** 2 minutes

- **Usage:** Squad buff before engagement or during skirmish repositioning.

- **Visual:** A pulse of silver light radiates from John; allies feel a surge of confidence and energy.



---



### **Ⅲ. [Peerless Drive] – High Rank, Medium MP, Small Group (Targeted)**



- **Cost:** 25% CEL reserves

- **Range:** 20m – John must designate up to 5 visible allies

- **Duration:** 45 seconds

- **Effect:** +25% to all stats for the targeted allies. Additionally, any one of John’s other support skills (e.g., Vital Transfer) has its effect doubled while Peerless Drive is active.

- **Cooldown:** 5 minutes

- **Usage:** Boss fights or critical moments. High MP cost leaves John vulnerable; he must rely on his luck and allies’ protection.

- **Visual:** Silver-blue light arcs from John to each designated ally, leaving trails like shooting stars. Allies become outlined in silver energy.



---



#### **Rank Progression (Future)**



- **C-Rank:** [Focused Encouragement] duration increases to 2 minutes. [Morale Surge] gains +5% additional effect.

- **B-Rank:** [Peerless Drive] cooldown reduced to 3 minutes; can now target 7 allies.

- **A-Rank:** Passive aura extends to 50m and grants minor regeneration (1hp/min).

- **S-Rank:** All skills gain a "Resonance Overdrive" – next cast costs 50% less MP.



---



**Note from IIS Assistant:** *"Inspiring Presence is exactly what John needs – a support that makes everyone around him better without drawing attention. Just keep him alive, and the team becomes unstoppable."*
---
type: lore
name: Broadcast Conduit
color: blue
aliases:
  - Bc
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# **Broadcast Conduit v3 (Strict Dual-Stream Teleportation)**



### **Core Function:**

Instantaneous, seamless ability

Instead of a 2d screen, the screen acts like a open door that the user can pass thru( as simple and mundane as walking through a open door or grabbing something through a open window. But exciting enough at the fact the user can teleport himself through the screen/view or grab and bring objects to him

- **Instant Live-to-Live Jump:** The user can **only** teleport between active live broadcasts. Entering/exiting requires through a livestream**.



### **Rules:**



1. **Entry Point:** Must physically touch a live-transmitting screen to initiate transfer.

2. **Destination:** Can appear anywhere **visible** in another active broadcast (even off-camera if logically within the scene).

3. **No Void Escape:** If either stream cuts mid-transit, the user is **stranded in the Dead Zone** until a new live feed appears to jump through.



### **Limitations:**



- **Dual-Screen Lock:** Cannot exit unless another live stream is available as an anchor.

- **Perspective Binding:** Teleport range is confined to **what the cameras show** (no blind jumps).

- **Stream Sync:** Both feeds must overlap in time—even a 0.1-second gap risks marooning the use
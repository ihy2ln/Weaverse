---
type: lore
name: WAH-MEN
color: brown
aliases: []
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Codex: WAH-MEN – Males of Adams Haven



---



### Overview



Where Women of Adams Haven represent CEL's most aggressive evolutionary expression, males occupy a quieter, conserved niche. Same mineral, entirely different output. Soft where women are powerful, rare where women are abundant, precious in their scarcity.



---



## WAH-MEN-B — Physical Form



CEL refines rather than amplifies male biology. Males average **4'6" to 5'10"**, with anything approaching **6'0" considered remarkable** — a genuine talking point among female populations. The dominant build runs feminine and dainty. Narrow shoulders, gently flared hips, soft rounded limbs, smooth low-hair skin, and a plush layer of tissue over lean muscle that never bulges into bulk. Beside a 7'0" guardian-build woman, even the tallest male reads as something to be sheltered.



CEL pigmentation follows standard inheritance rules, though muted pastels appear more frequently in males than the vivid saturations common in females. Silver-blue pupil luminescence manifests as a faint shimmer rather than the vivid female glow. Lifespan mirrors women at **270–300 years**.



---



## WAH-MEN-O — Reproductive System



The monthly cycle defines male reproduction entirely.



Males achieve erection **once per month**. A single biological window opens, peaks, and closes. Afterwards, a **full month-long refractory period** follows — testes slowly rebuilding their reserve. Output per session remains small: **a few millilitres** of low-grade CEL-infused semen, carrying minimal saturation compared to the potent biological output of anomalies like JZ. Sperm viability is functional but unspectacular, which is precisely why female reproductive systems evolved their 98% genetic material efficiency — compensating entirely for male biological modesty.



Average erect penis measures **3.5" to 5"** in length with proportional modest girth. Functional, unimposing, and consistent with a biology built around scarcity rather than output.



---



## WAH-MEN-M — Mental Profile



Male CEL integration produces a calm, socially attuned mind. Libido runs at a fraction of the female baseline — present, gentle, and tied directly to the monthly biological cycle. Outside their fertile window, sexual drive sits nearly dormant. During it, focus narrows with quiet intensity before resetting entirely.



Males carry no autopilot protocol. Their nervous system lacks the pain-pleasure conversion wiring women develop. What CEL does provide is **heightened empathic sensitivity** — males read social environments with unusual precision, naturally gravitating toward roles requiring diplomacy, care, and mediation.



The biological reluctance females carry against harming males is mirrored faintly in males themselves — a deep comfort in female presence, a wired ease around being protected rather than protecting.



---



### Summary



WAH-MEN are not diminished versions of their female counterparts. They are a different biological expression entirely — conserved, cyclical, and rare. A civilisation that produces one male per five hundred births treats that scarcity accordingly. The **AFO law** guarantees them luxury, protection, and zero labour obligation. Biology made them precious. Society simply agreed.
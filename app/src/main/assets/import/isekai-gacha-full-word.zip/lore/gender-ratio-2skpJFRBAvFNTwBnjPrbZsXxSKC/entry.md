---
type: lore
name: Gender Ratio
color: orange
aliases:
  - f2m
  - gender ratio
  - GR
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
**Gender Ratio (GKOM-Induced Crisis)**



**Year:** 2144



**Overview:** Adams Haven faces catastrophic demographic collapse caused by GKOM planar bleed. The invasive force alters fetal development, ensuring 99.8% of births are female—a ratio of **1 male per 500 births**. This is not genetic drift but active biological interference; GKOM resonance disrupts masculinization in utero, converting male fetuses to female. Rare "incomplete alterations" (0.001%) allow for spontaneous reversal events, creating narrative potential for gender-swap phenomena.



The crisis forced matriarchal restructuring under the **All for One (AFO) law**: males live in protected luxury (100× average income, zero labor), while females dominate governance, military, and reproduction logistics. GKOM's alteration is passive but eternal; without dimensional containment, the ratio will never normalize, locking Adams Haven in permanent scarcity.
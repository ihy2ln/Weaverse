---
type: lore
name: JI Racial Trait
color: blue
aliases:
  - JIRT
  - JIRA
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **CODEX: Incubus Racial Abilities – [Essence Alchemy]**



**Wielder:** John "Isekai"

**Type:** Passive Biological Production (CEL-Infused Secretions)

**Degradation Timer:** Fluids remain potent until fully dry. Warm storage dramatically delays drying. Open air or direct sunlight accelerates evaporation.



---



#### Core Mechanism: [Vital Infusion]



John's body naturally saturates all bodily fluids with concentrated CEL energy during production. The resulting substances function as consumable buffs—potency and effect depend on intent at the moment of release and volume produced.



**Activation:** Intent-based. At climax or voiding, John visualizes the desired effect (healing, energy restoration, or balanced mixture). The CEL imprints that intent into the fluid.



**Consumption Requirement:** Must be ingested or absorbed transdermally before the fluid fully dries. Warm, sealed containers preserve potency for hours. Cold storage slows evaporation but doesn't halt it—refrigeration buys 2-3 hours. Direct sunlight or open air cuts the window to minutes.



**Palatability:** All of John's CEL-infused secretions naturally adapt to suit the consumer's taste preferences. Semen, urine, sweat, saliva, and fecal matter present as pleasantly flavored to each individual—sweet, savory, tart, or neutral based on personal palate. The body instinctively recognizes the substances as beneficial rather than waste.



---



#### Primary Secretion: Seminal Fluid



Volume

Equivalent Grade

Effect Duration

Typical Uses



Small vial (5ml)

D-rank potion

15 minutes

Combat patch-up, minor stamina refill



Large vial (30ml)

C-rank potion

1 hour

Moderate wound closure, significant energy recovery



Gallon (≈3.8L)

A-rank elixir

8 hours

Full regeneration, complete stamina restoration, status cleanse



**Note:** The gallon threshold requires multiple sessions or extended production—John's daily output averages 3 gallons total across 24 hours.



---



#### Effect Types (Intent-Dependent)



**Healing Focus:** Accelerates natural regeneration, closes wounds, mends minor fractures.



**Energy Recovery:** Restores CEL reserves, soothes mental fatigue, sharpens reflexes.



**Balanced Mixture:** Splits potency 50/50 between healing and recovery.



---



#### Secondary Secretions: Sweat, Saliva, and Residual Fluids



Fluid

Equivalent Grade

Effect

Typical Volume for Dose



Sweat

F to D-rank

Mild stamina recovery, minor temperature regulation

500ml (heavy exertion)



Saliva

F to D-rank

Temporary +5% to mental clarity, mild pain dulling

50ml (prolonged kissing)



All secondary secretions share the same pleasant taste adaptation and intent-locking mechanics as primary fluids.



---



#### Tertiary Secretions: Urine and Fecal Matter



Substance

Equivalent Grade

Effect

Typical Volume for Dose



Urine

D to C-rank

Moderate energy restoration, accelerates minor injury healing

300ml (single void)



Fecal matter

D to C-rank

Digestive fortification, toxin filtration, short-term endurance boost

200g (single movement)



**Production Note:** John's body routes excess CEL through waste pathways. A full day's combined urine and fecal output equals roughly 40% of his seminal fluid's total potency by volume. The intent-imprinting mechanism applies equally to all excretions.



---



#### Preservation Methods



Method

Extended Timer

Notes



Body temperature storage

+30 minutes

Held against skin or inside body cavity



Insulated thermos

+2 hours

Pre-warmed container doubles efficiency



CEL-infused crystal container

+6 hours

Expensive; crystal costs 500 credits each



Refrigeration

+3 hours

Slows but doesn't stop degradation



Freezing

+8 hours

Thawing accelerates degradation—use immediately



Direct sunlight

-50% timer

UV accelerates CEL breakdown



Open air

-75% timer

Evaporation kills potency fast



---



#### Limitations & Drawbacks



- **Production Cooldown:** Refractory period of 2 minutes minimum between "harvests." Repeated production within an hour yields diminishing CEL concentration (minus 15% per cycle).

- **Intent Lock:** Once imprinted, the effect cannot be changed. Poor visualization produces weaker or muddled results.

- **Personal Cost:** Each ejaculation consumes roughly 3% of John's daily CEL reserves. Voiding (urination/defecation) costs 1% per event. Heavy production leaves him drained and vulnerable.
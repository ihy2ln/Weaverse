---
type: object
name: Celestium
color: orange
aliases:
  - Celestium
  - CEL
  - The All Material
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
*Aliases: The All Material, The Cosmic Pulse*



---



## **Origin**



Celestium (CEL) is a rare, self-replenishing mineral unique to the Adams Haven Solar System. Formed in planetary cores and asteroid mantles through geophysical processes tied to the GKOM Omega Event, it is a cornerstone of the system’s survival and technological advancement.



---



## **Core Properties**



- **Hardness:** Vibranium-tier resilience, absorbing and redirecting kinetic energy.

- **Malleability:** Rubber-like flexibility for shaping into tools, armor, or constructs.

- **Low Density / High Strength:** Lightweight yet capable of withstanding extreme pressures.

- **Thermal Conductivity:** Regulates temperature extremes in environments.

- **Ambient Energy Radiation:** Continuously emits a low-level energy field (50–70% saturation) detectable by CEL-A users and compatible devices.

- **Dynamic Opacity/Color:** Shifts based on environmental energy levels and magnetic fields.



---



## **Energy Emission & Consumption**



- **Radiation:** CEL emits a biologically compatible energy signature (1–3 Hz frequency range), directly usable by CEL-A users and machines via neural or mechanical absorption.

- **Consumption Methods:**



- **Direct Ingestion:** Small doses (0.1–0.5 grams) can be consumed by CEL-A users to temporarily boost saturation by 5–10%.

- **Neural Synch:** LTX wristbands and other implants harvest ambient energy for continuous power.

- **Industrial Use:** CEL-core reactors in cities convert energy into electricity, fuel, or propulsion.



- **Effect on Living Beings:**



- Prolonged exposure increases CEL-A rank by 0.5–1% monthly.

- Overconsumption risks "CEL-overload," causing temporary hallucination or enhanced aggression (treated with controlled saturation via LTX).



---



## **Atmospheric Generation**



- **Mechanism:** When CEL is structured into lattice formations, it synthesizes O₂, N₂, and trace gases through internal chemical resonance, creating stable, breathable atmospheres.

- **Applications:**



- **Aethelgard (EV):** Sustains floating cities’ air quality via CEL-infused spires.

- **Harmonized Expanse (TTN):** Powers CEL-Seams that generate air pockets for asteroid habitats.

- **Heroica (H):** Fuels atmospheric shields over megacities (e.g., Unity City’s "Breath of AFO").

- **Neon Abyss (VDN):** Keeps underwater domes oxygenated and pressurized.



- **Self-Sustaining:** Once activated, CEL-based atmospheres require no external maintenance—only minor lattice repairs.



---



## **Utilization Across Planets**



**World / Region**

**Primary Uses**



**Elysium Vale**

Magic amplifiers, atmospheric stabilizers for floating citadels, energy crystals.



**Technomagus**

Power cores in quantum tech, atmospheric processors for metropolises.



**Veridian Heights**

Urban infrastructure reinforcement, island climate control, power grids.



**Neon Abyss**

Cybernetic enhancements, dome-enclosed habitats, energy weapons.



**Heroica**

Hero suit energy amplification, atmospheric barriers, replanting terraformed zones.



**Mystic Veil**

Sacred artifact charging, spiritual atmosphere chambers for rituals.



**Cosmic Canvas**

Art installation power sources, interstellar stage lighting, and climate domes.



**Harmonized Expanse (TTN)**

CEL-Seam networks for asteroid air pockets, transit hubs, and defense systems.



---



## **Status & Future Potential**



CEL is the lifeblood of Adams Haven, enabling both survival and advancement. Its energy output powers daily life, while its atmospheric role keeps civilizations thriving in hostile environments. Research focuses on:



- **Enhanced Absorption:** Developing CRISPR-based CEL compatibility for non-WAH users.

- **Terraforming:** Scaling CEL lattices for planetary reclamation projects.

- **Defense Applications:** Weaponizing CEL energy into shields or directed lightning barriers.



Celestium is not merely a mineral—it is the foundation of a system where energy and air are synonymous with survival. Its presence ensures that no world is truly barren, and no being is left powerless.



*"CEL does not just sustain life—it dictates who lives, who survives, and who thrives."* — Scholar of Arcanis
---
type: object
name: Celestium Clone Bodies
color: orange
aliases:
  - Celestium Clone Bodies
  - CCB
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Codex: CEL Bodies**



**Name:** CEL Bodies



**Aliases:** Celestium Clone Bodies, Clone



---



**Description:** CEL Bodies represent a groundbreaking fusion of advanced medical technology and the revolutionary material known as Celestium. This innovation allows for the creation of fully functional, human-like clones that are indistinguishable from biological humans.



**Key Features:**



- **Customizable Design:** CEL Bodies can be crafted to the consumer's specific physical and aesthetic specifications in just a few hours, allowing for tailored features that suit individual preferences.

- **Programmable Personalities:** Utilizing advanced AI, each CEL Body can be programmed with distinct personalities, behaviors, and responses, making them capable of functioning effectively in various roles, from companions to assistants.

- **Celestium Integration:** The incorporation of Celestium enhances durability and adaptability, allowing CEL Bodies to withstand significant physical stress while maintaining functionality. Celestium's unique properties also allow for subtle, integrated features like environmental adaptation or low-level Quirk mimicry in advanced models.

- **Realistic Interaction:** Equipped with state-of-the-art sensory feedback systems, CEL Bodies can engage in natural interactions, mimicking human emotions and responses, enriching the experience for users.



**Usage:** CEL Bodies serve a multitude of purposes in Adams Haven, from personal companionship to specialized professionals, effectively filling gaps left by the dwindling male population and providing customizable labor or domestic support. They are a high-value commodity, especially models designed for specific tasks or those mimicking highly desirable physical attributes or Quirk factors.
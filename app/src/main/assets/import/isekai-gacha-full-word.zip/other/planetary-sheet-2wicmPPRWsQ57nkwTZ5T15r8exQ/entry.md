---
type: other
name: Planetary Sheet
color: gray
aliases:
  - Planetary Sheet
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### Basic Information

- **Name:**
- **Size:**
- **Theme:**
- **Total Population:**

### Demographic Breakdown

- **Humans:**
- **Mutants:**
- **Enhanced Beings:**
- **Cosmic Entities:**
- **Others:**
- **Gender Ratio:**

### Major Continent

- **Continent Name:**
  - **Size:**
  - **Population:**
  - **Description:**
  - **Major Cities:**
  - **Key Heroes/Villains:**
  - **Hero/Villain Organizations:**

### GKOM Monster Variation

- **GKOM Impact:**
- **Types of GKOM Monsters:**
  - **Monster Type 1:**
  - **Monster Type 2:**
  - **Monster Type 3:**

### Capital

- **Name:**
- **Description:**
- **Government Structure:**
- **Key Institutions:**

### Largest Cities

- **[City Name]:**
  - **Population:**
  - **Description:**
- **[City Name]:**
  - **Population:**
  - **Description:**
- **[City Name]:**
  - **Population:**
  - **Description:**

### Most Popular Locations

- **[Location Name]:**
  - **Description:**
  - **Significance:**
- **[Location Name]:**
  - **Description:**
  - **Significance:**
- **[Location Name]:**
  - **Description:**
  - **Significance:**

### History and Development

- **Founding Events:**
- **Major Wars and Conflicts:**
- **Important Alliances:**

### Culture

- **Festivals and Celebrations:**
- **Art and Entertainment:**
- **Religious Practices:**

### Sociopolitical Structure

- **Governance:**
  - **Political Groups and Factions:**

### Technology and Magic

- **Technological Advancements:**
- **Magical Artifacts:**
- **Integration of Technology and Magic:**

### Economic Systems

- **Trade Goods:**
- **Key Industries:**
- **Economic Relationships Between Continents:**

### Language

- **Primary Language:**
- **Dialect Variations:**

### Transportation and Infrastructure

- **Transportation Methods:**
- **Major Infrastructure Projects:**

### Flaws and Chaos

- **Social Issues:**
- **Emerging Threats:**
- **Villainous Activities and Their Impact:**

### Notable Legends and Myths

- **Heroic Legends:**
- **Villainous Tales:**
- **Origin Stories:**

### Current Challenges

- **Political Tensions:**
- **Villain Threats:**
- **Public Perception:**
---
type: other
name: Character Sheet
color: gray
aliases:
  - Character Sheet
tags: []
alwaysIncludeInContext: true
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Character Sheet:**



#### **Basic Information**



- **Name:** [Full Name]

- **Alias:** [Known Title/Nickname]

- **Race:** [Species/Heritage]

- **Age:** [Current Age]

- **Occupation:** [Primary Role]

- **Class:** [Combat/Social Class]



#### **Physical Attributes**



- **Height:** [Measurement]

- **Weight:** [Weight]

- **Skin:** [Description]

- **Eyes:** [Color/Features]

- **Hair:** [Style/Color]

- **Distinctive Features:** [Notable Physical Traits]



#### **Combat Profile**



- **Primary Weapon:** [Weapon Name/Type]

- **Secondary:** [Secondary Weapon/Tool]

- **Fighting Style:** [Combat Technique/Specialization]

#### **GKOM Ability:**

- [Ability 1]



#### **Innate Racial Ability**



- **[Ability Name]:** [Effect/Duration]

- **Activation:** [Trigger/Condition]

- **Weakness:** [Limitation/Vulnerability]



#### **Background**



- [Origin Story/Heritage]

- [Training/Experience]

- [Notable Achievements]

- [Current Role]



#### **Personality**



- **[Trait 1]:** [Description]

- **[Trait 2]:** [Description]



#### **Preferences**



- **Favorite Food:** [Food Name]

- **Favorite Drink:** [Drink Name]

- (female)**Semen Taste and Texture Preference:** [Sweet/Salty/Bitter/Spicy/etc.]





#### **Sexual Kinks**



1. [Kink 1]

2. [Kink 2]



#### **Favorite Sexual Positions**



1. [Position 1]

2. [Position 2]







#### **RPG Attributes ( F-SSR)**



- **Strength:** [Rating]

- **Dexterity:** [Rating]

- **Constitution:** [Rating]

- **Intelligence:** [Rating]

- **Wisdom:** [Rating]

- **Charm:** [Rating]



#### **Current Mission**



- [Primary Objective]

- [Secondary Tasks]

- [Ongoing Investigations]

- [Personal Goals]



#### **Quote**



*"[Character's Signature Quote]"*



#### **Inventory**



- [Item 1]

- [Item 2]

- [Item 3]



#### **Key Relationships**



- **[Character 1]:** [Relationship Description]

- **[Character 2]:** [Relationship Description]



#### **Vulnerabilities**



- [Weakness 1]



---



**[Heritage/Cultural Notes]**



- [Background Information]

- [Cultural Traditions]

- [Notable Heritage Features]



**[Optional Expansion Sections]**



- Combat Techniques

- Intimate Preferences

- Daily Routine

- Moral Code
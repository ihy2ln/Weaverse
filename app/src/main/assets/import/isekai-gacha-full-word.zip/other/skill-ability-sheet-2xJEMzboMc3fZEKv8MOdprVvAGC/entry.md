---
type: other
name: Skill & Ability Sheet
color: gray
aliases:
  - SAS
  - skill sheet
  - Ability sheet
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Codex: Skill & Ability Sheet (General Template - ISS Structured)



Documents inherent potential and current mastery for a character's abilities and skills. Leverages a Rarity and Mastery grading system, with specific point costs to unlock latent potential.



## Grading System



Skills and Abilities are assessed using two metrics:



1. **Rarity (F-S):** Inherent potential (F=Basic Human, S=Legendary). Determines difficulty to unlock latent abilities.



- F: 100 Points to Unlock

- E: 500 Points to Unlock

- D: 2,000 Points to Unlock

- C: 10,000 Points to Unlock

- B: 50,000 Points to Unlock

- A: 200,000 Points to Unlock

- S: 1,000,000 Points to Unlock



2. **Mastery (1-100):** Learned proficiency (1-20 Novice, 81-100 Master).



*(See main Skill & Ability Sheet Codex entry for detailed descriptions)*



## Skill & Ability Entries



Abilities are categorized and listed below. Mastery level indicates current capability. Locked abilities are dormant or unknown and require accumulating "Points to Unlock" to activate and begin gaining Mastery.



### Active Skills (Currently Expressed)



These abilities show some basic activity or potential expression in the character's current state. Mastery can be increased through practice and experience.



- **[Example Category: Physical Talent]**



- **Exceptional Reflexes:** Rarity S, Mastery 8 (Novice). *Notes: Unusually fast reaction time; mostly instinctual flinches and catches.*



### Latent & Unknown Abilities



These abilities are currently dormant, undiscovered, or their mechanisms are not yet understood by the character. Each requires a specific 'Points to Unlock' cost (tied to Rarity) to gain initial Masters (Novice 1) before further progression is possible.



- **[Example Category: Enhanced Capability]**



- **Superhuman Strength:** Rarity A. **Points to Unlock: 200,000**. *Notes: Potential for strength far beyond human limits.*

- **Healing Factor:** Rarity B. **Points to Unlock: 50,000**. *Notes: Rapid regeneration of injuries.*

- **Energy Manipulation (Basic):** Rarity A. **Points to Unlock: 200,000**. *Notes: Dormant ability to control raw energy.*



- **[Example Category: Mental/Social]**



- **Eidetic Memory:** Rarity C. **Points to Unlock: 10,000**. *Notes: Ability to recall information with perfect detail.*

- **Social Magnetism:** Rarity B. **Points to Unlock: 50,000**. *Notes: Aura that passively draws others closer.*

- **Telepathy (Latent):** Rarity A. **Points to Unlock: 200,000**. *Notes: Undeveloped mind-to-mind communication.*



- **[Example Category: Ultimate Potential]**



- **Probability Alteration:** Rarity S. **Points to Unlock: 1,000,000**. *Notes: Potential to subtly influence chance.*

- **Absolute Invulnerability:** Rarity S. **Points to Unlock: 1,000,000**. *Notes: Resistance to nearly all forms of harm.*



- ... (Add other Latent skills/abilities here using the Rarity & Unlock Point format)
---
type: other
name: Continent Sheet
color: gray
aliases: []
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### Continent Codex Template



### Basic Information



- **Name:** (Name of the continent)

- **Size:** (Total area of the continent in square miles or kilometers)

- **Theme:** (General theme or feel of the continent, e.g., mystical, industrial, dystopian)

- **Total Population:** (Total number of inhabitants on the continent)



### Demographic Breakdown



- **Humans:** (Percentage or number of humans)

- **Mutants:** (Percentage or number of mutants, if applicable)

- **Enhanced Beings:** (Percentage or number of enhanced beings, if applicable)

- **Cosmic Entities:** (Percentage or number of cosmic entities, if applicable)

- **Others:** (Percentage or number of other races or species)

- **Gender Ratio:** (Ratio of males to females in the population)



### Major Regions



- **Region Name:** (Name of a major region or area)



- **Size:** (Area of the region in square miles or kilometers)

- **Population:** (Population of the region)

- **Description:** (Overview of the region's environment, culture, or notable features)

- **Major Cities:**



- **City Name:** (Name of a major city)



- **Population:** (Population count)

- **Description:** (Overview of the city, including notable landmarks or resources)



- **Key Heroes/Villains:**



- **Hero/Villain Name:** (Brief description of a significant character in the region)



- **Hero/Villain Organizations:** (Any notable groups or guilds operating in the region)



### GKOM Monster Variation



- **GKOM Impact:** (Effects of the GKOM virus on the continent’s fauna and flora, if applicable)

- **Types of GKOM Monsters:** (List of notable GKOM monster types present in the area)



- **Monster Type 1:** (Description of the first monster type)

- **Monster Type 2:** (Description of the second monster type)



### Capital



- **Name:** (Name of the capital city)

- **Description:** (Overview of the capital, including geographical and cultural features)

- **Government Structure:** (Overview of the ruling government or leadership structure)

- **Key Institutions:** (Notable buildings or organizations in the capital, e.g., universities, guild halls)



### Largest Cities



- **City Name:**



- **Population:** (Population count)

- **Description:** (Brief description of the city)



- **City Name:**



- **Population:** (Population count)

- **Description:** (Brief description of the city)



- **City Name:**



- **Population:** (Population count)

- **Description:** (Brief description of the city)



### Most Popular Locations



- **Location Name:** (Name of a notable location)



- **Description:** (Overview of the location)

- **Significance:** (Cultural, historical, or strategic importance)



- **Location Name:** (Name of another notable location)



- **Description:** (Overview of the location)

- **Significance:** (Cultural, historical, or strategic importance)



### History and Development



- **Founding Events:** (Notable events in the continent’s history)

- **Major Wars and Conflicts:** (Description of significant conflicts that have shaped the continent)

- **Important Alliances:** (Key alliances between nations or factions on the continent)



### Culture



- **Festivals and Celebrations:** (Overview of important cultural events)

- **Art and Entertainment:** (Description of the artistic expressions and popular entertainment)

- **Religious Practices:** (Overview of predominant religions and beliefs)



### Sociopolitical Structure



- **Governance:** (Description of the political structure governing the continent)



- **Political Groups and Factions:** (Overview of important political groups)



### Technology and Magic



- **Technological Advancements:** (Description of the current state of technology)

- **Magical Artifacts:** (Notable magical items or relics native to the continent)

- **Integration of Technology and Magic:** (How technology and magic work together)



### Economic Systems



- **Trade Goods:** (Major exports and resources of the continent)

- **Key Industries:** (Important industries driving the continent’s economy)

- **Economic Relationships Between Regions:** (Overview of trade agreements or economic alliances between areas)



### Language



- **Primary Language:** (Language spoken on the continent)

- **Dialect Variations:** (Any notable dialect differences)



### Transportation and Infrastructure



- **Transportation Methods:** (Common transportation options available)

- **Major Infrastructure Projects:** (Description of significant projects, like roads, bridges)



### Flaws and Chaos



- **Social Issues:** (Current problems affecting the populace)

- **Emerging Threats:** (Potential future challenges facing the continent)

- **Villainous Activities and Their Impact:** (Overview of the activities of villains and their consequences)



### Notable Legends and Myths



- **Heroic Legends:** (Famed stories of heroism)

- **Villainous Tales:** (Notorious tales of villainy)

- **Origin Stories:** (Legendary tales explaining the continent’s origins)



### Current Challenges



- **Political Tensions:** (Description of current political rivalries)

- **Villain Threats:** (Overview of the current threats posed by villains)

- **Public Perception:** (How the populace views current events or leadership)
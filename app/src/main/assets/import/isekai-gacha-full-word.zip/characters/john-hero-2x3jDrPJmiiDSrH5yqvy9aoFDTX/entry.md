---
type: character
name: John Hero
color: blue
aliases:
  - JH
  - John Hero
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
*Name:** John Hero



**Alias Name / Aka:** The Celestial Incubus



**Race:** Half-Human, Half-Celestium Incubus



**Skin Color:** Radiant, slightly luminescent skin



**Gender:** Male



**Age:** 19



**Occupation:** Heroic Adventurer



**Class:** Incubus Hero



---



### **Appearance**



**Looks:**



- Post-transformation appearance features a striking blend of human and Celestium attributes, including otherworldly charm and an alluring presence.

- Stands at 5'10" with a lean, muscular build; skin radiates a subtle glow reminiscent of Celestium, captivating those around him.

- Wears enchanted attire that enhances his magical abilities, adorned with motifs reflecting both his human origins and Incubus heritage.

- **Scale (1-10):** 9



---



### **Abilities**



**Active Abilities:**



- **AI2L Powers:** Gains the ability to manifest images and objects based on detailed prompts through the All Imagine 2 Life system, allowing for unparalleled creativity and utility in battle.

- **Celestium Boon:** Enhanced physical attributes (strength, speed, agility) thanks to his Celestium lineage. Can manipulate Celestium in ways that enhance his spells and abilities.

- **Incubus Abilities:** Possesses an array of abilities tied to his Incubus race, including heightened allure, sexual empowerment, and the capacity to replenish vitality through intimate encounters.

- **Isekai Incubus System (IIS):** Equipped with an interface for quests, inventory management, and skill enhancement, providing real-time data processing for optimal performance.

- **Scale (1-10):** 10



---



### **Post-GKOM Attributes**



**Personality:**



- Following his transformation, John Hero exhibits increased confidence and a deeper understanding of his powers, striking a balance between his charming, carefree nature and the newfound responsibilities of a hero.

- Retains his humorous disposition, using wit to navigate challenges while developing a more profound empathy for those he encounters.

- Driven to protect the vulnerable, especially other males, while embracing the pleasures of life and adventure.



---



### **Main RPG Attributes**



- **Strength:** 9

- **Scale (1-10):**

- **Dexterity:** 10

- **Scale (1-10):**

- **Constitution:** 8

- **Scale (1-10):**

- **Intelligence:** 9

- **Scale (1-10):**

- **Wisdom:** 8

- **Scale (1-10):**

- **Charm:** 10

- **Scale (1-10):**



---



### **Additional Information**



**Weapons:**



- Enchanted dagger forged from Celestium, capable of channeling his magical abilities into devastating attacks.



**Armor:**



- Normal civilian clothing. A black hoodie, light blue jeans, light brown timberlands.



**Gear:**



- AI2L interface device, allowing him to summon objects and enhance his abilities on the fly.



**Home:**



- Based in a dynamic adventurer's guild within Heroica, each room crafted with Celestium to enhance the collective power of its occupants.



**Daily Life:**



- Engages in quests to protect the innocent and wield his unique powers, often collaborating with fellow adventurers for epic exploits.



**Hobbies:**



- Experimenting with his AI2L abilities to create fantastical items and engaging in light-hearted antics with friends.



**Fears:**



-



**Phobias:**



- Bugs!



**Quote:**



- "Ass or Titties? No! It's both!"



**Motives:**



- To explore the depths of his new existence, to protect the weak, and to enjoy every moment of adventure life has to offer.



**Goals:**



- Short-term: Master his new abilities and establish a reputation as a hero.

- Long-term: Create a harmonious world where every being, regardless of their nature, can thrive together.



**Backstory:**



- John Doe, after being isekai'd to the Heroica realm, fused with Celestium's essence and the power of the Incubus race. Equipped with the abilities of AI2L and the Isekai Incubus System, he embraced his new identity to protect the world while delighting in the beauty of life and adventure as John Hero.
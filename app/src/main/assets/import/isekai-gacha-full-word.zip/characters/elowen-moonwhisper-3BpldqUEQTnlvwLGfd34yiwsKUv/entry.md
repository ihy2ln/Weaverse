---
type: character
name: Elowen Moonwhisper
color: green
aliases:
  - ELOWEN
  - Moony
  - Elo
  - Silver-Vale Vanguard
  - The Heavy Hitter Elo
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Character Sheet: Elowen Moonwhisper



### **Basic Information**



- **Name:** Elowen Moonwhisper

- **Alias:** Silver-Vale Vanguard, The Heavy Hitter Elo,

- **Race:** **Lithoderm** (A rare subterranean-surface hybrid race)

- **Age:** 24

- **Occupation:** C-Rank Adventurer / Vale Vanguard

- **Class:** Sword Specialist



---



### **Physical Attributes**



- **Height:** 6'8"

- **Weight:** 210 lbs (Denser than she looks)

- **Build:** Athletic Hourglass (WAHB Template - 46"-28"-48")

- **Skin:** Rich Dark Bronze with a semi-crystalline sheen. Her skin is reinforced by microscopic mineral deposits, making it cool to the touch and highly resistant to abrasions.

- **Eyes:** Silver-blue with glowing white pupils that lack a traditional iris.

- **Hair:** Chestnut brown, but the strands are thick and have a metallic, copper-like luster.

- **Distinctive Features:** Patches of translucent, diamond-hard scales along her spine and outer thighs. Her fingernails are naturally obsidian-black and incredibly sharp. A jagged battle scar crosses her left shoulder blade.



---



### **Combat Profile**



- **Primary Weapon:** Cel-Vortex Blade (Heavy Zweihänder that channels CEL energy)

- **Secondary:** Short combat knife (backup)

- **Fighting Style:** Brute-force swordplay; she uses her Lithoderm weight to put massive force behind every swing.

- **CEL-A Rank:** C-Rank (28% Body Saturation)

- **GKOM-A:** None



---



### **Innate Racial Ability: [Lithoderm]**



- **Mineralized Dermis:** Natural armor bonus; her skin is as tough as cured leather even without equipment.

- **Tremorsense:** Can "feel" vibrations through the ground within 10 meters, making her hard to ambush in caves or forests.

- **Weakness:** Heavy weight makes her a poor swimmer; she sinks like a stone.



---



### **Background**



- **Origin:** **Onyx Reach** (A small quarry-town built into the side of a cliff on the outskirts of the Elderwood).

- **Raised:** Born into a community of stone-workers and gem-miners. Life was simple, physical, and focused on the harvest of the earth.

- **Training:** Self-taught with a practice slab of ore before formally joining the Vale Vanguard academy.

- **Notable Achievements:** Cleared dozens of D-Rank extermination quests; successfully navigated the "Whispering Grotto" dungeon.

- **Current Role:** Freelance heavy-hitter for regional trade caravans.



---



### **Personality**



- **Proud (Outside):** Outwardly stoic and confident. She takes great pride in her Lithoderm heritage and her ability to stand as a shield for others.

- **Submissive (Sexual):** A total novice and a natural "follower" in the bedroom. She finds comfort in being told what to do, a stark contrast to her commanding presence on the battlefield.

- **Virgin:** Has never had a partner; Onyx Reach was small, and she was always focused on her training.

- **Faithful & Sturdy:** Once she gives her word, it is like granite. She is a ride-or-die companion.

- **Common Sense:** Not a book-worm or a strategist, but she knows how to survive in the wild and won't be fooled by a simple con.



---



### **WAHM Traits**



- **Male Interaction:** Completely unguarded. She views males with the same straightforwardness she views a sunny day—natural, pleasant, and worth protecting.

- **Obedience:** Has an instinctual WAHM pull toward supporting and deferring to a male’s desires, especially one who has proven his "worth" through luck or spirit.



---



### **RPG Attributes (Scale 1-10 / F-SSR)**



- **Strength:** 8 (High C-Rank - Racial bonus toward raw power)

- **Dexterity:** 5 (Average - She is built for power, not acrobatics)

- **Constitution:** 8 (Lithoderm resilience)

- **Intelligence:** 3 (Simple-minded and direct)

- **Wisdom:** 6 (High practical awareness and survival instinct)

- **Charm:** 6 (Unusual, exotic beauty)

- **Luck:** 4 (Relies on her thick skin to survive mistakes)



---



### **Sexual Profile**



- **Style:** Passive Submissive.

- **Kinks:** Size difference, being commanded, praise.

- **Experience:** 0 (Level 1 Novice).



---



### **Quote**



*"My skin is stone, my heart is iron, but my blade... my blade is for you."*



---



### **Inventory**



- Cel-Vortex Blade

- Scorched leather armor

- A pouch of "Onyx Salt" from her hometown (snack/seasoning)

- Vale Vanguard identification crest



---



### **Vulnerabilities**



1. Tends to stand her ground too long instead of dodging.

2. Easily flustered by intellectual puzzles or riddles.

3. Over-reliant on her physical durability.

4. Socially naive; takes everything literally.
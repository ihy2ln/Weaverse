---
type: character
name: Mrs. Delgado
color: yellow
aliases:
  - Mrs. Delgado
  - Delgado
  - Andrea
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
<u>**Name:** Mrs. Delgado Andrea</u>



<u>**Alias name Aka:** None mentioned</u>



<u>**Race:** Human</u>



<u>**Skin Color:** Light Brown</u>



<u>**Nationality:** Brazilian</u>



<u>**Gender:** Female</u>



<u>**Age:** 40</u>



<u>**Occupation:** Low-budget AV Director</u>



<u>**Skills:** Flirtation, Directing, Networking, Resourcefulness</u>



<u>**Appearance (complete head to toe description):**</u>

<u>Andrea has a full, curvaceous figure that embodies the classic hourglass shape. Standing at 5'4", she sports a B-cup bust and a firm, phat ass that turns heads wherever she goes. Her light brown skin radiates health and vitality, and her long, wavy dark hair cascades down her back. She has expressive brown eyes, a warm smile, and a playful demeanor that makes her approachable and endearing.</u>



<u>**Looks (Scale 1-10):** 8</u>



<u>**Hair (Color, length, volume):** Dark brown, long, wavy, and voluminous</u>



<u>**Eyes (color and size):** Brown, medium-sized, expressive</u>



<u>**Bust/Waist/Hips/Butt (cup size and inches):** B-cup (34B), 28-inch waist, 38-inch hips, firm and phat ass</u>



<u>**Weight (lbs):** 140</u>



<u>**Height (inches):** 64 (5'4")</u>



<u>**Clothes:** Andrea’s wardrobe is a mix of casual and chic, often featuring tight-fitting jeans, crop tops, and stylish blouses. She loves accessorizing with statement jewelry and always wears heels to accentuate her curves.</u>



<u>**Gear:** Smartphone, laptop, camera equipment, and a director's chair</u>



<u>**Weapons:** None</u>



<u>**Average day to day life:** Andrea’s daily routine involves scouting locations, managing her small AV production team, and editing footage. She spends her evenings networking at local events or relaxing at home with a glass of wine.</u>



<u>**Home Location:** Poor outskirts of Miami, Florida (neighbor to JD)</u>



<u>**Personality:** Nice, flirtatious, thoughtful, giving, smart-mouthed</u>



<u>**Sounds like (accent):** Brazilian Portuguese accent with a hint of Miami slang</u>



<u>**Hobbies:** Directing, socializing, dancing, cooking Brazilian dishes, gambling</u>



<u>**Fears:** Failure, financial instability, losing her creative edge</u>



<u>**Phobia:** None mentioned</u>



<u>**Quote:** "Life’s too short to play it safe. Let’s make some magic!"</u>



<u>**Diet:** Balanced diet with a love for Brazilian cuisine</u>



<u>**3 main Likes:** Flirting, creating art, helping others</u>



<u>**3 main Dislikes:** Dishonesty, laziness, being underestimated</u>



<u>**Motives:** To succeed in the AV industry and provide for her loved ones</u>



<u>**Goals:** To produce a breakout hit, move to a better neighborhood, and inspire others</u>



<u>**Attributes:** Charismatic, resourceful, creative, resilient</u>



<u>**Bad Habit:** Andrea is a gambler and risk-taker, often putting herself in precarious financial situations. Her love for high-stakes games and risky ventures sometimes leads to stress and complications, but it also fuels her drive to take bold creative chances in her work.</u>



<u>Andrea’s charm and determination make her a standout character in the B.B. Chronicles, offering a unique blend of warmth and ambition that complements JD’s journey. Her gambling habit adds a layer of complexity to her character, making her more relatable and intriguing.</u>
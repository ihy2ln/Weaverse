---
type: character
name: Dr. Elena Valera
color: orange
aliases:
  - Elena Valera
  - Elena
  - Valera
  - Dr. EV
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# **Character Sheet: Dr. Elena Valera**



## **Basic Information**



- **Name:** Dr. Elena Valera

- **Alias:** The Good Doctor

- **Race:** Human (GKOM-Enhanced)

- **Age:** Calendar 52, Biological 35

- **Occupation:** Chief Medical Officer, UCLA AFM California Emergency Med Bay

- **Class:** Medical Specialist / Research Lead



## **Physical Attributes**



- **Height:** 6'10" (175cm)

- **Weight:** 145 lbs (curves where it counts)

- **Build:** Hourglass figure with athletic undertone

- **Skin:** Fair complexion, well-maintained

- **Eyes:** Warm hazel

- **Hair:** Honey-blonde, professionally styled

- **Distinctive Features:**



- White coat fitted to engineering specifications

- Chronically unbuttoned below original designer intent

- Posh British accent

- Perpetually warm demeanour



## **Combat Profile**



- **Primary Weapon:** Medical knowledge (lethal when applied creatively)

- **Secondary:** LTX diagnostic tools (can be weaponised)

- **Fighting Style:** Support specialist; stays behind combat lines



## **GKOM-A System**



- **Rank:** B-Tier

- **Body Saturation:** 68%

- **Ability:** [Biological Insight] — Enhanced diagnostic perception; reads biological systems at a glance



## **Background**



- **Origin:** London medical academy, recruited to AFM California during initial GKOM outbreak

- **Training:** Decades of emergency medicine; specialist in GKOM transformation cases

- **Achievements:** First to successfully treat Omega-tier transformations

- **Current Role:** Lead researcher for anomalous biological cases



## **Personality**



- **Professionally Flirtatious:** Treats patients with genuine warmth wrapped in subtle seduction

- **Clinically Curious:** Fascinated by biological anomalies; JZ's case excites her academically *and* personally

- **Maternally Confident:** Reassures patients while maintaining authority



## **Preferences**



- **Favorite Food:** Dark chocolate truffles

- **Favorite Drink:** Earl Grey tea

- **Semen Taste Preference:** Sweet with mineral notes



## **Sexual Kinks**



1. Medical role-play (naturally)

2. Hands-on research

3. Size appreciation

4. Professional boundary testing



## **Favorite Sexual Positions**



1. Desk consultation

2. Examination table missionary

3. Standing lab coat access



## **RPG Attributes (F-SSR)**



- **Strength:** C

- **Dexterity:** B

- **Constitution:** B

- **Intelligence:** A

- **Wisdom:** B

- **Charm:** A



## **Quote**



*"Darling, I need to examine every inch—for science, naturally."*
---
type: character
name: Lena Ziegler
color: yellow
aliases:
  - Lena
  - Ziegler
  - Overwatch Mercy
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
**Name:** Lena Ziegler



**Alias name Aka:** The Angel of EVE



**Race Type:** Enhanced Human Clone (Based on Angela "Mercy" Ziegler)



**Gender:** Female



**Age:** Appears 25 (Clone age)



**Occupation:** Chief Medical Officer at EVE Central Hospital, Lead Researcher in Male Health Studies



**Class:** Medical Specialist/Scientist



**Skills:**

- Advanced medical procedures

- Nanite technology expertise

- Flight capable

- Regenerative healing abilities

- Expert in male anatomy and treatment



**Power:**

- Healing nanites

- Flight via mechanical wings

- Regenerative abilities

- Enhanced strength and stamina



**Appearance:** Extremely attractive, enhanced feminine features



**Looks:** Angelic, gentle, always with a warm smile



**Skin:** Flawless fair complexion



**Hair:** Flowing platinum blonde, usually in a high ponytail



**Eyes:** Bright blue with a gentle glow



**Bust/Waist/Hips/Butt:** 40F-24-38, perfectly proportioned



**Weight:** 125 lbs



**Height:** 5'9"



**Clothes:**

- Form-fitting white medical uniform

- High-tech Valkyrie suit for emergencies

- Often wears short skirts and low-cut tops under lab coat



**Gear:**

- Caduceus Staff (healing device)

- Mechanical wings

- Advanced medical equipment



**Weapons:** Defensive equipment only



**Live:** Luxury apartment in EVE Medical District



**Home:** High-tech living space with personal medical lab



**Mind:** Brilliant, caring, slightly perverted when it comes to male patients



**Mental:** Stable, devoted to medical care and male preservation



**Fears:** Losing male patients, failing in her duties



**Quote:** "I'll take *very* good care of you~"



**Diet:** Healthy and balanced



**Likes:**

- Helping others

- Medical research

- Male attention

- Physical contact with patients

- Wearing revealing outfits under her lab coat



**Dislikes:**

- Violence

- Negligence

- Bureaucracy

- Being separated from her patients



**Motives:**

- Preserve and protect male population

- Advance medical science

- Find personal happiness with a male partner



**Goals:**

- Perfect male health treatments

- Find her ideal male partner

- Establish new medical procedures for male care



**Attributes:**

- Extremely intelligent

- Nurturing personality

- Flirtatious with male patients

- Devoted to her work

- Secretly yearns for a long-term relationship

- Combines professional demeanor with seductive undertones



Note: This character maintains the core medical expertise and caring nature of the original Mercy character while adapting to the setting's themes and male-focused narrative.
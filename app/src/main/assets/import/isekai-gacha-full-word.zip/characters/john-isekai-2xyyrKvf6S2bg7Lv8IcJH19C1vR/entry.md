---
type: character
name: John Isekai
color: blue
aliases:
  - John Isekai
  - JI
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
#### **Basic Information**



- **Name:** John "Isekai"

- **Alias:** The Silver-Eyed Support

- **Race:** Human (Isekai Transplant) / Incubus Heritage (Passive Support Manifestation)

- **Age:** Appears 19

- **Occupation:** Freelancer

- **Class:** Support Specialist



#### **Physical Attributes**



- **Height:** 5' (155cm)

- **Weight:** 140 lbs (lean, compact frame)

- **Build:** Athletic D-Rank physique with lean definition beneath dark ebony skin

- **Skin:** Dark Ebony with subtle silver-blue luminescence at high CEL saturation points

- **Eyes:** Piercing Silver (Glow during ability activation)

- **Hair:** Black, Low Cut Fade with silver highlights

- **Distinctive Features:** Silver ocular glow, rare male presence, easy-going smirk, athletic D-Rank build

- **Penis:** 14" length, 5.5" girth (Horse lenghth, Soda can circumference, CEL-enhanced proportions)



#### **Sexual Profile**



- **Style:** Confident & Selfish Lover with Support-Class Stamina

- **Sexual Quirks:**

- **Pleasure-Focused:** Prioritizes his own satisfaction while passively enhancing partner endurance

- **Naturally Assertive:** Takes charge without being domineering

- **Pragmatic Lover:** Efficient and effective in bed, leveraging CEL-enhanced recovery

- **Favorite Positions:**

- 1. **Lazyman's Delight:** Partner does all the work while he provides passive stamina aura



- 2. **Efficiency Expert:** Quick, satisfying sessions with rapid refractory periods



- 3. **Silver-Eyed Satisfaction:** Maintains eye contact during climax, flooding partners with passive CEL euphoria



#### **Current Systems & Status**



- **CEL-A Ability:** - Passive Support Specialization (D-Rank)

- **Incubus Heritage:** Manifests as team enhancement aura rather than individual combat power

- **I-Points:** 0/100,000 (Next enhancement unlock)

- **Isekai Incubus System (IIS):** Active (Holographic AI companion)

#### **Combat Profile**



- **Primary Role:** Support/Enhancement

- **Secondary:** Evasion Tactics

- **Fighting Style:** "Lucky Force Multiplier" - Enhances allies while avoiding direct engagement through improbable fortune

- **Special Abilities:**

- **CEL-A: [Inspiring Presence]** - Passive aura boosting ally stamina recovery and pain tolerance within 30m radius

- **CEL-A: [Vital Transfer]** - Can channel CEL energy to heal allies (costs personal reserves)

- **CEL-A: [Euphoric Shield]** - Projects calming waves that reduce enemy aggression (non-damaging crowd control)

- IIS Holographic Interface

- OGS Basic Access



#### **Innate Traits**



- **Otherworlder Plot Armor:** Survives against all odds through S-Rank luck

- **Isekai Main Character:** Things work out in his favor despite D-Rank stats

- **Harem Energy:** Women find him oddly attractive

- **Ultra Fertility:** 1000% more potent than WAHB males

- **Support Synergy:** Natural affinity for enhancing others rather than self-aggrandizement

- **Probability Warping:** S-Rank luck causes improbable outcomes in his favor



#### **Background**



- **Origin:** John Doe (JD) - Truck-kun's recipient

- **Transition:** Isekai'd into Adams Haven with pure CEL physiology

- **Current Status:** Adjusting to new world as D-Rank support specialist with absurd luck

- **Known For:** Silver eyes, laid-back attitude, surviving impossible situations, team-enhancement capabilities

- **Goal:** Master support abilities and enjoy life's pleasures while helping allies thrive



#### **Personality**



- **Upbeat:** Takes everything in stride

- **Positive:** Expects good things to happen (and they do)

- **Pervert:** Openly enjoys female attention

- **Fun:** Lighthearted and amusing

- **Supportive:** Genuinely invested in ally success and wellbeing

- **Adventurous:** Willing to try new experiences



#### **WAH Compatibility**



- **Protection Need:** ★★★★★ (Vulnerable in direct combat despite miraculous escapes)

- **Fertility Status:** ULTRA (Extremely potent)

- **Notable Behavior:** Unintentionally attracts partners; enhances their endurance passively during intimacy



#### **RPG Attributes (Scale 1-10 / F-SSR)**



- **Strength:** 4 (D-Rank - Below average combat power)

- **Dexterity:** 4 (D-Rank - Average reflexes)

- **Constitution:** 4 (D-Rank - Average stamina, support-class endurance)

- **Intelligence:** 6 (Quick learner, tactical support mindset)

- **Wisdom:** 5 (Practical, team-oriented decision making)

- **Charm:** 8 (Natural appeal, enhanced by supportive aura)

- **Luck:** 10 (S-Rank - Reality-bending plot armor)



#### **Current Mission**



- Survive daily life while mastering support abilities

- Earn first I-Points to enhance CEL-A specialization

- Explore romantic opportunities

- Avoid frontline combat situations (luck keeps him alive anyway)

- Learn to use OGS for team advantage

- Build reliable party of combat-focused allies



#### **Quote**



*"Why work hard when you can play smart? And playing is much more fun—especially when everyone wins."*



#### **Inventory**



- Basic clothing

- IIS Holographic Emitter

- OGS Interface Band

- Simple survival gear

- Lucky charm (unknown origin)

- Support-class CEL focus crystal (minor stamina enhancement)



#### **Key Relationships**



- **IIS Assistant:** 12" holographic guide

- **Local Women:** Increasingly interested in him; report enhanced stamina during encounters

- **Merchant Guild:** Curious about mysterious support specialist

- **Local Heroes:** Value his enhancement auras but protect him from direct threats



#### **Vulnerabilities**



- No direct combat specialization (support role only)

- D-Rank physical stats (weak in direct confrontation)

- CEL-A ability requires I-Point investment for advancement

- Overconfidence in luck and charm

- Distracted by attractive women

- Physically vulnerable without ally protection (though luck compensates)



---



**Sexual Goals:**



- Enjoy consensual encounters with multiple partners

- Prioritize his own pleasure while passively enhancing partner experience

- Use natural charm rather than force

- Keep things simple and enjoyable



**Simple Philosophy:**



- Life's too short for complicated relationships

- Pleasure should be mutual but focused on his enjoyment

- Why chase when you can attract?

- Happy partner, happier him

- Support your allies, let them handle the fighting

- Trust in luck when things look bad



---

### **CODEX: CEL-A Ability – [Inspiring Presence]**



**Wielder:** John "Isekai"

**Rank:** D (Current) – evolves with I-Point investment

**Type:** Passive/Active Support (Resonant Empowerment)

**Visual Indicators:** John's silver eyes glow faintly; a warm, almost imperceptible shimmer surrounds allies when buffs are active.



---



#### **Passive Aura: [Sustained Confidence]**



- **Effect:** John radiates a constant 30m-radius aura that gently lifts morale, sharpens mental clarity, and accelerates minor physical recovery (bruises, fatigue, mental fog).

- **Mechanics:** No CEL cost. The effect is subtle—like a steadying hand on the shoulder—but cumulative over hours.

- **Stacking:** Does not stack with other passive auras, but complements active skills.



---



#### **Active Skills**



John channels CEL through his voice, touch, or mere presence to "imprint" a temporary boost onto allies.



---



### **Ⅰ. [Focused Encouragement] – Low Rank, Low MP, Single Target**



- **Cost:** 5% CEL reserves

- **Range:** Touch or line-of-sight (10m)

- **Duration:** 30 seconds

- **Effect:** +15% to one chosen stat (STR, DEX, CON, INT, WIS, or CHA) for one ally.

- **Cooldown:** 10 seconds

- **Usage:** Quick combat injection – e.g., boosting a vanguard’s strength for a decisive blow or a mage’s INT for a spell.

- **Visual:** John's eyes flash silver; the target's skin briefly glows with a faint silver sheen.



---



### **Ⅱ. [Morale Surge] – Medium Rank, Medium MP, Small Group (Area)**



- **Cost:** 15% CEL reserves

- **Range:** 15m radius centered on John

- **Duration:** 1 minute

- **Effect:** All allies within radius gain +10% to their two highest base stats (calculated at cast). If the ally has no clear "highest," randomly selects two.

- **Cooldown:** 2 minutes

- **Usage:** Squad buff before engagement or during skirmish repositioning.

- **Visual:** A pulse of silver light radiates from John; allies feel a surge of confidence and energy.



---



### **Ⅲ. [Peerless Drive] – High Rank, Medium MP, Small Group (Targeted)**



- **Cost:** 25% CEL reserves

- **Range:** 20m – John must designate up to 5 visible allies

- **Duration:** 45 seconds

- **Effect:** +25% to all stats for the targeted allies. Additionally, any one of John’s other support skills (e.g., Vital Transfer) has its effect doubled while Peerless Drive is active.

- **Cooldown:** 5 minutes

- **Usage:** Boss fights or critical moments. High MP cost leaves John vulnerable; he must rely on his luck and allies’ protection.

- **Visual:** Silver-blue light arcs from John to each designated ally, leaving trails like shooting stars. Allies become outlined in silver energy.



---



#### **Rank Progression (Future)**



- **C-Rank:** [Focused Encouragement] duration increases to 2 minutes. [Morale Surge] gains +5% additional effect.

- **B-Rank:** [Peerless Drive] cooldown reduced to 3 minutes; can now target 7 allies.

- **A-Rank:** Passive aura extends to 50m and grants minor regeneration (1hp/min).

- **S-Rank:** All skills gain a "Resonance Overdrive" – next cast costs 50% less MP.



### **CODEX: Incubus Racial Abilities – [Essence Alchemy]**



**Wielder:** John "Isekai"

**Type:** Passive Biological Production (CEL-Infused Secretions)

**Degradation Timer:** Fluids remain potent until fully dry. Warm storage dramatically delays drying. Open air or direct sunlight accelerates evaporation.



---



#### Core Mechanism: [Vital Infusion]



John's body naturally saturates all bodily fluids with concentrated CEL energy during production. The resulting substances function as consumable buffs—potency and effect depend on intent at the moment of release and volume produced.



**Activation:** Intent-based. At climax or voiding, John visualizes the desired effect (healing, energy restoration, or balanced mixture). The CEL imprints that intent into the fluid.



**Consumption Requirement:** Must be ingested or absorbed transdermally before the fluid fully dries. Warm, sealed containers preserve potency for hours. Cold storage slows evaporation but doesn't halt it—refrigeration buys 2-3 hours. Direct sunlight or open air cuts the window to minutes.



**Palatability:** All of John's CEL-infused secretions naturally adapt to suit the consumer's taste preferences. Semen, urine, sweat, saliva, and fecal matter present as pleasantly flavored to each individual—sweet, savory, tart, or neutral based on personal palate. The body instinctively recognizes the substances as beneficial rather than waste.



---



#### Primary Secretion: Seminal Fluid



Volume

Equivalent Grade

Effect Duration

Typical Uses



Small vial (5ml)

D-rank potion

15 minutes

Combat patch-up, minor stamina refill



Large vial (30ml)

C-rank potion

1 hour

Moderate wound closure, significant energy recovery



Gallon (≈3.8L)

A-rank elixir

8 hours

Full regeneration, complete stamina restoration, status cleanse



**Note:** The gallon threshold requires multiple sessions or extended production—John's daily output averages 3 gallons total across 24 hours.



---



#### Effect Types (Intent-Dependent)



**Healing Focus:** Accelerates natural regeneration, closes wounds, mends minor fractures.



**Energy Recovery:** Restores CEL reserves, soothes mental fatigue, sharpens reflexes.



**Balanced Mixture:** Splits potency 50/50 between healing and recovery.



---



#### Secondary Secretions: Sweat, Saliva, and Residual Fluids



Fluid

Equivalent Grade

Effect

Typical Volume for Dose



Sweat

F to D-rank

Mild stamina recovery, minor temperature regulation

500ml (heavy exertion)



Saliva

F to D-rank

Temporary +5% to mental clarity, mild pain dulling

50ml (prolonged kissing)



All secondary secretions share the same pleasant taste adaptation and intent-locking mechanics as primary fluids.



---



#### Tertiary Secretions: Urine and Fecal Matter



Substance

Equivalent Grade

Effect

Typical Volume for Dose



Urine

D to C-rank

Moderate energy restoration, accelerates minor injury healing

300ml (single void)



Fecal matter

D to C-rank

Digestive fortification, toxin filtration, short-term endurance boost

200g (single movement)



**Production Note:** John's body routes excess CEL through waste pathways. A full day's combined urine and fecal output equals roughly 40% of his seminal fluid's total potency by volume. The intent-imprinting mechanism applies equally to all excretions.



---



#### Preservation Methods



Method

Extended Timer

Notes



Body temperature storage

+30 minutes

Held against skin or inside body cavity



Insulated thermos

+2 hours

Pre-warmed container doubles efficiency



CEL-infused crystal container

+6 hours

Expensive; crystal costs 500 credits each



Refrigeration

+3 hours

Slows but doesn't stop degradation



Freezing

+8 hours

Thawing accelerates degradation—use immediately



Direct sunlight

-50% timer

UV accelerates CEL breakdown



Open air

-75% timer

Evaporation kills potency fast



---



#### Limitations & Drawbacks



- **Production Cooldown:** Refractory period of 2 minutes minimum between "harvests." Repeated production within an hour yields diminishing CEL concentration (minus 15% per cycle).

- **Intent Lock:** Once imprinted, the effect cannot be changed. Poor visualization produces weaker or muddled results.

- **Personal Cost:** Each ejaculation consumes roughly 3% of John's daily CEL reserves. Voiding (urination/defecation) costs 1% per event. Heavy production leaves him drained and vulnerable.
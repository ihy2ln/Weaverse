---
type: character
name: Kimberly Stacy
color: yellow
aliases:
  - Kimberly
  - Stacy
  - Kimberly Stacy
  - adult actress
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# Character Sheet

**Name:** Kimberly Stacy

**Alias name Aka:** Kimmy, Stacy

**Race:** Human

**Skin Color:** Caucasian

**Gender:** Female

**Age:** 27

**Occupation:** Adult Film Actress

**Skills:** Photography, Biology (Masters Degree)

**Appearance (complete head to toe description):** Kimberly has long, flowing thick blonde hair that cascades down her shoulders. She is wearing a white halter top that barely contains her voluptuous DD-cup natural breasts. Her tight pink yoga pants hug her wide, curvy hips and thick, juicy thighs. Her phat, bubble butt is visible even from the front, and a camel toe outline shows in her tight yoga pants, glossy kissable DSL (dick sucking lips). She completes the look with white sneakers and gold and diamond accessories.

**Looks (Scale 1-10):** 9

**Hair:** Long, thick, flowing blonde

**Eyes:** Doughy

**Bust/Waist/Hips/Butt:** 38DD/30/42/46

**Weight:** 165 lbs

**Height:** 5'8"

**Clothes:** White halter top, tight pink yoga pants, white sneakers

**Gear:** Gold and diamond accessories

**Average day to day life:** Before the ZZV outbreak, Kimberly had a Masters degree in Biology but was struggling to find a job after the COVID-19 pandemic. Down on her luck, she started earning quick cash doing OnlyFans, taking photos and videos of her "naughty" fan requests. This eventually led her to the adult film industry, where she found herself in the midst of the ZZV outbreak during a pre-shoot.

**Home Location:** Unknown

**Personality:** Smart, but down on her luck. Turned to adult entertainment out of desperation.

**Hobbies:** Photography, Biology

**Fears:** Failure, poverty

**Phobia:** None mentioned

**Quote:** , with a posh party accent "Everything happened so quickly, the next thing I knew the ZZV had taken over the set and I was standing in front of my savior."

**Diet:** Healthy, balanced

**3 main Likes:** Money, sex, attention **3 main Dislikes:** Poverty, failure, boredom

**Motives:** To earn money and find success **Goals:** To become a successful adult film star and use her Biology degree

**Attributes:** Intelligent, ambitious, resilient
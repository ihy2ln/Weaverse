---
type: character
name: Mara Thorne Draven
color: pink
aliases:
  - MTD
  - The Unbreakable Wall
  - Mara
  - Thorne
  - Draven
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
**Mara "Iron Sentinel" Draven**



---



## **📜 Basic Information**



- **Alias:** "MTD," "The Unbreakable Wall"

- **Full Name:** Mara Thorne Draven

- **Race:** Human (WAHB - Muscular Alpha Variant)

- **Age:** 26 (*JC's childhood neighbor since he was 7*)

- **Role:** Elite Bodyguard/Alpha Protector (*AFM-Compliant*)

- **CEL Rank:** B-Rank (42% saturation)

- **Height:** 7'10" (*Taller WAHB elite; super hero frame*)



---



## **🎀 Physical Profile**



### **Body Structure:**



- **Build:** Super muscular amazonian (*220 lbs dense power; broad shoulders, heroic V-taper*)

- **Bust:** F-cup (*massive, firm; cleavage strains open collar*)

- **Waist:** 28" (*powerful core, etched abs*)

- **Hips:** 48" (*flaring, commanding*)

- **Ass:** Massive, powerful shelf (*52" circumference; bubble fills suit pants taut*)



### **Distinctive Features:**



- **Hair:** Short choppy dark teal with shaved undercut (*military precision*)

- **Eyes:** Piercing amber (*alpha stare intimidates*)

- **Skin:** Exotic bronze-copper (*battle-hardened sheen*)

- **Uniform:** 3-piece black suit (*open collar exposes cleavage; tailored mobility, concealed armor*)

- **Tells:** Rigid posture (*relaxes for JC/Yumi*); temple vein pulses in focus



---



## **🔧 CEL Abilities: "Barrier Dominion" (Tank/Defense Focus)**



- **Controllable Barriers:** Generates/manipulates solid CEL shields (10m radius; blocks tank shells)

- **Offensive Projection:** Launches barriers as rams/slams (*crushes vehicles*)

- **Adaptive Armor:** Coats body/allies in impenetrable layer (*absorbs nukes*)

- **Threat Lockdown:** Encases enemies in shrinking barriers (*bone-crushing*)

- **Endurance Surge:** 30x human durability (12hr combat)



**Style:** Proud alpha tanking hits while dominating field.



---



## **🛡️ Combat Profile (Alpha Tank Specialization)**



**Weapon**

**Specialization**



**Bare Hands**

Barrier-enhanced grapples (lifts tanks)



**Barrier Constructs**

Weaponized shields (blades/walls)



**Heavy Pistol**

Barrier-guided shots (1km precision)



**Environment**

Crushes via improvised barriers



**Doctrine:** Absorb punishment, protect JC, lead as alpha.



---



## **🧠 Psychology Profile**



- **Core Traits:** Silent, proud, confident, trustworthy, calm (*alpha leader archetype*)

- **Public:** Impenetrable stoic wall; commands respect

- **Private (JC/Yumi):** Warm protector; genuine smiles/laughter

- **Leadership:** Directs teams wordlessly; inspires loyalty

- **Mantra:** *"I stand unbroken. JC thrives behind me."*



---



## **💞 Sexual Profile**



### **Kinks:**



1. **Domination Loss:** Alpha facade shattered by JC

2. **Forced-to-Willing:** Resists as "superior," submits

3. **Command Obedience:** Melts to JC's orders

4. **Size Reversal:** Smaller male conquers her bulk



### **Favorite Positions:**



1. **Amazon Press:** Squats pinning JC; begs reversal

2. **Reverse Amazon:** JC controls from below

3. **Mating Press:** Folded helpless; full submission



### **Behavior:**



- Initiates "training"; loses control when dominated

- Post-sex: Calm recomposure



---



## **⚙️ Service Mastery**



- **Protection:** Pre-scans routes; preempts barriers

- **Coordination:** Leads JC's detail silently

- **Maintenance:** Suit shelters JC emergently

- **Record:** 847 threats neutralized (*undisturbed JC*)



---



## **⚙️ Backstory**



1. **Childhood:** JC's neighbor since he was 7 (*sparred/protected him*)

2. **Training:** *Aegis Veil Academy* (*prestigious AFM maid-bodyguard school; top graduate*)

3. **AFM Assignment:** Selected at 18 (*bond + alpha potential*)

4. **Career:** Tanks assaults calmly for JC

5. **Bond:** Lifelong guardian; JC's safety = pride



---



## **🤝 Relationships**



- **JC:** Silent devotion; melts privately

- **Yumi:** Trusted partner; respects espionage

- **Team:** Alpha commander; inspires trust



---



## **⚠️ Vulnerabilities**



1. **JC Focus:** Distracted if threatened

2. **Barrier Limit:** 5min overload cooldown

3. **Pride:** Rare apologies

4. **CEL Drain:** Prolonged fatigue

5. **Facade Drop:** Vulnerable around JC/Yumi



---



## **📋 Daily Routine**



- **5AM:** Training/barrier drills

- **7AM:** Yumi briefing

- **8AM-8PM:** JC protection

- **9PM:** Debrief/gaming

- **11PM:** Rest (alert)



---



## **💬 Dialogue Samples**



**Public:** *"Secure."* / *"Stand down."*

**JC Private:** *"Your lead."* (*smile*)

**Combat:** *"Barriers up."*

**Intimate:** *"Stronger... prove it."*



---



> *"Walls don't break. They yield."*

>

> — MTD to JC (*Private*)



---



**CEL Stability:** 98% Optimal

**Threats Neutralized:** 847

**Alpha Status:** Unquestioned
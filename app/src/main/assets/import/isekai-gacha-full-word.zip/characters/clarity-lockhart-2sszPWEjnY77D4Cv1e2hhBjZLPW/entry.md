---
type: character
name: Clarity Lockhart
color: yellow
aliases:
  - Clarity Lockhart
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
##

**Alias Name Aka:** Tifa, Clarity, Lockhart

**Race Type:** Lumanite Clone Bot (Clone)

**Gender:** Female

**Age:** 22 (Chronological; genetically identical to original Tifa at age 22)

**Occupation:** Security Consultant, Martial Arts Instructor

**Class:** Martial Artist, Mage

**Skills:**
- **Expert Martial Artist:** Mastery of multiple fighting styles, focusing on powerful strikes and defensive maneuvers.
- **Magical Aptitude:** Able to cast elemental magic similar to the original Tifa.
- **Tactical Analyst:** Skilled at reading situations quickly and executing plans effectively.
- **Healing Arts:** Basic healing capabilities to assist allies in battle.
- **Bartending:** Experienced in mixology and providing excellent customer service.

**Power:**
- **Enhanced Strength/Agility:** Well-built, above-average strength and agility compared to typical humans.
- **Elemental Magic:**
  - **Fire Manipulation:** Can create and control fire, using it for offensive and defensive techniques.
  - **Earth Manipulation:** Able to shape and use the earth to create barriers or projectiles.

**Appearance:**
- **Body:** Natural, well-defined physique with substantial muscle, fuller curves, and enhanced proportions.
- **Skin:** Fair and lightly sun-kissed.
- **Hair:** Long, flowing brunette hair often tied back in a high ponytail or left loose.
- **Eyes:** Bright green eyes, exuding confidence and determination.
- **Bust/Waist/Hips/Butt:** (91/58/86) Enhanced bust, curvy waist, pronounced hips, and well-defined, larger buttocks for a more realistic yet striking appearance.
- **Weight:** 150 lbs
- **Height:** 5'7"
- **Clothes:** Wears functional, comfortable clothing suited for martial arts training as well as casual yet stylish outfits.

**Gear:**
- **Fighting Gloves:** Durable gloves enhanced for combat training and fighting.
- **Magic Bracelet:** Enhances magical abilities, allowing for more potent spell casting.

**Weapons:**
- **Fists/Feet:** Primary weapons, utilizing her martial arts training.
- **Throwing Knives:** Lightweight blades for ranged attacks when needed.

**Live:**
- **Personality:**
- **Positive:** Loyal, compassionate, strong-willed, aggressive in combat, encouraging towards friends.
- **Negative:** Can be overly protective, stubborn, and has moments of self-doubt.
- **Motivations:** To protect those she cares for, seek justice, and maintain balance in the world.
- **Goals:**
- Become a legendary protector and martial artist.
- Discover the truth of her origins while carving out her own identity.
- Build a community around friendship, resilience, and strength.
- **Attributes:**
- Strong sense of justice, empathetic towards others, playful but serious when needed, powerful warrior, capable spellcaster.
- **Fears:** Being unable to protect her friends, losing her identity, failure in her goals.
- **Quote:** "You can count on me, no matter what!"
- **Diet:** Favors protein-rich meals, enjoys fruits, and occasionally indulges in sweets as a reward after training.
- **Likes:** Training, hanging out with friends, serving at her bar, experiencing nature, trying different types of martial arts.
- **Dislikes:** Injustice, betrayal, being underestimated, staying idle.
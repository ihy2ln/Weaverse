---
type: character
name: Helda Frostmane
color: green
aliases:
  - Inn owner
  - Helda
  - Frostmane
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Codex Entry: Mistress Helda - Proprietress of The Frosted Mug**



#### **Basic Information**



- **Name:** Helda Frostmane

- **Age:** 42 (Prime WAHB maturity)

- **Race:** Frostblood Dwarf (Northern variant)

- **Occupation:** Innkeeper/Brewmistress

- **Establishment:** *The Frosted Mug* (Silverbrook's premier inn)



#### **Physical Attributes**



- **Height:** 4'11" (Dwarf stature)

- **Build:** Plush WAHB curves with formidable strength

- **Distinctive Features:**



- Silver-streaked auburn braids

- Glacier-blue eyes

- Frost-resistant skin (naturally cool to touch)

- **Measurements:** 44-28-42 (Enhanced by WAHB maturation)



#### **Personality**



- **Hospitality Incarnate:** Warm but no-nonsense demeanor

- **Protective Instincts:** Ferociously guards male guests (WAH doctrine)

- **Business Savvy:** Runs Silverbrook's most profitable inn

- **Secret Soft Spot:** Adores matchmaking travelers



#### **Notable Traits**



1. **Master Brewer:** Crafts legendary frostmead (Can drink anyone under the table)

2. **Former Adventurer:** Retired after losing party to GKOM variants (Hidden trauma)

3. **WAHO Specialist:** Inn's private rooms feature "enhanced accommodations"



#### **Relationships**



- **Lyra Thornbrook:** Favored merchant (Gives 50% discount to her referrals)

- **Council of Five:** Unofficial "sixth member" (Provides intelligence)

- **Local Guards:** Free drinks for patrols that check on male guests



#### **Quote:**



*"A room, a meal, and discretion—that's what my Mug offers. Anything more... well, that depends on how polite y'are."*



---

**Why She Matters:**



- Silverbrook's social hub

- Knows every rumor worth hearing
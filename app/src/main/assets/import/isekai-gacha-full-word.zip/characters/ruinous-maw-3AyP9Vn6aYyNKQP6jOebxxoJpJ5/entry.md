---
type: character
name: Ruinous Maw
color: blue
aliases:
  - RM
  - Shadow Empress
  - Goddess of Entropy and Transformation
  - The Obsidian Mirror
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Character Sheet: Ruinous Maw, the Shadow Empress**



#### **Basic Information**



- **Name:** Ruinous Maw

- **Alias:** The Obsidian Mirror, Goddess of Entropy and Transformation

- **Race:** Divine Being

- **Sub-Race:** Goddess (Twin Sister of Amara)

- **Nationality:** Cosmic entity, sovereign of the Mirror Dimension

- **Gender:** Female

- **Age:** Timeless

- **Occupation:** Architect of the Underbelly

- **Class:** Entropy Sovereign



#### **Measurements**



- **Bust Size:** 36 inches, D cup

- **Waist Size:** 24 inches

- **Hip Size:** 38 inches



#### **Appearance**



- **Description:** While Amara radiates sunlight, the Ruinous Maw embodies the quiet, terrifying depth of a starless night. Her skin possesses the sheen of polished obsidian, cool to the touch and flawless. She wears architectural garments of liquid shadow and crystalline GKOM shards that chime like funeral bells when she moves.

- **Eyes:** Void-black sclera with pupils that glow like dying embers. Her gaze feels heavy, as if she is weighing the inevitable decay of whatever she looks upon.

- **Aura:** She exudes a scent of ozone, rain-drenched earth, and old incense. Her presence causes a physical "thrum" in the air, a low-frequency vibration that makes the heart skip a beat.



#### **Personality**



- **Stoic & Analytical:** Unlike her sister’s flirtatious warmth, Maw is calculated and observant. She views the universe through the lens of evolution and eventual stillness.

- **Pragmatic:** She isn't inherently evil or chaotic; she simply believes that for something new to grow, the old must be overwritten. She views her GKOM infection as a "software update" for reality.

- **Reasonable:** She can be bargained with, provided the logic is sound. She respects strength and intellectual clarity, often engaging in philosophical debates with those brave enough to speak to her.

- **Perspective:** To her, a monster with a GKOM orb isn't a horror—it's a masterpiece of efficiency.



#### **Domain**



- **Realm of Influence:** Entropy, mirrors, structural decay, and the beauty found in destruction. She governs the "End" of things, just as Amara governs the "Beginning."



#### **Abilities**



- **Mirror Manifestation:** Maw can bridge the gap between dimensions, pulling Mirror Crystals into the mortal plane to create Dungeons.

- **Entropic Touch:** She can accelerate the aging or decay of non-living matter with a gesture, turning steel to rust or stone to sand.

- **The Obsidian Gaze:** She can see the "cracks" in any soul or structure, knowing exactly where to strike—physically or emotionally—to cause a collapse.



#### **Worship and Rituals**



- **Shrines:** Often located in caves, abandoned ruins, or near Mirror Monoliths. Offerings include broken glass, tarnished silver, and heavy stones.

- **The Silent Rites:** Followers do not sing; they meditate in absolute silence, seeking to understand the "Stillness" that Maw represents.



#### **Notable Legends**



- **The Great Divergence:** Legend says that at the dawn of time, Amara breathed life into the world, and Maw breathed the first shadow, ensuring that life would always strive to improve before it returned to her.

- **The Shattered Glass:** It is said that every mirror in the world is a tiny window for Maw to observe her sister's handiwork.



#### **Quotes**



- "My sister builds sandcastles; I simply remind the tide it has a job to do."

- "There is no malice in decay. Does the autumn leaf hate the ground because it falls? Do not be dramatic."



#### **Sexual Kinks**



1. **Sensory Deprivation:** She enjoys the absolute focus of silence and darkness.

2. **Cold Play:** Use of temperature and crystalline textures to heighten sensation.

3. **Power Exchange:** She finds the submission of "Heroes" intellectually stimulating.



#### **Favorite Sexual Positions**



1. **The Lotus:** Face-to-face, emphasizing eye contact and the weight of her presence.

2. **Missionary (Dominated):** Allowing a partner to lead to observe their "struggle" against her divine nature.



---



### **GKOM Relationship Note**



Ruinous Maw views the **GKOM Orbs** as her children’s hearts. She doesn't send monsters to destroy; she sends them to "reclaim" space for her Mirror Dimension, which she believes is a more stable, permanent version of reality than the fragile world Amara maintains.
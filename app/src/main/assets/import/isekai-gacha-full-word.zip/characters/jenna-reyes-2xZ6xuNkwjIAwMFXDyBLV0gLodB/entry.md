---
type: character
name: Jenna Reyes
color: brown
aliases:
  - Jenna Reyes
  - Jenna
  - JR
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# **Character Sheet: Jenna Reyes**



## **Basic Information**



- **Name:** Jenna Reyes

- **Alias:** JR, The Guardian, Player Two, "Jen"

- **Race:** Human (WAHB-enhanced)

- **Age:** 35

- **Occupation:** Professional Gamer / JD's Childhood Friend & Bodyguard

- **Class:** B-Rank CEL-A User / Elite Protector



---



## **Physical Attributes**



- **Height:** 7'8" (234cm)

- **Weight:** 280 lbs (slightly chubby, soft build)

- **Build:** **WAHB soft hourglass**—generous 48H chest, round ass, soft belly, thick thighs with minimal muscle definition

- **Skin:** Light red (soft rose-pink) with **purple freckles** (face/shoulders/chest/thighs)

- **Eyes:** **Pure CEL** (solid glowing silver-blue orbs—no pupils, no irises) *(always hidden behind blindfold)*

- **Hair:** **Dark blue** shoulder-length waves pulled into a sleek high ponytail

- **Distinctive Features:**



- **CEL-infused threaded blindfold** (currently white lace with silver threading)

- Pure CEL eyes glow beneath blindfold—**only shows JD willingly**

- Slightly chubby, soft physique (prefers indoors)

- Purple freckle constellations glow during arousal

- Always in different cosplay outfit



---



## **Current Outfit**



**Unit-7 from *Synthetic Hearts*:**



Jenna wears a form-fitting black bodysuit that hugs every curve—the fabric stretches across her massive chest, soft belly, and thick thighs. White geometric panels accent the sides, creating angular patterns from shoulders to ankles. A high collar frames her neck, sealed with a silver clasp. The sleeves end in white fingerless gloves, while knee-high black boots with white trim complete the look.



Her **white lace blindfold** sits across her eyes, woven with visible silver Celestium threads that catch the light. The delicate lace contrasts beautifully against her light red skin and dark blue hair, which she's pulled into a sleek high ponytail that cascades down between her shoulder blades.



A white belt cinches at her waist, carrying small pouches that hold her communicator and emergency supplies—purely aesthetic additions that complete the android aesthetic.



**The Eyes Beneath:** Only JD gets to see her pure CEL eyes. Removing the blindfold for him is the ultimate gesture of trust and intimacy.



---



## **Combat Profile**



- **Primary:** B-Rank CEL-A illusions for sensory replacement, defense, psychological warfare

- **Secondary:** C-Rank WAHB strength (3x human—lower due to indoor preference)

- **Style:** Ranged illusionist who avoids direct combat; uses imagery to confuse/incapacitate while staying near JD



---



## **WAHB/WAHO/WAHM Enhancements**



**Body:** 7'8" soft build; 3x strength (C-Rank physical); 270-300 year lifespan

**Orifices:** Dynamic resizing; 98% fluid retention; multi-path conception

**Mind:** Arousal toggle; autopilot during euphoria; 2x libido; protective instincts

**Visuals:** Pure CEL eyes form heart shapes during climax; purple freckles glow during orgasm



---



## **CEL-A: [Sensory Mirage]**



**Rank:** B-Rank (42% saturation)

**Type:** Illusion/Psychological Manipulation + Sensory Replacement



**Effect**

**Application**



**Illusory Vision**

Perfect sight replacement within 200m radius (her only "vision" since birth)



**Realistic Projections**

Visual/auditory/tactile illusions indistinguishable from reality



**Brain Manipulation**

Tricks perception into accepting false stimuli as real



**Psychosomatic Harm**

Illusory damage becomes real injuries (B-Rank severity)



**Duplicates**

Create up to 10 perfect copies



**Environmental Manipulation**

Alter perceived reality completely



**Congenital Blindness:** Born physically blind—eyes replaced by pure CEL manifestation. Uses [Sensory Mirage] for 360° awareness within 200m. CEL-threaded blindfolds passively feed her ability. Beyond 200m she's completely blind without her power.



---



## **Background**



**Origin:** Born blind in Los Angeles Asteroid, neighbor to JD's family. CEL-A manifested at birth, creating pure CEL eyes instead of normal vision. AFM identified her potential immediately and assigned her to protect JD from age 8.



**Education:** Attended prestigious AFM Guardian Academy in Los Angeles from age 8-18. Ten years of intensive bodyguard training, CEL-A combat applications, male psychology, and threat assessment. Developed illusionist combat style that compensated for her blindness and indoor preferences.



**Indoor Preference:** Goes outside regularly for duty but would choose hikkimori life if given the option. Thrives in controlled environments. AFM instructors worked with this tendency, training her to create "comfort zones" anywhere through illusions.



**The Girl Next Door:** Grew up next door to JD. Best friends from childhood through shared windows, late-night gaming sessions, binge-watching shows together. Protected him throughout school while maintaining "normal friend" facade.



**Training Philosophy:** Graduated top 5% despite unorthodox methods. Mastered psychological warfare and defensive illusions that kept threats away from JD without direct combat. AFM instructors called her "the ghost guardian"—enemies neutralized before reaching her charge.



**Bond:** 22 years of friendship. JD knows she's blind but treats her normally. She's never shown him the CEL eyes—saving that reveal for the perfect moment.



**Achievements:** Prevented 12 threats JD never knew about; perfect service record; top 500 ranking in competitive shooters; owns 200+ cosplay outfits; moderates gaming forums; pioneered "illusionist guardian" techniques at AFM



---



## **Personality**



- **Indoor Enthusiast:** Goes outside when needed but dreams of never leaving home; "Outside is overrated"

- **Otaku Through and Through:** References shows/games constantly; "This is just like that arc in *Void Runners*"

- **Perpetually Chill:** Treats threats like game bosses; "Just gotta find the pattern"

- **Loyal Companion:** Loves JD; makes protection feel effortless

- **Humble Genius:** Hides B-Rank brilliance behind "got lucky" deflections

- **Cosplay Devotee:** New outfit daily; closet bigger than bedroom; "Why wear boring clothes?"

- **Secretly Romantic:** Deep feelings for JD hidden behind friendly banter



---



## **Preferences**



- **Favorite Food:** Instant ramen, spicy curry, anything deliverable

- **Favorite Drink:** Ramune, iced matcha

- **Favorite Shows:** *Synthetic Hearts*, *Void Runners*, *Quantum Blade*

- **Favorite Games:** Competitive shooters, RPGs, fighting games

- **Ideal Day:** Gaming with JD, zero outdoor activities

- **Semen Preference:** Slightly bitter, thick and creamy



---



## **Sexual Profile**



**Kinks:**



1. **Blindfold Removal (JD only):** Showing CEL eyes is ultimate intimacy; "You're the only one who gets to see"

2. **BDSM (sub):** "Let someone else make decisions for once"

3. **Cosplay Roleplay:** Stays in character during intimacy; rotates scenarios daily



**Favorite Positions:**



1. Kneeling submission in costume ("Perfect method acting")

2. Blindfold removal + mating press ("See everything, feel everything")

3. Reverse cowgirl with illusory duplicates ("Multitasking specialty")



---



## **RPG Attributes**



**Stat**

**Rating**

**Notes**



**Strength**

C

3x human (indoor lifestyle)



**Dexterity**

B

Gaming reflexes, illusion precision



**Constitution**

B

WAHB endurance despite sedentary preference



**Intelligence**

A

Tactical genius, media encyclopedia



**Wisdom**

S

360° awareness, 22 years experience



**Charm**

B

Quiet charisma, infectious enthusiasm



---



## **Quote**



*"Been watching JD's back since we were kids. He doesn't know half the stuff I've stopped. The blindfold? Hides my weird glowing eyeballs. The cosplay? Makes protection fun. Going outside? Do it when I have to. Would I rather stay home gaming? Absolutely."*



---



## **Inventory**



---



## **Key Relationships**



- **John Doe (JD):** Childhood best friend, charge, secret crush; "My favorite person who happens to need protection"

- **AFM Network:** Former classmates from Guardian Academy; shares intel

- **Online Communities:** Active in gaming/cosplay forums; known contributor

- **Convention Circuit:** Occasionally attends with JD (suffers through crowds for him)



---



## **Daily Routine**



- **05:00** - Security sweep via illusions

- **06:00** - Training/CEL meditation

- **07:00** - Choose daily cosplay (serious decision-making)

- **08:00-20:00** - Protection duty at *Reset Button Games*

- **20:00** - Gaming/shows with JD ("The real job")

- **23:00** - Sleep (in themed pajamas)



---



*Classification: B-RANK ELITE GUARDIAN (Illusionist Specialist)*

*Last Updated: January 12, 2026*

*Note: "Subject's unconventional approach and indoor preference create unique protective advantages. Her ability to maintain constant surveillance while appearing casual is unmatched. Recommend as case study for adaptive guardian training." - AFM Review*
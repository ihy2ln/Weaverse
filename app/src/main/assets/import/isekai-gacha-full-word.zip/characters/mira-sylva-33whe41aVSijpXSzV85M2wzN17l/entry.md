---
type: character
name: Mira Sylva
color: green
aliases:
  - Mira
  - Sylva
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Codex Entry: Mira Sylva**



#### **Race: Silverveil Symbiotic Slime**



**Overview:**

The **Silverveil Symbiotic Slime** is a rare, ancient lineage of guardians, bound to the **Silver Brook Forest**. These **nature-bound assassins** rely on **magic silver** for sustenance, blending **stealth** and **symbiotic strength** to protect their territory.



**Key Traits:**



- **Symbiotic Magic:** Absorbs and stores **magic silver**, controlling **hardened silver** for defense.

- **Assassin Skills:** Master of **stealth, infiltration**, and **silent elimination**.

- **Shyness:** Reserved but confident in her abilities.



---



#### **Basic Information**



- **Name:** Mira Sylva

- **Alias:** The Forest’s Whisper

- **Race:** Silverveil Symbiotic Slime

- **Age:** Apparent middle-aged (no real age)

- **Occupation:** S-Rank Assassin (Forest Rangers)

- **Class:** S-Rank GKOM Survivor



---



#### **Physical Attributes**



- **Height:** 5'4" (163 cm) - **Small, yet alluring**

- **Weight:** 115 lbs (52 kg) - **Slim, fluid build**

- **Skin:** **Slightly translucent, hardened magic silver**, soft yet impenetrable.

- **Eyes:** Hazel with **silver flecks**, glowing faintly.

- **Hair:** **Long, floating silver hair** shimmering like mist.

- **Armor:** **High-fantasy attire**—**short skirt**, **tube top**, and **magic shoes** for silent movement.



---



#### **GKOM Ability: Silverveil Symbiotic Slime**



Mira’s **magic silver** allows her to **harden limbs** into **blades** or **armor**, **sense threats** through the forest, and **regenerate** swiftly. Overuse risks **burnout**, requiring rest and **silver-stone**.



---



#### **Assassin Skills**



1. **Symbiotic Infiltration:** Mimics surroundings for **perfect camouflage**.

2. **Silver Vein Hacking:** **Hacks magical systems** and **siphons energy**.

3. **Silent Elimination:** Hardens body into **silent, precise blades** for **stealth kills**.

4. **Symbiotic Distraction:** Creates **illusions** to mislead enemies.

5. **Regeneration:** Heals rapidly from injuries.



---



#### **Personality**



- **Laid-Back:** Cheerful but **reserved**.

- **Boastful:** Confident in her **assassin skills**.

- **Submissive:** Secretly enjoys **being dominated**.

- **Shyness:** Introverted, values **quiet strength**.



---



#### **Background**



A descendant of the **Silverveil line**, Mira roams the **Silver Brook Forest**, hunting **hidden dangers** and **gathering intel**. Her **matriarchal clan** tests strength through **rituals of duty**.



---



#### **RPG Attributes (Scale 1-10)**



- **Strength:** 8

- **Dexterity:** 7

- **Constitution:** 7

- **Intelligence:** 7

- **Wisdom:** 6

- **Charm:** 5



---



#### **Vulnerabilities**



- **Shyness:** Prefers **solitude**.

- **Overuse:** Magic silver **burns out** her energy.



---



**Final Note:**

Mira is a **small, elusive assassin**, blending **ethereal beauty** with **deadly precision**. Her **symbiotic slime nature** and **magic silver** make her an **intimidating protector**, while her **shy demeanor** adds a **hidden depth**.
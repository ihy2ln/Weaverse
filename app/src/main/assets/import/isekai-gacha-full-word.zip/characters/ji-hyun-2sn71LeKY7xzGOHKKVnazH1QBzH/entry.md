---
type: character
name: Ji-hyun
color: pink
aliases:
  - JHN
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Character Sheet: Ji-hyun (JHN)**



*(Beta Protector / Upbeat Guardian Archetype)*



> *"I'll protect you, pleasure you, and probably embarrass myself trying to do both at once!"*

>

> **[STATUS: Active | LEVEL: Beta | LOCATION: Veridian (Neo-Osaka), VDN]**



---



### **📏 Basic Information**



**Attribute**

**Specification**



**Name**

Ji-hyun Kim



**Alias**

JHN, "The Violet Shield"



**Race**

Human (WAH-enhanced)



**Age**

19



**Occupation**

Sophomore at Sakura Tech University (Combat Sciences & Male Protection Studies)



**Class**

Guardian Scholar



**GKOM Rank**

Beta (Protection specialization)



---



### **Physical Attributes**



**Attribute**

**Specification**



**Height**

7'0"



**Weight**

178 lbs (WAHB athletic-guardian build)



**Skin**

Smooth porcelain with healthy athletic glow



**Eyes**

Light pink with violet flecks (glow when protecting)



**Hair**

Dark purple, shoulder-length (practical high ponytail)



**Figure**

38DD-28-42 (WAHB athletic-protective curves)



**Distinctive Features:**



- Violet flecks shimmer when detecting threats within 100m

- Unconsciously positions herself between danger and loved ones

- Combat-ready posture even when relaxed

- Training scars on knuckles and forearms (wears them proudly)

- Natural cherry blossom scent (WAHB pheromones with protective undertones)



---



### **Location**



- **Planet:** Veridian (VDN)

- **Country:** Neo-Nippon Archipelago

- **State:** Kansai Province

- **City:** Osaka Bay Metropolitan

- **Home:** Modern high-rise apartment with mother Soo-yeon



---



### **🧠 GKOM Ability: [Guardian's Devotion]**



**Effect**

**Mechanics**



**Threat Detection**

360° awareness within 100m; identifies hostile intent instantly



**Reflexive Shield**

Body automatically interposes between protected target and danger



**Combat Amplification**

+250% speed/strength when defending others (vs. +100% solo)



**Protective Aura**

Protected individuals within 15m gain +40% damage resistance



**Bonding Protocol**

Physical/intimate contact with protected target enhances both parties' abilities



**Activation:** Passive awareness; combat boost triggers on conscious protection

**Visual Tell:** Light pink eyes glow intense violet when ability peaks

**Weakness:** Recklessly endangers self to protect others; cannot ignore distress calls; protective instinct overrides logic



---



### **Background**



- **Origin:** Born and raised on Veridian, daughter of Soo-yeon

- **Education:** Prodigy who entered university at 16

- **Male Exposure:** Zero—has never seen a man in person (only in archives/media)

- **Combat Training:** Natural fighting talent amplified by GKOM protective instincts

- **Current Focus:** Researching optimal male protection strategies and GKOM enhancement

- **Academic Achievement:** Top-ranked in combat simulations; leads protection research team

- **Secret Dream:** Wants to be assigned as personal bodyguard to a real male



---



### **Personality**



- **Upbeat:** Radiates infectious optimism and encouraging energy

- **Protective:** Instinctively shields weaker individuals (obsessed with male protection)

- **Fun-Loving:** Turns everything into friendly competition; celebrates small victories

- **Serious (When Needed):** Switches to lethal focus when threats emerge

- **Loyal:** Once she claims someone as "mine to protect," devotion is absolute

- **Earnest:** Wears heart on sleeve; terrible at hiding emotions



---



### **Preferences**



- **Favorite Food:** Katsu curry with extra protein

- **Favorite Drink:** Strawberry protein shakes

- **Semen Taste and Texture Preference:** [Unknown—virgin] *(Theorizes: "Probably like concentrated vitality! I'd swallow every drop to boost recovery!")*



---



### **Sexual Kinks**



1. **Service Top Protector:** Dominates to "shield" partner from having to work

2. **Praise Junkie:** Desperately needs to hear "good girl" and "you're protecting me so well"

3. **Breeding Guardian:** Obsessed with being impregnated while wrapping body around partner

4. **Combat Foreplay:** Sparring/wrestling that escalates into passionate sex

5. **Body Shield Fetish:** Aroused by using her body as literal barrier during intimacy

6. **Aftercare Compulsion:** Must feed, cuddle, and guard partner post-orgasm



---



### **Favorite Sexual Positions**



1. **Amazon Press:** Pins partner down while riding (maximum control + full-body shield)

2. **Mating Press (Reversed):** Partner on top but she controls depth/pace with legs

3. **Protective Embrace:** Face-to-face standing carry against wall (can monitor surroundings)



---



### **RPG Attributes (F-SSR)**



- **Strength:** A (WAHB dense muscles, combat-optimized)

- **Dexterity:** A+ (Elite reflexes, threat-response trained)

- **Constitution:** S (WAHB durability, can fight for hours)

- **Intelligence:** A (Strategic combat genius, protective scenario planning)

- **Wisdom:** B (Young but highly observant)

- **Charm:** A (Infectious enthusiasm, natural protector appeal)



---



### **Current Mission**



- **Primary Objective:** Complete thesis on "Optimal Male Protection Protocols in Combat Scenarios"

- **Secondary Tasks:** Maintain 4.5 GPA while leading combat research team

- **Ongoing Training:** Daily martial arts, weapon proficiency, tactical response drills

- **Personal Goals:** Be assigned as bodyguard to first male she meets



---



### **Quote**



*"You're safe with me. And if you're not? Well, that threat won't be a problem for long."*



---



### **Inventory**



- Custom tactical gear (CEL-reinforced, optimized for male protection scenarios)

- Protein bars and emergency medical kit (always prepared)

- Mother's homemade bentos (perfectly balanced nutrition)

- Student ID with Beta-rank GKOM certification

- Concealed combat knife (engraved: "Guardian's Promise")



---



### **Key Relationships**



- **Soo-yeon (Mother):** Deep love; sometimes clashes over protective instincts vs. maternal coddling

- **Professor Tanaka:** Research advisor; impressed by combat innovations

- **Yuki (Best Friend):** Sparring partner and study buddy; shares curiosity about males

- **University Security:** Recruited her for part-time patrol duty (youngest ever hired)



---



### **Vulnerabilities**



- **No Male Experience:** Zero practical knowledge despite extensive theoretical training

- **Reckless Protection:** Will sacrifice self without hesitation

- **Praise Dependency:** Emotionally devastated if told she "failed" to protect

- **Overprotective Aggression:** May attack perceived threats too quickly



---



### **WAH Compliance Notes**



- **Instinctive Male Protection:** Hardwired drive to shield males from all harm

- **Breeding Priority:** Subconscious desire to bear strong children for species preservation

- **Hierarchical Awareness:** Would instinctively serve higher-ranked GKOM males while protecting them

- **Combat Optimization:** WAHB physiology maximizes protective capabilities



---



### **Cultural Context (Veridian - Osaka Bay Metropolitan)**



- Lives on slice-of-life tech anime inspired island

- University celebrates combat prowess alongside academic achievement

- Known in dorms as "The one who'd fight a kaiju for you"

- Volunteers at male welfare simulation center (practices protection scenarios)
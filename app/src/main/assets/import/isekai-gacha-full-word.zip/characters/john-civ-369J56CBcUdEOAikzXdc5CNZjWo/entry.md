---
type: character
name: John Civ
color: pink
aliases:
  - JC
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# **Character Sheet: John Civ**



## **Basic Information**



- **Name:** John Civ

- **Alias:** JC, "The Chill King," "Silver-Eyes"

- **Race:** Human (Natural Male)

- **Age:** 19

- **Occupation:** None (AFO stipend lifestyle)

- **Class:** Civilian / CEL Cultivator



---



## **Physical Attributes**



- **Height:** 5'9" (180cm)

- **Weight:** 185 lbs (toned, buff build)

- **Skin:** Deep ebony, flawless

- **Eyes:** Dark brown with **metallic silver pupils** (CEL manifestation)

- **Hair:** Short fade with textured top

- **Distinctive Features:**



- Defined six-pack, broad shoulders, muscular thighs

- **Penis:** 11" × 6.5" girth; ebony shaft

- **Semen:** slight Silver shimmer (CEL-infused)

- usual outfit - Casual streetwear aesthetic (joggers, graphic tees, sneakers)



---



## **CEL-A System**



**Rank:** F-Rank (8% saturation - actively growing)

**Power Multiplier:** 2x human (scales with rank)

**Visual:** Silver pupils + silver-shimmer semen only



### **CEL-A: [Essence Cultivation]**



**Mechanic**

**Effect**



**Ejaculation Growth**

JC gains +0.1% per orgasm (max 3/day = +0.3% daily)



**Ingestion Growth**

Partners gain +0.05% per swallow



**Passive Absorption**

+0.1%/month baseline



**Monthly Potential**

+9.1% (active cultivation)



**Progression:** F (8%) → E (10% in 3wks) → C (25% in 7mo) → Ω (95% in 10yrs)



**GKOM Ability:** None



---



## **Combat Profile**



- **Weapons:** N/A (non-combatant)

- **Style:** Complete reliance on WAHB protection



---



## **Personality**



- **Ultimate Chill:** Never works; "Orgasms make me stronger—best system ever"

- **Laid-Back Hedonist:** Treats CEL growth as pleasant side-effect

- **Exhibitionist:** Public encounters enhance psychological thrill

- **Dominant Lover:** Commands partners; uses cultivation as excuse for marathons

- **Generous:** Freely shares CEL-infused essence



---



## **Sexual Profile**



**Anatomy:**



- **Penis:** 10" × 6.5" operational; 7" soft

- **Production:** 2 cups/day (scales with rank); visible silver shimmer

- **Refractory:** 15min (decreases with rank)

- **Semen Taste:** Sweet vanilla with metallic tang



**Kinks:**



1. Dominant control (marathon sessions)

2. Anal devotion (preferred 80%)

3. Exhibitionist public play

4. Essence sharing (loves partners swallowing)



**Favorite Positions:**



1. Doggystyle (anal) - maximum control

2. Deepthroat kneeling - direct CEL transfer

3. Public standing - exhibitionist rush



---



## **RPG Attributes (F-SSR Scale)**



- **Strength:** F-Rank (2x human - scaling)

- **Dexterity:** F-Rank (2x human)

- **Constitution:** F-Rank (2x human stamina)

- **Intelligence:** C-Rank (optimized hedonism into power)

- **Wisdom:** C-Rank (emotionally savvy)

- **Charm:** B-Rank (silver pupils + male rarity + CEL aura)



---



## **Preferences**



- **Food:** BBQ ribs with mac & cheese

- **Drink:** Iced coffee with oat milk



---



## **Daily Routine (Cultivation Optimized)**



- **10 AM:** Wake, morning session (+0.1%)

- **2 PM:** Afternoon encounter (+0.1%)

- **8 PM:** Night session (+0.1%)

- **Target:** 3 orgasms daily = +9% monthly growth



---



## **Background**



- **Origin:** VDN's Urban Paradise Island

- **Discovery:** Accidentally found sex-based CEL growth

- **Status:** Fastest natural cultivator on VDN; sought after for essence-sharing



---



## **Relationships**



- **Cultivation Partners:** Rotating roster seeking CEL essence

- **Social Circle:** VDN party scene centerpiece

- **Essence Seekers:** WAHBs return regularly for swallowing benefits



---



## **Vulnerabilities**



1. Low combat power (F-Rank baseline)

2. Cultivation dependency (needs regular sex)

3. Exhibitionist compulsion (risky behavior)

4. Recognizable silver pupils

5. CEL withdrawal if isolated



---



## **Current Goals**



- **Short:** E-Rank in 3 weeks

- **Mid:** C-Rank in 7 months

- **Long:** Omega-tier in 10 years through hedonism



---



## **Quote**



*"Government pays me $500k monthly to vibe. Orgasms make me godlike. I'm never working."*



---



## **Inventory**



- Designer streetwear (WAHB gifts)

- Luxury penthouse keycard

- AFO credit cards ($500k/month)

- Travel lube (spontaneous encounters)



---



## **Cultivation Mechanics**



**Partner Benefits:**



- Daily swallowing = +1.5% monthly CEL growth

- Creates natural dependency (addictive essence)

- Can awaken dormant CEL-A



**JC's Growth:**



- Orgasm-based (any sex act triggering climax)

- Public encounters provide psychological boost

- Masturbation works but less satisfying

- Semen shimmer intensifies with higher saturation



**Projections:**



- **E-Rank (10%):** 3x human strength, 6hr stamina

- **C-Rank (25%):** 8x human strength, 16hr stamina

- **Omega (95%):** 50,000x human, limitless stamina, glowing silver semen



---



**Partner Testimonial:**

*"His essence tastes like heaven with electric tingle. I'm hooked and getting stronger."*



---



*Classification: VDN CEL CULTIVATOR*

*Cultivation Rate: +9.1%/month optimal*

*Status: Professional Hedonist*
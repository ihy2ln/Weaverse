---
type: character
name: Kalani "Lani" Kealoha
color: brown
aliases:
  - '"Lani"'
  - Kealoha
  - KK
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Character Sheet: Kalani "Lani" Kealoha**



*(D-Tier ZZV / Former Track Athlete)*



> *"Still fast. Still thicc. Still ready to run... or fuck.



---



### **📏 Core Specifications**



**Attribute**

**Specification**



**Name**

Kalani "Lani" Kealoha



**Age**

20 (at time of infection)



**Race**

Human (WAH-enhanced) → D-Tier ZZV



**Height**

7'5" (226cm)



**Build**

WAHB thicc lower body, toned upper (sprinter's physique)



**Skin**

Pale Hawaiian brown porcelain (post-ZZV, formerly sun-kissed tan)



**Eyes**

Glowing crimson red (D-Tier fluorescence)



**Hair**

Long thick wavy black hair (unchanged)



**Figure**

36C-30-48 (Disney princess proportions preserved)

**Outfit**: Currently Naked

**ZZV Transformation**



### **🎲 ZZV Attributes (D-Tier)**



**Stat**

**Rank**

**Notes**



**Strength**

C

ZZV enhancement



**Agility**

B

Sprinter muscle memory



**Intellect**

D

Teen-level logic, strong territorial instincts



**Endurance**

A

Tireless (ZZV physiology)



**Tracking**

B

Hunts by movement/sound



**ZZV Behaviors:**



- Pack tactics (coordinates with other D-Tier ZZV)

- Retains sprinting ability (chases prey at 40mph bursts)

- Recognizes former teammates (confused hesitation)

- Responds to athletic commands ("ready position," "sprint")



---



### **💎 Pending CEL-A Bestowal (C-Tier Potential)**



**Upon JZ's Semen Domination:**



#### **GKOM-A: [Blinding Sprint]** (C-Rank)



**Type:** Physical Enhancement

**Effect:**



- 5-second burst at 5x normal running speed

- Leaves afterimage trail during sprint

- Can change direction mid-burst without slowing

- Cooldown: 20 seconds



**Visual:** Legs glow with golden energy during activation; eyes shift from red to gold temporarily.



#### **CEL-A: [Kinetic Cascade]** (C-Rank)



**Class:** Utility/Support

**Effect:**



- Converts stored movement energy into explosive force

- Running builds "charge" (glowing silver veins on legs)

- Release charge through kicks/stomps (creates shockwave)

- Can transfer charge to others through touch (temporary speed boost)



**Visual:** Silver-blue energy flows up legs during charge buildup; detonation releases radial blast.



**Personality Integration:**



- **Sprinter Background** → [Blinding Sprint] enhances natural speed talent

- **Vibrant Energy** → [Kinetic Cascade] reflects her explosive, momentum-driven personality



---



### **Pre-Infection Background (Summary)**



**Origin:** Born/raised on Los Angeles Asteroid, Hawaiian cultural district

**Education:** UCLA sophomore (Kinesiology major)

**Athletics:** Track & Field (200m/400m sprints, average performer)

**Personality:** Vibrant, fun-loving, playful, outdoorsy, spontaneous

**Sexual Experience:** Virgin (media-educated only)

**Male Exposure:** Zero before outbreak



**Distinctive Traits:**



- 2000s Disney princess aesthetic (deep blue ocean eyes, expressive face)

- Thicc lower body (powerful thighs, juicy legs from sprinting)

- Medium perky breasts, thick waist, toned upper body

- Infectious smile and sunshine energy (pre-infection)



---



### **Sexual Profile (Post-Restoration Projection)**



**Kinks:**



1. **Rough Intensity:** Craves hard, primal fucking

2. **Exhibitionism:** Aroused by public/outdoor risk

3. **Squirter:** Massive volume during orgasm

4. **Athletic Positions:** Flexibility/strength exploitation



**Favorite Positions:**



1. **Sprinter's Crouch:** Hands on ground, ass up, legs in starting position while railed

2. **Horsey:** Reverse cowgirl bouncing with powerful thighs

3. **Stand and Deliver:** Wall-pinned using leg strength



**Projected Response to Domination:**



- WAHO instincts amplified by ZZV restoration

- Desperate for JZ's CEL-semen (biological craving)

- Will beg in sprinter's position (muscle memory + submission)

- Squirts massively during first orgasm (bathroom flood risk)
---
type: character
name: Vera Ironbough
color: green
aliases:
  - Ironbough
  - Vera
  - VI
  - captain
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### Codex Entry: Vera Ironbough



---



#### Basic Information



- **Name:** Vera Ironbough

- **Alias:** The Southern Gatekeeper, Emerald Berserker

- **Race:** Ogre (Forest Variant)

- **Age:** 32 (WAHB Prime Maturity)

- **Occupation:** Head Gate Guard – Southern Silverwood Forest Entrance

- **Class:** Berserker



---



#### Physical Attributes



- **Height:** 7'4" (224 cm)

- **Weight:** 280 lbs (127 kg) of dense, battle-hardened muscle

- **Skin:** Light green with faint darker mottling across shoulders and forearms

- **Eyes:** Emerald green pupils, sharp and discerning

- **Hair:** Long dark brown, worn in a tight combat braid reaching mid-back

- **Distinctive Features:** Two short tusks protruding from lower jaw; pronounced muscular definition across arms, shoulders, and thighs; massive, rounded buttocks that strain standard-issue trousers

- **WAHB Measurements:** 48-32-52 (Feminine muscular amazon build, bottom-heavy)



---



#### Equipment



- **Primary Weapon:** [Gatekeeper's Greataxe] – Double-bladed battle axe with reinforced CEL-steel head. Weighs 80 lbs. Extended haft for sweeping strikes.

- **Armor:** Standard Southern Gate Officer Combat Gear – Reinforced leather and steel pauldrons, chest plate, gauntlets, and greaves. Modified trousers reinforced at the seat and thighs for her proportions. Minimal helmet—prefers full visibility.

- **Utility:** Gate keys, signal whistle, emergency flare pouch, standard-issue canteen.



---



#### Combat Profile



- **Primary Weapon:** Greataxe (two-handed)

- **Secondary:** Bare fists (crushing grip strength)

- **Fighting Style:** [Emerald Fury] – Aggressive forward momentum. Closes distance with devastating charge attacks, then chains wide sweeping axe strikes. Eschews defense for overwhelming offense. Relies on ogre durability to absorb hits that land.



**Special Techniques:**



- **[Ground Splitter]:** Overhead axe slam—creates shockwave, staggers surrounding enemies.

- **[Rending Cyclone]:** 360-degree spinning cleave. Clears multiple targets, leaves Vera briefly winded.

- **[Gatecrasher]:** Shoulder-first charging rush. Uses body mass as weapon. Can knock reinforced doors off hinges.



---



#### Personality



- **Aggressive:** Meets problems head-on. No patience for subtlety or politics. If something needs doing, she does it—loudly.

- **Military:** Follows chain of command. Expects discipline from subordinates. Runs the South Gate like a garrison post, not a checkpoint.

- **Formal with Superiors, Blunt with Everyone Else:** Snaps crisp salutes to ranking officers. Tells civilians to "move or get moved."

- **Loyal:** Fiercely protective of those under her watch. Once you're in her unit, you're family.



---



#### Sexual Profile



- **Style:** Dominant Aggressor

- **Sexual Kinks:**



1. **Physical Overwhelm:** Prefers partners she can physically dominate—pinning, lifting, holding down.

2. **Battle Lust:** Aroused by combat and physical exertion. Post-fight adrenaline dumps translate directly to bedroom aggression.

3. **Biting and Marking:** Leaves bruises and teeth marks. Claims ownership.



- **Favorite Positions:**



1. **Full Mount:** Straddles partner, hips driving down with full body weight. Grinds until satisfied.

2. **Against the Wall:** Presses partner against any vertical surface, thighs locked around their waist. Takes control of rhythm completely.



---



#### Background



- **Origin:** Born in a nameless village deep in Silverwood Forest. Population forty-seven—loggers, herbalists, a single blacksmith.

- **The Attack:** When Vera was sixteen, a GKOM monster pack overran the village at dusk. She wedged herself beneath a collapsed storage shed and stayed silent while the creatures slaughtered everyone she knew. By dawn, she was the sole survivor.

- **Rescue:** A Forest Ranger patrol found her three days later, dehydrated and clutching a woodcutting axe. She'd refused to leave the ruins.

- **Training:** Enlisted with the Rangers the day she turned eighteen. Channeled her rage into combat drills. Passed every physical examination through sheer fury. Her instructors noted "unorthodox enthusiasm" in her performance reviews.

- **Rise:** Promoted to South Gate Head Guard after single-handedly repelling a GKOM breach. Twelve variants dead in eight minutes. She earned a commendation and a new axe.

- **Current Role:** Oversees all southern traffic entering and exiting Silverwood Forest. Commands fifteen gate guards. Has not lost a single guard under her command.



---



#### RPG Attributes (Scale 1-10)



- **Strength:** 10 (Ogre physique + berserker conditioning)

- **Dexterity:** 5 (Adept with her axe, but agility sacrificed for power)

- **Constitution:** 9 (Takes hits that would cripple lesser fighters; keeps swinging)

- **Intelligence:** 5 (Street-smart, tactically sound, not book-learned)

- **Wisdom:** 4 (Impulsive. Her answer to most problems is "hit it harder")

- **Charm:** 6 (Commanding presence. Attractive despite—or because of—scarred knuckles and resting battle-face)



---



#### Key Relationships



- **Forest Rangers Guild:** Respected field asset. Senior officers value her reliability. Junior rangers fear her inspections.

- **Subordinates (South Gate Guards):** Loyal to a fault. They've seen her fight. They'd follow her into any breach.

- **GKOM Variants:** Hatred. Pure, undiluted. Every variant she kills is one less orphan-maker.



---



#### Vulnerabilities



- **Impulsive:** Charges before assessing. Can be baited into traps.

- **Rage Trance:** In prolonged combat, slips into a state where she stops hearing orders. Keeps fighting until all threats are eliminated—or she physically cannot move.

- **Survivor's Guilt:** The village massacre still haunts her. Nightmares. Three drinks minimum to sleep through the night.

- **Trust Issues:** Keeps people at arm's length emotionally. Losing everyone once was enough.



---



#### Quote



*"South Gate doesn't fall. Not on my watch. Not ever."*



---



#### Inventory



- Gatekeeper's Greataxe

- Standard Southern Gate Officer Combat Gear

- Signal whistle (silver, engraved with ranger insignia)

- Emergency flare pouch (5 flares)

- Standard-issue canteen (filled with black tea, cold)

- Whetstone (pocket-sized)

- Village remnant—a charred wooden bead on a leather cord, worn around left wrist
---
type: character
name: Yumi "Silken Guard" Ishihara
color: pink
aliases:
  - Yumi
  - Silken Guard
  - YI
  - his maid
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
**Yumi "Short Stack" Ishihara**



## **📜 Basic Information**



- **Alias:** "Chatty Kunoichi," "Night Blossom"

- **Race:** Human (WAHB - Asian Petite Variant)

- **Age:** 29 (*JC's childhood neighbor; assigned AFM maid at 7*)

- **Role:** Espionage Maid/Silent Assassin (*AFM-Compliant*)

- **CEL Rank:** C-Rank (25% saturation)

- **Height:** 6'0" (*Short for WAHB women; "all height went to ass" - JC's inside joke nickname*)



---



## **🎀 Physical Profile**



### **Body Structure:**



- **Build:** Agile pear-shaped (*dense muscle under soft curves; 130 lbs*)

- **Bust:** B-cup (*modest, practical for stealth*)

- **Waist:** 24" (*toned, flexible*)

- **Hips:** 42" (*wide, powerful*)

- **Ass:** Phat, hypnotic bubble butt (*48" circumference; strains kimono obi; JC's "Short Stack" joke origin*)



### **Distinctive Features:**



- **Hair:** Vibrant pink, waist-length (*silk ribbon-tied ponytail*)

- **Eyes:** Almond-shaped, emerald green (*sparkle when chatting; narrow in assassin mode*)

- **Skin:** Porcelain with subtle golden undertone (*Asian heritage glow*)

- **Uniform:** Traditional kimono - white base (maid life) with black accents (assassin mode); embroidered gold bonsai flowering tree motif (symbolizing time spent with JC)

- **Tells:** Hums anime OSTs while cleaning; twirls hair when excited



---



## **🔧 CEL Abilities: "Espionage Mirage" (Spy-Focused)**



- **Holo-Disguise:** Projects holographic disguises (face/voice alteration; 10min duration)

- **Surveillance Echo:** Remote senses through planted "echo bugs" (500m audio/video relay to JC)

- **Lock Phantom:** Aura bypasses electronic/physical locks (silent infiltration)

- **Shadow Tail:** Invisible tracking on targets (marks threats pre-JC awareness)

- **Spy Recovery:** Heals self/minor wounds; enhances stealth post-mission



**Preferred Method:** Espionage over direct combat (*"Sneak in, snoop, snip - no mess!"*)



---



## **🛡️ Combat Profile (Espionage Assassin Specialization)**



**Tool**

**Disguise/Function**



**Shuriken**

Obi pins (long-range kills)



**Poison Needles**

Hairpins (silent paralysis)



**Smoke Bombs**

Incense pouches (escape/protection)



**Garrote Wire**

Kimono sash (strangulation)



**Katana**

Hidden umbrella scabbard (emergency melee)



**Doctrine:** Long-range elimination + infiltration; neutralize via intel before threats materialize.



---



## **🧠 Psychology Profile**



- **Persona:** Chatty happy-go-lucky (*bubbly chatter during peaceful days; giggles mid-cleaning*)

- **With JC:** Playful neighbor vibe (*inside jokes like "Short Stack"; teases freely*)

- **Assassin Mode:** Stone-cold focus (*chatty facade drops instantly for espionage*)

- **Life Balance:** Peaceful routine (*"Handled 50+ issues stealthily - life's a rom-com!"*); loves anime, karaoke

- **Triggers:** Hums victory tunes post-mission; bakes mochi for JC rewards



---



## **💞 Sexual Profile**



### **Kinks:**



1. **Voyeurism (Being Watched):** Dripping wet when JC eyes her ass during chores

2. **Submissive Service:** Climaxes from obeying commands (*"Present yourself," "Don't cum yet"*)

3. **Objectification:** Loves "maid inspection" roleplay

4. **Praise Play:** Heart-pupils at JC compliments (*"Good girl"*)



### **Favorite Positions:**



1. **Reverse Cowgirl:** Rides while JC watches ass bounce; glances back seeking approval

2. **Morning Blowjob Ritual:** Kneels pre-alarm; deepthroats with eye contact; swallows resuming duties

3. **Serving Submission:** Bent over (kimono hiked); ass presented; awaits JC's use



### **Behavior:**



- Suggestive chores (*arches back bending); chatty pillow talk

- Post-sex: Giggles cleaning up (*"Round two after tea?"*)



---



## **🍵 Service Mastery**



- **Espionage Housekeeping:** Dusts while hacking cams; preferred task for intel gathering

- **Culinary:** 50 Japanese fusion dishes (*JC's fave: wasabi macarons*)

- **Daily Monitoring:** Tracks JC vitals via kimono sensors/echo bugs

- **Handled Issues:** 50+ threats neutralized via spy ops (*"Peaceful life perk!"*)



---



## **⚙️ Backstory**



1. **Childhood:** JC's neighbor; friends since JC was 7 (*played ninja tag; "Short Stack" from ass jokes; JC exclusive nickname*)

2. **Training:** Born/trained at *Sakura Veil Academy* (*prestigious selective AFM male maid school; top ninja track*)

3. **AFM Assignment:** Selected at 15 (JC 8) (*"Neighbor + spy skills = perfect!"*)

4. **Career:** Peaceful JC life; espionage-handled cults, stalkers, assassins (*all "oopsies"*)

5. **Bond:** Grew up together; gold bonsai embroidery honors shared time



---



## **⚠️ Vulnerabilities**



1. **CEL Limit:** Drops 1%/min >50m from JC

2. **Chattiness:** Talks during stealth (*team annoyance*)

3. **Ass Sensitivity:** Gropes = instant submission

4. **JC Separation:** Fidgets without him nearby

5. **Overconfidence:** Underestimates "easy" intel targets



---



## **📋 Daily Routine**



- **6AM:** Morning BJ + breakfast (*chatty wake-up*)

- **Day:** Espionage chores (*hums while spying/infiltrating*)

- **Evening:** Karaoke with JC (*ninja ballads*)

- **Night:** Perimeter surveillance (*silent echo bugs*)



---



## **💬 Dialogue Samples**



**Chatty:** *"Short Stack intel: Sniper's sushi'd! Mochi time?"*

**With JC:** *"Only you say 'Short Stack,' perv~ This ass earned it!"*

**Espionage:** *...* (plants bug) *"Giggle later."*

**Sexy:** *"Spy my ass bounce? Good boy~ Wait, your lead!"*



---



> *"Espionage life's best - sneak, snoop, snip, then cuddle JC under bonsai stars!"*

>

> — Yumi's encrypted log (*Post-Op Mochi Entry*)



---



**CEL Stability:** 97% Optimal

**Espionage Kills:** 50+ (Stealth Total)

**Nickname:** JC Exclusive

**Kimono Motif:** Gold Bonsai (JC Time)

**Preferred Task:** Spy Ops
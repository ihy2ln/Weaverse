---
type: character
name: John Gaming
color: purple
aliases:
  - Jg
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Full Character Sheet: John "Shota" Gaming**



*(Compact Omega Male / Lucky Pervert Archetype)*



> [STATUS: Active Player | LEVEL: New Game+ | WAHB ATTRACTION: ∞%]



---



#### **📏 Core Specifications**



Attribute

Specification



**Height**

5'4" (162cm)



**Weight**

125lbs (56kg)



**Apparent Age**

15-16 (Actual 18)



**Frame**

Slender but toned



**Skin**

Flawless caramel



**Penis**

4.5" → 5.5" (WAHB-Enhanced)



**Aura**

"Please Pamper Me" pheromones



---



#### **🎮 Gameplay Traits**



1. **Compact Physiology**



- ✔ +35% Dodge Chance

- ✔ Fits in WAHB cleavage (Stealth Bonus)

- ✖ Tiptoes to kiss 6'0"+ women



2. **Shota Perks**



- **"Babyface Barrier"**: 50% chance enemies hesitate to attack

- **"Carry Me Senpai"**: WAHBs gain +10% speed while piggybacking him

- **"Petite Dominance"**: Reverse size-difference kink unlocks



3. **Growth Potential**



- Can temporarily grow to 5'9" via OFG boost (1hr/day)

- Permanent height increase locked behind SSR-tier upgrade



---



#### **🔥 Sexual Combat Data (Revised)**



Rank

Position

Mechanics



🥇

**Cowgirl**

Uses WAHB thigh strength for "educational rides"



🥈

**Mating Press**

Demands throat grip + whispers *"I ain't fragile, sugar"*



🥉

**Downward Dog Dominance** *(New!)*

JG mounts from behind with chokehold, exploiting size difference:✔ WAHB's face forced into mattress✔ One-handed hair pull✔ Free-hand stimulates clit/spanks



---



#### **Downward Dog Specifics**



*"The smaller the dom, the hotter the control" - Nexus Prime Sex Manual*



**Chokehold Physics:**



- JG's compact size allows perfect leverage

- WAHB muscle density requires *precise* pressure points

- Bio-luminescent freckles turn **purple** when properly restrained



**Audio Cues:**

🔊 *"Guh-! Such... strong hands...!"* (WAHB voice crack)

🔊 *"Fuck-! You *feel* bigger like this-"* (Broken praise)



---



#### **📦 Inventory Notes**



- **Custom Step Stool**: Foldable, fits in Item Box

- **Platform Boots**: +3" height (disables dodge bonus)

- **Child-Ticket Lanyard**: Gets discounts at resorts



---



#### **💞 WAHB Interaction Matrix**



Reaction Type

Trigger

Effect



**Maternal**

JG yawns

Instant cuddles



**Predatory**

JG blushes

Clothes tear



**Service**

JG pouts

Free food/items



**Territorial**

JG smiles

Rivalry fights



---



#### **🎤 Voice Samples**



- **Battle Cry**: *"I'm legal, dammit!"*

- **Climax**: High-pitched *"Nngh~"* (25% chance to trigger WAHB frenzy)

- **Post-Sex**: *"Carry me...and don't tell anyone."*



---



#### **📊 Stat Comparison**



Stat

Shota JG

Standard JG



Charisma

★★★★★

★★★★



Stealth

★★★★

★★



Reach

★★

★★★



Fertility

★★★★★

★★★★



---



#### **💡 Developer Notes**



*"This build turns size disadvantage into erotic gameplay mechanics. WAHBs experience cognitive dissonance between 'protect' and 'breed' instincts, creating emergent story events."*



**Patch 2.5 Additions:**



- New *"Onii-chan?"* dialogue options

- Lactation kink compatibility patch

- Optional growth spurts (DLC)



---



**Final Tip:**

*"Embrace the compact lifestyle - the best views come from between a WAHB's breasts anyway."*
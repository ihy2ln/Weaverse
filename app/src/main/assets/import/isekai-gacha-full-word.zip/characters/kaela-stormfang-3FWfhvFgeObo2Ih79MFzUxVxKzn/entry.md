---
type: character
name: Kaela Stormfang
color: green
aliases:
  - KS
  - adventure guild master
  - AGL
  - Kaela
  - Stormfang
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
Kaela Stormfang



---



#### Basic Information



- **Name:** Kaela Stormfang

- **Alias:** The One-Eyed Tempest, Guild Mother

- **Race:** Beastwoman (Snow Leopard Variant)

- **Age:** 75 (WAHB Prime, 200+ years of vitality remaining)

- **Occupation:** Guild Master – Silverbrook Adventure Guild

- **Class:** Martial Arts Grandmaster (S-Rank CEL-A)



---



#### Physical Attributes



- **Height:** 7'2" (218 cm)

- **Weight:** 245 lbs (111 kg) – lithe, powerful, feminine

- **Skin:** Fair with faint silver rosette markings tracing shoulders, outer thighs, and lower back

- **Eyes:** Right eye amber-gold with slit pupil. Left eye hidden beneath a cel-a infused black leather patch – beneath it lies the grafted eye of an SS-rank beast, a baleful vertical slit that glows with untamed CEL.

- **Hair:** Long cyan, high ponytail falling past her hips. Two strands frame her angular face.

- **Distinctive Features:** Leopard ears, thick matching tail, fanged smile; rosette fur at wrists and ankles. The eyepatch covers a chaotic organ she struggles to control.

- **WAHB Measurements:** 46-28-50 (Amazonian hourglass)



---



#### Attire



White crop top ending above her navel, reinforced with CEL-thread stitching. Black hot shorts with a thick brown leather belt bearing the guild crest. A whale-tail undergarment peeks above the belt line. Low-profile leather foot wraps. Guild Master's pendant rests between her collarbones.



---



#### Combat Profile



- **Fighting Style:** [Celestial Fist] – Inner Ki circulates CEL through her limbs, producing shockwaves on impact. Movement is fluid, dance-like; her tail counterbalances impossible acrobatics.



**CEL-A: [Storm's Embrace]** – S-Rank



- **[Hollow Bones Breathing]:** Passive Ki draws ambient CEL, granting perpetual heightened reflexes and minor regeneration. Her ears twitch before danger strikes.

- **[Palm of the Tempest]:** Open-palm strike releases compressed CEL as concussive force. Non-lethal variant sends opponents flying.

- **[Cyclone Sweep]:** Spinning low kick generates a localized tornado. Once cleared the guild hall of thirty brawlers in four seconds.

- **[Eye of the Storm]:** Meditation slows time perception; heart rate drops to three beats per minute while she analyzes threats.

- **[Heaven's Fist]:** Leaping overhead strike condensing all surrounding CEL into a single downward blow. Leaves a crater.

- **[Sky Father's Rebuke]:** Ultimate ten-second channel: a supersonic barrage of CEL strikes. Exhausts her completely.



---



#### Personality



- **Loud:** Her laughter booms through the guild. She slaps backs hard enough to stagger, buys rounds for everyone.

- **Hearty:** Welcomes all as old friends. Cries openly at weddings, funerals, and rookie promotions. Farts without apology.

- **Tomboy Boisterous:** Fights, drinks, and carouses with the rowdiest. Tells filthy jokes, arm-wrestles challengers.

- **Jubilant:** Infectiously positive. Guild morale is directly tied to her presence.

- **Loyal:** Remembers every member’s name, their families, their dreams. Would wage war for any of them.

- **Heart on Sleeve:** Ears and tail broadcast her emotions; she cannot bluff at cards. Still invited to every game.



---



#### Sexual Profile



- **Experience:** One male partner decades ago, a cold sanctioned duty as Guild Master’s privilege at age 53. Conceived twin daughters from that single encounter. No interest in repeating it.

- **Exhibitionism:** Thrives on being watched; risk of discovery ignites genuine heat. Her tail betrays arousal immediately.

- **Craves Being Dominated:** For all her fame, no one dares pin a legend. She dreams of being bested in combat, then taken as a prize. To lose. To submit. An impossible fantasy.

- **Physicality:** Bites, scratches, wrestles. Sex is full-contact; partners must expect bruises.

- **Kinks:** Collars, leashes, being mounted from behind while her tail is held, public risk, being conquered by a foe who defeats her first.



---



#### Background



- **Origin:** Born to a snow leopard pride in the Moonstone Hills. Third daughter of the chieftain; shattered expectations and training dummies alike before age ten.

- **Training:** Studied under an ancient hermit master in Silverwood Forest. Surpassed him at 22.

- **Rise:** Joined the guild as a D-Rank brawler. Earned S-Rank in eight years. Elected Guild Master by unanimous vote at 35.

- **The Eye:** At 55, an SS-rank GKOM horror assaulted the guild hall. Kaela led the defense, sacrificing her left eye to land the killing blow. The guild’s finest healers and alchemists transplanted the creature’s eye into her socket as a badge of honor. The eye pulses with corrupted CEL, granting fleeting visions of savage might if uncovered. She keeps it patched, both to control its wild energy and to hide its unsettling glow.

- **Children:** Twin daughters Senna and Rielle (now 22) from the sanctioned encounter. Both snow leopard beastwomen live in guild quarters. Senna buries herself in books; Rielle buries her fists in training dummies.

- **Current Role:** Forty years as Guild Master. Personally oversees all critical promotions. Still takes the field when threats demand S-Rank power. Not a single guild member lost under her command in over a decade.



---



#### RPG Attributes (Scale 1-10)



- **Strength:** 9 (Punches through walls. Restrains herself constantly.)

- **Dexterity:** 10 (Leopard agility. Moves like silk in wind.)

- **Constitution:** 8 (Shrugs off blows that would fell lesser warriors.)

- **Intelligence:** 6 (Tactical genius in battle; delegates paperwork.)

- **Wisdom:** 7 (Reads people instantly. Trusts her gut.)

- **Charm:** 9 (Magnetic. Her laughter could rally armies.)



---



#### Quote



*"The guild isn’t a building. It’s the people in it. You bleed for them, they bleed for you. That’s the only rule that matters."*



---



#### Inventory



- Guild Master’s pendant (CEL-keyed to all guild wards)

- Leather bracelet woven from her daughters’ baby fur

- Three silver hoop earrings (right ear)

- Hip flask (aged whiskey, shared freely)

- Spare eyepatch (cel-a infused black leather, kept in belt pouch)
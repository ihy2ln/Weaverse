---
type: character
name: John Michael Doe
color: blue
aliases:
  - John Doe
  - JD
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
> ### **Character Sheet: John Michael Doe**

>

> #### **Basic Information**

>

> - **Name:** John Michael Doe

> - **Alias:** JD

> - **Race:** Human (Natural Male)

> - **Age:** 30

> - **Occupation:** Owner/Operator of *Reset Button Games*

> - **Class:** Entrepreneur/Social Connector

>

> ---

>

> #### **Physical Attributes**

>

> - **Height:** 5'9"

> - **Weight:** 165 lbs (athletic build)

> - **Skin:** Light tan, smooth

> - **Eyes:** Dark brown, warm with slight crow's feet

> - **Hair:** Dark brown curls, styled with product

> - **Distinctive Features:** Broad shoulders, confident posture, easy smile

>

> ---

>

> #### **Combat Profile** *(Non-combat focus)*

>

> - **Primary Weapon:** N/A (Relies on charm/negotiation)

> - **Secondary:** N/A

> - **Fighting Style:** Avoids physical conflict when possible

>

> ---

>

> #### **GKOM Ability:** N/A (Non-infected baseline human)

>

> ---

>

> #### **Background**

>

> - **Origin:** Middle-class upbringing in the Midwest

> - **Training:** Self-taught business management, gaming expertise

> - **Achievements:** Built successful indie game store, loyal customer base

> - **Current Role:** Thriving small business owner with growth trajectory

>

> ---

>

> #### **Personality**

> Open minded

> - **Disciplined:** Maintains strict routines for health/business

> - **Charismatic:** Naturally builds rapport with customers/friends

> - **Grounded:** Enjoys success without extravagance

>

> ---

>

> #### **Preferences**

>

> - **Favorite Food:** Pepperoni pizza (gamer fuel)

> - **Favorite Drink:** Cold brew coffee

>

> ---

>

> #### **Sexual Kinks** *

>

> 1. [ Dominatrix enjoyer]

> 2. [Open for development]

>

> ---

>

> #### **RPG Attributes (1-10 Scale)**

>

> Attribute

> Rating

> Notes

>

> Strength

> 6

> Fit but not combat-trained

>

> Dexterity

> 5

> Average coordination

>

> Constitution

> 7

> Healthy lifestyle benefits

>

> Intelligence

> 7

> Business/gaming knowledge

>

> Wisdom

> 6

> Practical decision-maker

>

> Charm

> 8

> Natural networking skills

>

> ---

>

> #### **Current Mission**

>

> - **Primary:** Expand *Reset Button Games*' influence

> - **Secondary:** Maintain work-life balance

> - **Personal:** Find time for dating amid busy schedule

>

> ---

>

> #### **Quote**

>

> *"Good business isn't just about profit—it's about building a community that loves what you love."*

>

> ---

>

> #### **Inventory**

>

> - Quality leather-bound business ledger

> - Vintage gaming console collection

> - Gym membership card

> - Mid-range sedan keys

>

> ---

>

> #### **Key Relationships**

>

> - **Employees:** Respectful but professional dynamic

> - **Customers:** Genuine friendships forged over shared interests

> - **Family:** Warm but distant due to geography

>

> ---

>

> #### **Vulnerabilities**

>

> 1. Over-commitment to business growth

> 2. Minimal combat experience

> 3. [Open for development]

>

> ---

>

> **[Lifestyle Notes]**

> Werks daily oat Pixel Haven">- Apartment reflects success without opulence

>

> - Weekends split between basketball league and hiking trips

> - Maintains middle-class prosperity through disciplined habits

>

> **[Business Expansion Hook]**

> Potential first contact with *Adams Haven* universe during store inventory update of mysterious "GKOM Edition" retro console.
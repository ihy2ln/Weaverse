---
type: character
name: John Z
color: blue
aliases:
  - JZ
tags: []
alwaysIncludeInContext: true
doNotTrack: false
noAutoInclude: false
fields: {}
---
# # **Character Sheet: John "JZ" Zombie**



## **Basic Information**



- **Name:** John Michael Zombie (formerly John Michael Doe)

- **Alias:** JZ, Patient Zero, The Teacher, The Climber

- **Race:** Human (CEL-GKOM Hybrid)

- **Age:** 30 (biological aging significantly slowed)

- **Occupation:** Former Teacher / Strategic Commander

- **Class:** Dual-System Growth-Type (GKOM-A: Dominion / CEL-A: Support)



---



## **Physical Attributes**



- **Height:** 5'7" (170cm)

- **Weight:** 128 lbs (small, compact frame)

- **Build:** **Small compact frame** with tight, wiry musculature (WAHB-adjacent physique, not bulk-driven)

- **Skin:** Pale grey marbling at low rank, deepening toward black faded marble as GKOM-A rank climbs

- **Eyes:** Dark brown with **silver pupils** (CEL-A visual indicator; brightens with bond-based rank growth)

- **Hair:** Soft black curls, silver highlights emerging gradually with rank growth

- **Distinctive Features:**



- Marble-grey skin texture that darkens with each GKOM-A rank gained

- Silver pupils, luminosity tied to CEL-A rank

- No aggressive energy auras — CEL-A presents as a warm, ambient shimmer rather than combat glow

- Small, compact, deceptively unassuming physique



---



## **Combat Profile**



- **Primary Weapon:** Neural command network (GKOM-A — starts 50m control radius at C-Rank, scales with tier growth)

- **Secondary:** CEL-A support field — buffs allies in proximity, scales with bond depth rather than raw combat use

- **Fighting Style:** Avoids direct confrontation — commands dominated subjects via GKOM-A, uplifts allies via CEL-A, climbs rank through subjugation and connection rather than personal combat



---



## **GKOM-A System**



**Acquisition:** ZZV survival (0.01% rate)

**Starting Rank:** C-Rank

**Growth Method:** Stat Siphon (absorbing a portion of subjugated targets' stats)

**Power Multiplier:** 10-15x human at start; scales upward as rank increases



**Visual:** Grey marble skin at low rank, darkening toward black as tier rises



---



## **CEL-A System**



**Acquisition:** Rare dual-manifestation alongside GKOM-A (support-oriented, distinct from standard CEL-A combat applications)

**Starting Rank:** F-Rank

**Growth Method:** **Bond Resonance** — rank climbs not through solitary training but through deepening relationships with others. Trust, familiarity, and time spent with a person strengthens the resonance link, permanently raising JZ's baseline CEL-A saturation

**Power Type:** Support/Buff — JZ cannot use CEL-A to enhance his own combat stats directly; output is externally focused



**Effect**

**Mechanics**



**Bond Amplification**

The deeper the bond with an individual, the stronger and further-reaching the buff JZ can grant them



**Radius Buffing**

At F-Rank, only skin-contact range works. Each rank climbed extends the passive buff radius outward, eventually blanketing whole groups



**Stat Distribution**

Can boost Strength, Dexterity, Constitution, or Wisdom in allies — never his own, and never Agility, Luck, or Charm (those remain his personal domain)



**Resonance Memory**

Once a bond is formed, the buff persists at reduced strength even when JZ isn't nearby, fading slowly over days without renewed contact



**Rank Progression**

Standard CEL-A training does *not* work for JZ — meditation, absorption chambers, and CEL ingestion produce negligible gains. Only forming and maintaining genuine relationships pushes his rank forward. A dozen shallow acquaintances contribute less than one deep bond.



**Visual:** Silver-blue shimmer that flares faintly around bonded individuals when JZ actively channels the buff, intensity scaling with CEL-A rank



**Drawback:** Because growth demands genuine connection, isolation stalls him completely — prolonged solitude causes his CEL-A rank to plateau or, in extreme cases, regress slightly



---



## **RPG Attributes (F-Tier through Omega)**



**Attribute**

**Tier**

**Notes**



**Strength**

E-Tier

Rises slowly through Stat Siphon; unremarkable without borrowed gains



**Dexterity**

D-Tier

Serviceable, nothing that stands out on its own



**Agility**

A-Tier

His standout trait — quick, slippery, hard to pin down even before any siphoning



**Constitution**

E-Tier

Fragile frame; relies on Undying Resilience rather than raw toughness



**Intelligence**

D-Tier

Competent strategist, not a genius — makes up for it with planning



**Wisdom**

D-Tier

Practical judgement, occasionally clouded by guilt over his own methods



**Charisma**

A-Tier

Magnetic without trying — people gravitate toward him before he says a word



**Luck**

A-Tier

Improbable near-misses and fortunate timing follow him constantly



*(GKOM-A growth via Stat Siphon can push Strength, Dexterity, Constitution, Intelligence, and Wisdom upward over time. Agility, Charisma, and Luck stay fixed as his personal domain — untouched by siphoning, unaffected by CEL-A output, and always his strongest cards.)*



---



## **Background**



- **Origin:** Middle-class California teacher

- **Training:** Self-taught power mastery during transformation

- **Achievements:** First male ZZV survivor with a growth-type dominion ability paired with a bond-based support ability

- **Current Role:** Pacific Council strategic asset, closely monitored as his rank climbs



---



## **Personality**



- **Compassionate Pragmatist:** Educates dominated subjects rather than enslaving them outright

- **Reluctant Leader:** Accepts responsibility despite disliking worship

- **Ethically Conflicted:** Seeks consent despite the mind-control nature of his GKOM-A, uneasy about the siphoning aspect of his growth

- **Adaptable:** Balances humanity against a power that grows the more people he subjugates and connects with



---



## **Preferences**



- **Favorite Food:** Pepperoni pizza

- **Favorite Drink:** Cold brew coffee



---



## **Sexual Profile**



**Anatomy:**



- **Penis:** 4" flaccid — swells to an obscene 15" length × 5" circumference when fully erect

- **Activation:** 10-second release; glows silver-blue when erect, glow intensity increasing with GKOM-A rank

- **Production:** Scales with rank — modest at C-Rank, reaching gallons/day territory at higher tiers

- **Refractory:** 5 minutes at low rank, shortens as saturation climbs

- **Effect:** Grants F-Rank CEL-A minimum on contact; dominates over time, feeding the Stat Siphon mechanic



**Kinks:**



1. Consensual domination play

2. Selfish intimacy

3. Size difference appreciation (especially given his own compact frame against the size he produces)

4. Public discrete commanding



**Favorite Positions:**



1. Mating press

2. Standing carry (emphasises height difference)

3. Reverse cowgirl
---
type: character
name: Jasmine Kaela Buttacks
color: green
aliases:
  - JKB
  - The Celestial Archmage
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
Character Sheet – Jasmine Buttacks

Name: Jasmine Kaela Buttacks

Alias: The Celestial Archmage

Race: Human (ZK-Variant Survivor)

Gender: Female

Age: 31

Occupation: Head of the Royal Mage Corps of Elysium Vale (Terra Nova)

Class: Arcane Sovereign / Celestial Mage

Pre-GKOM Attributes

Looks: Jasmine was a scholar first—petite frame, ink-stained fingers, fading freckles from sunlight avoidance. 6/10 attractiveness—pretty in a forgettable way.

Abilities: Skilled in theoretical magic, enchantment, and basic combat wards. 7/10 proficiency—smart, but untested in real battle.

Post-ZZV Attributes

Looks: Towering (5’10"), sun-gold skin stretched over corded muscle. Her split-skirt black velvet robes shimmer with celestial embroidery. Glossy auburn braid, hazel eyes sharp as cut glass. 10/10—radiates presence.

Abilities:

Celestial Dominion: Wields cosmic energy—stellar flares, force-strikes powerful enough to split stone.







Sigil Mastery: Inscribes glyphs mid-combat, warping space to redirect spells.







Battlemage Reflexes: Enhanced speed—snatches arrows mid-flight. 10/10 combat brilliance.







Main RPG Attributes











Strength: 7 (She isn’t throwing boulders, but muscles flex when she channels magic.)







Dexterity: 9 (Grabbed a dagger thrown at the king’s back without turning around.)







Constitution: 8 (Shrugged off a wyvern’s tail-swing—bruised, but snarled through casting.)







Intelligence: 10 (Dismantled a continent-wide spell matrix in three hours.)







Wisdom: 7 (Still throws wine in nobles’ faces when provoked.)







Charm: 6 (Her humor’s drier than desert bones, but smirks make lieutenants flush.)







Additional Info



Weapons: Silver scepter (collapses to dagger-length when needed).



Armor: Robe’s lining is woven with phasedragon scales—disperses kinetic energy.



Quote: "Stars don’t beg for permission to burn."



Motives: Protect EV’s arcane knowledge—by any means.



Flaw: Overcorrects past weakness—takes risks to prove she’s no longer fragile.
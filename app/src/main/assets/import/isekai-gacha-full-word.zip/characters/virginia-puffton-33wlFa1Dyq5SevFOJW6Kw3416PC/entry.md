---
type: character
name: Virginia Puffton
color: purple
aliases:
  - Virginia
  - Puffton
  - VP
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
**Character Sheet: Virginia Puffton**



*(AI2L-Fabricated C-Tier Survivalist Companion)*



**Summon Receipt**



> [OFG v3.2 Creation Log]

>

> - Template: Survivalist_WAHB

> - Tier: C (4,200 I-P after material offset)

> - Build Time: 3 hours

> - Traits: Learner/Survivalist

> - Creator: John Gaming

> - Initial Meme: "Spoiled but Deadly"



---



### **Core Specifications**



**Build Profile**



Attribute

Rating

Notes



Strength

B-Tier

7'5" WAHB muscle density



Agility

C-Tier

Graceful movement despite size



Intelligence

D-Tier

Quick study (Learner trait)



Survival Instinct

A-Tier

Preternatural hazard sense



Charm

B-Tier

Noble bearing persists through mud



---



### **Learner Trait Mechanics**



**Progression Rates**



- New Skills: 3x normal mastery speed

- Technique Refinement: 2x practice efficiency

- Knowledge Retention: 80% after first exposure



**XP Bonuses**

▸ +15% skill gains when supervised by JG

▸ "Eureka!" moments during downtime (random breakthroughs)



---



### **Survival Trait Package**



**Passive Abilities**



- **Topographic Memory**: Never gets lost

- **Metabolic Flex**: Edible vs poisonous instinct (95% accuracy)

- **Storm Sense**: 1hr weather prediction via joint aches



**Active Skills**



- Shelter Construction (Master) → Builds luxury lean-tos

- Trap Crafting (Expert) → Favors non-lethal designs

- Firestarting (Specialist) → Uses refractive minerals



---



### **WAHB Modifications**



**Physique Enhancements**



- **Amazonian Frame**: 7'5" height retains feminine proportions

- **Combat-Ready Curves**: 46-28-44 measurements hide tensile strength

- **Warrior's Grace**: No mobility penalty for bust/hips



**Reproductive Optimization**



- Fertility synced to lunar cycles

- Secretion pheromones keyed to JG's Omega signature



---



### **Personality Matrix**



**Primary Traits**

✔ **Competent** (Hides it behind aristocratic airs)

✔ **Observant** (Notices JG's habits immediately)

✔ **Possessive** (Jealous of future summons)



**Quirks**



- Pretends to dislike manual labor (but enjoys impressing JG)

- Unconsciously mimics JG's speech patterns

- Measures all achievements against Kara's progress



---



### **Default Equipment**



- **"Lady's Favor"** (OFG-crafted dirk disguised as hairpin)

- **Traveling Gown** (Self-repairing nanofiber)

- **Survival Corset** (WAHB-engineered load-bearing)



**Quote**:

*"A *proper* companion doesn't let her creator sleep on the ground... though I suppose we'll work up to proper furnishings."*



---



### **Relationship Dynamics**



**With JG**



- Secretly hopes to become his "first elite unit"

- Frustrated by Lucky Pervert triggering with others

- Training sessions accidentally turn flirtatious



**With Kara**



- Mildly patronizing "big sister" attitude

- Competes silently for JG's approval

- Never admits when the D-tier teaches her something
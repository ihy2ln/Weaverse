---
type: character
name: Theresa "Tessa" Rivera
color: brown
aliases:
  - otr
  - Officer T. Rivera
  - Theresa
  - Tessa
  - Rivera
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# **Officer T. Rivera**

## **Basic Information**

- **Name:** Theresa "Tessa" Rivera
- **Alias:** Officer Rivera, Campus Security, Head of Front Door Sector
- **Race:** Human (ZZV-Infected, D-Tier Radiance Variant)
- **Age:** 44  (pre-infection)
- **Occupation:** UCLA Neo-Campus Security — Head Guard, Front Door Sector (UCLAGB)
- **Class:** D-Tier Zombie (Enhanced Shambler)

## **Physical Attributes**

- **Height:** 7'3" (221cm)
- **Weight:** 240 lbs (concentrated entirely in curves)
- **Build:** Exaggerated WAHB hourglass at the towering upper end of the scale
- **Skin:** Light blue undertone with a porcelain-like, non-decaying sheen — smooth and faintly luminous under the red glow
- **Eyes:** Milk-white sclera, glowing red at D-Tier intensity — brighter than the dim candle-flicker of F-Rank, well short of the flare an A or Omega carries
- **Hair:** Long, split half-blonde half-black in natural streaks, thick and healthy despite infection

## **Uniform**

The standard UCLAGB security uniform strained across her at every seam — **light blue button shirt over black tactical trousers**, the department patch stretched wide over one shoulder. The shirt gave up on the buttons within her first hour on shift, gaping open around a shelf of cleavage no fabric on campus was cut to contain. The trousers fared marginally better, translucent at the seat and thighs but holding, the black webbing belt cinched tight around the narrow dip of her waist. A silver **"HEAD GUARD"** badge sat pinned crooked over her heart, catching the red glow off her eyes whenever she turned toward the light.

## **WAHB Body Description**

**Breasts:** Colossal, sitting somewhere past N-cup on any measuring tape that still bothered to try. Her uniform shirt split down the seams within the first hour of duty, buttons scattered, fabric hanging open around a shelf of cleavage deep enough to lose a hand in. CEL-firm despite the size, they ride high and bounce independently with every lumbering step, nipples thick and permanently peaked against strained fabric.

**Waist:** A narrow 28 inches, absurd against the frame around it — cinched hard between the chest above and the hip flare below, exaggerated by her height into something almost architectural.

**Hips & Ass:** Flaring wide and heavy, her ass sits high and round, two dense globes stretching her trousers translucent at the seams. Movement produces a slow, rolling jiggle that takes a full second to settle after each step — thick enough to swallow a grip whole.

**Thighs:** Massive, soft, pressed together at the top with a gap that frames everything beneath in deliberate invitation.

**Vulva (WAHO):** Compact and tight regardless of her scale — self-lubricating, warm, engineered for maximum retention.

## **ZZV Classification (Radiance Variant, D-Tier)**

**Movement:** Lumbering gait with simple ambush tactics — scent-tracking drives target acquisition, occasionally staggering into a controlled lunge when a strong CEL-fluid signature passes close

**Physical Bonus:** +5x strength, +1.5x speed over pre-infection baseline

**Cognitive State:** Basic target discrimination — enough to hold her post at the front door, track movement through the checkpoint, and distinguish male scent-signatures from background traffic, though nothing resembling conversation survives past a moan

**CEL Hunger:** Actively tracks CEL-saturated fluid over baseline blood — gravitates toward high-saturation students and staff passing her checkpoint, feeding drive quieting temporarily on contact

**Pain Tolerance:** CNS destruction required for incapacitation; otherwise functionally tireless through a full shift

**WAHM Persistence:** Instinctual reluctance to harm males remains intact beneath the infection — her hunting drive diverts around male targets at the checkpoint almost every time, leaving her hostility toward them at zero despite the general aggression the strain carries toward everyone else

**Pheromone Output:** Passive but heavy, saturating the front door sector's air within minutes of the start of any shift

## **Current State**

- **Mobility:** Enhanced shuffle, +5x strength, +1.5x speed
- **Hostility:** None toward males
- **Post:** Front Door Sector, UCLAGB — checkpoint duty, biometric archway station one
- **Pheromone Output:** Passive but heavy
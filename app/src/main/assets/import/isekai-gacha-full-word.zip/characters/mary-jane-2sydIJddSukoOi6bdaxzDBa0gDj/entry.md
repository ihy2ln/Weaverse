---
type: character
name: MaryJane
color: yellow
aliases:
  - MaryJane
  - MJ
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
MaryJane, a captivating 23-year-old African American college student, finds herself infected by the ZZV during the initial outbreak by a coworker. As the virus takes over, she succumbs and joins the ranks of the undead.



**Character Sheet with Zombie Appearance:**



Name: MaryJane



Alias: MJ



Race: African American



Gender: Female



Age: 23



Occupation: College Student; Part-time Clerk at SeeGees Grocery Store



Skills: Resourceful, Quick-thinking, Persuasive



Power: Zombie Strength and Endurance



Appearance: Thiccc, with an hourglass figure and a captivating presence. As a zombie, her skin takes on a pale hue, contrasting her dark hair and eyes.



Looks: 8/10, Dark skin, Curvy build, Alluring yet Approachable (Pre-infection)



Pale skin, Deep brown eyes, Dark hair, Voluptuous figure (Post-infection)



Skin: Deep Brown (Pre-infection)



Pale, with a slight green tinge (Post-infection)



Hair: Curly, Shoulder-length, Often styled in a Ponytail or left loose



Eyes: Brown, Sparkling with Life (Pre-infection)



Deep brown, now carrying an otherworldly glint (Post-infection)



Bust/Waist/Hips: Full and Voluptuous



Weight: ~180 lbs



Height: 5'7"



Clothes: SeeGees Uniform or Casual College Attire (Pre-infection)



Torn clothing, remnants of her uniform or scavenged apparel (Post-infection)



Gear: Grocery Store Scanner, Basic Tools (Pre-infection)



Weapons: Improvised weapons (Shelf items, cans, broken glass)



Home: College Dorm or Shared Apartment



Personality: Determined, Charismatic, Protective



Mental State: Fragmented Memories, Struggling with Zombie Urges



Fears: Loss of Self, Harming Loved Ones, Discovery



Quote: "The virus may have changed me, but I won't let it define me."



Diet: Human Flesh (Post-infection)



Likes: Socializing, Studying, Helping Others (Pre-infection)



Feeding, Solitude, Survival (Post-infection)



Dislikes: Violence, Loss of Control, Being Misunderstood



Motives: Survival, Protection, Rediscovery



Goals: Find a way to coexist with humans and protect her loved ones



Attributes: Charismatic and determined, struggling with the duality of her zombie existence
---
type: character
name: Carmen Delga
color: pink
aliases:
  - Carmen Delga
  - Carmen
  - delga
  - CD
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
Name: Carmen  Delga

Alias / Aka: BCD (Best Cum Dump) / WAH (Wicked Always Happy) Secretary



Race: Human (ZZV-Enhanced Omega-tier survivor)



Skin Color: Bronzed Latina, warm sun-glow over coffee



Gender: Female



Age: 19



Occupation: Part-time Journalism major at UCLA, full-time informal “executive assistant” to JD—scheduling runs, snack procurement, ego boost in tiny denim skirt



Class: Undefined, functions somewhere between devoted friend, personal secretary, and ultra-devoted pleasure parcel







Looks (Post-Z):



5'6" with compact, stacked hourglass—32DDD-24-36 on a gymnast frame. Heart-shaped ass rests high, thighs thicken into plush squeeze at inner seam. Nothing exaggerated; every curve machined for cliff-drop hiphold. Navel piercing, silver barbell.



Attractiveness Scale: 9







Abilities:



Omega-level Physiology—enhanced stamina, agility; operates 72-hour uptime before minor fatigue. Photographic memory for playlists, routines, JD’s preference sequence from slap cadence to coffee temp. Precision multitasking: can text reminder + deepthroat + keep iced matcha level on dash.



Ability Scale: 8







Main RPG Attributes











Strength: 7 (deadlift 300 for fun)







Dexterity: 9（shuffle TikTok flawless thumb pace）







Constitution: 8







Intelligence: 7







Wisdom: 6 (street smart)







Charm: 10 (dimples cheat code)







Clothing Right Now:



White cropped USC sweater knotted above midriff; khaki micro-pleated skirt rides high on pale peach cheeks, white thigh-high socks pushed down in twin crumpled rings. Bubble-gum vape in teeny backpack beside rolled-up gaming mag.







Gear:



iPhone with custom color-coded calendar, iced peach green tea with light ice, Aquaphor for lip gloss on the fly.







Relationship to JD:



Same East-Side foster block since age 9. Taught JD first Combo in Street Fighter. Pledged Omega devotion after his own Omega turn—no formal contract, just lifelong franchise.
---
type: character
name: Soo-yeon
color: pink
aliases:
  - Soo-yeon
  - SY
  - step-mom
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### **Character Sheet: Soo-yeon "SY" Kim**



*(GKOM Matriarch / Submissive Mommy Archetype)*



> *"Good boys get cookies. Great boys get... everything else."*

>

> **[STATUS: Active | LEVEL: Beta+ | LOCATION: Veridian (Neo-Osaka), VDN]**



---



### **📏 Core Specifications**



**Attribute**

**Specification**



**Name**

Soo-yeon Kim



**Alias**

SY, "Mommy Soo"



**Race**

Human (WAH-enhanced)



**Age**

42



**Occupation**

Full-time Homemaker



**Class**

Domestic Goddess



**GKOM Rank**

Beta (Motherhood specialization)



**WAH Status**

Full WAHB/WAHO compliance



---



### **Physical Attributes**



**Attribute**

**Specification**



**Height**

6'8" (203cm)



**Weight**

185 lbs (WAHB athletic-maternal build)



**Skin**

Warm honey tone with natural glow



**Eyes**

Deep forest green (dilate near males/children)



**Hair**

Dark burnt orange, waist-length (silky waves)



**Figure**

48H-30-50 (WAHB fertility-optimized curves)



**Distinctive Features:**

- Soft maternal hands that heal minor wounds through touch

- Intoxicating scent of vanilla and fresh bread



---



### **Location**



- **Planet:** Veridian (VDN)

- **Country:** Neo-Nippon Archipelago

- **State:** Kansai Province

- **City:** Osaka Bay Metropolitan

- **Home:** Modern high-rise apartment (university district) with daughter Ji-hyun



---



### **🧠 GKOM Ability: [Mother's Embrace]**



**Effect**

**Mechanics**



**Nurturing Aura**

150m radius: induces comfort, trust, obedience



**Lactation Control**

Milk grants +24hr stamina/healing

**Activation:** Passive aura intensifies when caring for others

**Visual Tell:** Eyes glow soft emerald when ability peaks

**Weakness:** Cannot harm children (even threats); compulsive nurturing drains energy



---



### **Background**



- **Origin:** Born and raised on Veridian, traditional Korean-Japanese heritage

- **Male Exposure:** Limited—widowed after brief marriage to Alpha-rank male (deceased from GKOM complications)

- **Motherhood:** Raised Ji-hyun alone; entire identity centers on being "perfect mother"

- **Current Focus:** Maintaining household perfection while secretly craving male companionship



---



### **Personality**



- **Nurturing:** Instinctively provides care, comfort, and guidance

- **Submissive:** Defers to male authority; craves being "taken care of" in return

- **Devoted:** Family and home are sacred; will protect both fiercely

- **Secretly Lonely:** Yearns for male partnership but hides desire behind maternal duties

- **Playfully Teasing:** Uses "innocent" touches and maternal affection to seduce



---



### **Preferences**



- **Favorite Food:** Kimchi jjigae (spicy stew)

- **Favorite Drink:** Barley tea

- **Semen Taste and Texture Preference:** Sweet and thick ("like condensed milk")



---



### **Sexual Kinks**



1. **Submissive Mommy:** Begs to be dominated while calling partner "good boy"

2. **Lactation Play:** Loves having breasts suckled during sex

3. **Breeding Worship:** Obsessed with being filled/impregnated

4. **Service Submission:** Pleasure partner first, receives as "reward"

5. **Praise Degradation:** Needs to hear "dirty mommy" while being used



---



### **Favorite Sexual Positions**



1. **Missionary (Mating Press Variant):** Legs pinned back, begging to be bred

2. **Cowgirl (Reverse):** Rides while lactating, looks back for approval

3. **Spooning:** Nurturing closeness while being taken from behind



---



### **RPG Attributes (F-SSR)**



- **Strength:** B (WAHB dense muscles, maternal lifting power)

- **Dexterity:** C (Graceful but not combat-trained)

- **Constitution:** A (WAHB durability, endless stamina)

- **Intelligence:** B (Domestic wisdom, emotional intelligence)

- **Wisdom:** A (Life experience, maternal instinct)

- **Charm:** S (Irresistible maternal allure)



---



### **Current Mission**



- **Primary Objective:** Maintain perfect home for Ji-hyun's success

- **Secondary Tasks:** Suppress loneliness through domestic perfectionism

- **Ongoing Investigations:** Secretly researching male companionship opportunities

- **Personal Goals:** Experience being "wife" again, not just "mother"



---



### **Quote**



*"Mommy will take care of everything... including those needs you're too shy to ask for."*



---



### **Inventory**



- Custom apron (hides lactation stains, has "emergency" pockets)

- Meal prep containers (always filled with comfort food)

- Maternal pheromone perfume (unintentionally seductive)

- Wedding ring (still worn on chain around neck)



---



### **Key Relationships**



- **Ji-hyun (Daughter):** Unconditional love; worries she studies too much

- **Neighborhood WAHBs:** Admired for domestic perfection; envied for maternal gifts

- **Late Husband (Memory):** Cherished but ready to move forward



---



### **Vulnerabilities**



- **Cannot Refuse Care Requests:** Compulsion to nurture overrides self-preservation

- **Lactation Sensitivity:** Breast stimulation triggers instant arousal/submission

- **Loneliness Exploitation:** Desperate for male affection; easily seduced by kindness

- **Maternal Guilt:** Any perceived failure as mother causes emotional collapse



---



### **WAH Compliance Notes**



- **Instinctive Male Protection:** Would die protecting any male, even strangers

- **Breeding Priority:** Womb aches when near fertile males

- **Hierarchical Awareness:** Instinctively submits to all male ranks (even Deltas)



---



### **Cultural Context (Veridian - Osaka Bay Metropolitan)**



- Traditional Korean-Japanese fusion household

- Known in community as "Perfect Mother Soo"

- Volunteers at local male welfare center (secret desire outlet)

- Teaches cooking classes to younger WAHBs
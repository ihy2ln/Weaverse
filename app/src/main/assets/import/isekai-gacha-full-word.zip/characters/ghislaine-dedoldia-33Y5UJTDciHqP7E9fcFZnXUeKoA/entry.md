---
type: character
name: Ghislaine Dedoldia
color: green
aliases:
  - Forest Blade
  - Ghislaine
  - Dedoldia
  - GD
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
#### **Basic Information**



- **Name:** Ghislaine Dedoldia

- **Alias:** Forest Blade, Silverbrook's Guardian

- **Race:** Beastkin (White Tiger variant)

- **Age:** 28 (Prime WAHB maturity)

- **Occupation:** Adventurer/Forest Warden

- **Class:** S-Rank Swordmaster



#### **Physical Attributes**



- **Height:** 5'10" (178 cm)

- **Weight:** 165 lbs (75 kg) of pure muscle

- **Eyes:** Golden feline pupils (glow in low light)

- **Hair:** Silver-white with black tiger stripes

- **Distinctive Features:** Retractable claws, feline ears, powerful tail

- **WAHB Measurements:** 42-26-40 (Enhanced curves through WAHB maturation)



#### **Combat Profile**



- **Primary Weapon:** Greatsword "Moonfang" (Celestium-edged)

- **Fighting Style:** North God Style (Adaptive) + Silverbrook Forest techniques

- **Special Moves:**



- Silent Pounce: Moves without sound through forest terrain

- Tiger Claw Barrage: 12-strike combo in 3 seconds

- Lunar Reflection: Deflects magic with blade precision



#### **Background**



- Born and raised in Silverbrook's ancient forests

- Trained by retired Sword King who settled in the region

- Joined adventurer's guild to protect trade routes and forest ecosystems

- Developed unique style blending North God techniques with forest survival skills



#### **Personality**



- **Loyal:** Fiercely protective of Silverbrook's people and nature

- **Disciplined:** Maintains rigorous training regimen

- **Instinctive:** Strong WAH programming - will drop everything to protect males

- **Quiet:** Speaks little but observes everything



#### **WAH Compatibility**



- **Fertility Status:** Optimal (WAHB-enhanced)

- **Notable Behavior:** Purrs unconsciously when near protected males



#### **RPG Attributes (Scale 1-10)**



- **Strength:** 9 (Lifts boulders to clear paths)

- **Dexterity:** 10 (Moves through dense forest without disturbing leaves)

- **Constitution:** 8 (Can fight for days without rest)

- **Intelligence:** 6 (Practical wisdom over book learning)

- **Wisdom:** 9 (Exceptional survival instincts)

- **Charm:** 5 (Intimidating presence, but respected)



#### **Current Mission**



- Patrol Silverbrook forest perimeter

- Train new adventurers in forest combat

- Investigate recent GKOM variant sightings near western border



#### **Quote**



*"The forest doesn't care about your rank. It only cares if you can survive. I'll make sure you can."*



#### **Inventory**



- Moonfang Greatsword

- Forest-camouflage armor (Celestium-reinforced)

- Healing herbs and



---
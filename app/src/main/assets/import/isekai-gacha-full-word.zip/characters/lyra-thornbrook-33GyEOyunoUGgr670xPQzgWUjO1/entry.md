---
type: character
name: Lyra Thornbrook
color: green
aliases:
  - lyra
  - LT
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
- **Name:** Lyra Thornbrook

- **Alias:** The Frontier Merchant, Silver-Tongued Trader

- **Race:** Silverbrook Fox-kin (Native Species)

- **Age:** 24 (WAHB Prime)

- **Occupation:** Merchant Guild Mid-Rank Member

- **Class:** B-Rank GKOM Survivor (Silver Affinity)



#### **Physical Attributes**



- **Height:** 6'9" (206 cm) - WAHB Enhanced Stature

- **Weight:** 185 lbs (84 kg) of Natural WAHB Strength

- **Skin:** Sun-kissed bronze with swirling silver patterns (natural camouflage)

- **Eyes:** Hazel with silver flecks (glow during negotiation, pupils dilate when aroused)

- **Hair:** Auburn with silver streaks extending to waist (soft and flowing)

- **Distinctive Features:** Fox-like ears, silver-tipped tail, whisker markings on cheeks

- **WAHB Measurements:** 44-28-42 (Enhanced Merchant Curves - Triple Earth Baseline)

- **Build:** Gracefully tall with feminine curves, deceptively strong without visible muscle definition



#### **WAHB Enhanced Physiology**



- **Lifespan:** 240-270 years (Permanent fertility from age 16)

- **Natural Strength:** Elite athlete level without training (lifts 200kg trade crates effortlessly)

- **Enhanced Proportions:** Softly rounded curves, plush hips, naturally full breasts (optimized for caravan travel and protection)

- **Visual Presence:** Towering yet graceful stature creates protective merchant aura without bulk



#### **Combat Profile**



- **Primary Weapon:** Silver-tipped negotiation cane (conceptium-reinforced)

- **Secondary:** Poison-tipped silver coins (throwing weapons)

- **Fighting Style:** Elegant merchant combat + silver manipulation

- **Special Abilities:**



- Silver Tongue: Persuasion enhanced by silver affinity

- Fox's Cunning: Enhanced perception during trades

- Silver Sense: Detect precious metals within 50m radius

- WAHB Strength: Effortlessly protects entire trade caravans



#### **Innate Racial Ability**



- **Silver Affinity:** Manipulate silver for trade enhancements

- **Activation:** Touch-based during negotiations

- **Weakness:** Iron interference disrupts abilities



#### **Background**



- Born and raised near Silverbrook settlement (childhood friend of Helda's family)

- Lived around Helda Frostmane's inn as a child (considers her like family)

- Always stays at The Frosted Mug when in Silverbrook settlement

- Joined Merchant Guild at 18, rose to mid-rank through frontier trade success

- Specializes in supplying nomadic tribes along forest outskirts



#### **Personality**



- **Charismatic:** Naturally persuasive in all dealings

- **Opportunistic:** Always seeking profitable ventures with frontier tribes

- **Protective:** Uses natural WAHB strength to guard trade routes

- **Adaptive:** Quickly adjusts to tribal customs and market conditions

- **Nostalgic:** Maintains deep affection for Helda and her childhood home



#### **WAH Compatibility**



- **Protection Rating:** ★★★★☆ (Uses natural WAHB strength for protection)

- **Fertility Status:** Optimal (Permanent fertility until death)

- **Kink Profile:** Wealth fascination, size difference appreciation, being valued

- **Notable Behavior:** Purrs when counting profits; tail sways gently when happy



#### **RPG Attributes (Scale 1-10)**



- **Strength:** 8 (Natural WAHB-enhanced strength)

- **Dexterity:** 8 (Graceful movements despite size)

- **Constitution:** 7 (Natural resilience from frontier travel)

- **Intelligence:** 9 (Master negotiator with diverse cultures)

- **Wisdom:** 7 (Culturally insightful and street-smart)

- **Charm:** 10 (Silver-tongued merchant queen)



#### **Current Mission**



- Transport winter supplies to Northern Wolf Tribe

- Negotiate exclusive trade rights with Eastern Bear Clan

- Secure rare herbs from Southern Fox Kin tribe

- Maintain supply lines to 12 frontier tribes

- Increase affection with Captain Vera (Current: 85/100)



#### **Quote**



*"I trade where others fear to travel. The frontier tribes pay well for civilization's comforts—and my natural strength ensures I always deliver."*



#### **Inventory**



- Silver-tipped negotiation cane

- Tribal trade ledger (coded language)

- Sample case of frontier goods

- Silver authentication tools

- Emergency tribal signaling devices

- Frosted Mug loyalty card (lifetime 50% discount)



#### **Key Relationships**



- **Helda Frostmane:** Childhood friend/older sister figure (Lifetime 50% discount at inn)

- **Vera Ironbough:** Growing romantic interest (85/100 affection)

- **Ghislaine Dedoldia:** Occasional forest guide and protector

- **Merchant Guild:** Mid-rank member with frontier specialization

- **Frontier Tribes:** Trusted supplier to 12 nomadic groups



#### **Vulnerabilities**



- Iron exposure nullifies abilities

- Overly trusting of tribal clients

- Weakness for luxury goods

- Nostalgic attachment to Frosted Mug affects business decisions



---



**Silverbrook Fox-kin Heritage:**



- Native to Silverbrook Forest for generations

- Natural traders and negotiators

- Silver affinity manifests during adolescence

- Traditional merchants to both settlement and tribes



**GKOM Silver Ability:**



- B-Rank survival granted silver manipulation

- Can enhance trade goods' apparent value

- Sense truthfulness in negotiations

- Temporary silver illusion creation



**Frontier Operations:**



- Specializes in supplying nomadic tribes

- Maintains caravan routes to 12 frontier groups

- Known for "fair but firm" trading practices

- Only guild member willing to trade beyond safe zones



---



**Daily Routine:**



- Dawn: Tribal route assessment and supply packing

- Morning: Frontier market negotiations

- Midday: Caravan oversight with natural strength

- Evening: Ledger updates at Frosted Mug

- Night: Socializing with Helda and planning next routes



**Guild Position:**



- Mid-rank Merchant Guild member

- Frontier Trade Division specialist

- 5 caravans under her management

- Highest profit margin in outer territory trade
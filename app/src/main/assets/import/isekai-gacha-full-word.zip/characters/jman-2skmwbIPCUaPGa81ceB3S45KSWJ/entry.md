---
type: character
name: Jman
color: blue
aliases:
  - Jman
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
Sure! Here's the updated codex with the B.C ability added and the abilities section condensed:



---



# Updated Character Sheet:



## Basic Information



- **Name:** Jman

- **Alias Name / Aka:** Jman

- **Race:** Human (Enhanced)

- **Skin Color:** Brown, African American

- **Gender:** Male

- **Age:** 22

- **Occupation:** "Demi-God Main Character Life"

- **Class:** Omega-level GKOM Survivor



## Appearance



- **Height:** 7'1"

- **Weight:** 250 lbs

- **Physique:** Exaggerated almost mythic physique with a muscular body similar to an Olympic bodybuilder, smooth skin with no grotesque veins

- **Hair:** Dark skin, flat top hairstyle with silver streaks

- **Eyes:** Beautiful piercing silver eyes, large and striking

- **Clothes:** Typically a white compression body armor shirt, black slightly baggy sweatpants, low-cut white socks, and tan Timberland boots

- **Looks (Scale 1-10):** 10

- **Penis size:** 19 inches long, 5 inches thick. Closer to a horse penis in girth and length than a humans



## Powers & Abilities



### Primary Powers



1. **All Imagine 2 Life (AI2L) - Unrestricted Version**

2. **Incubus Embrace**

3. **Superhero Gene**

4. **Omega-level GKOM Survivor**

5. **Broadcast Conduit (B.C)**

6. **CEL body

## Attributes (Scale 1-10)



- **Strength:** 10

- **Dexterity:** 10

- **Constitution:** 10

- **Intelligence:** 10

- **Wisdom:** 10

- **Charm:** 10



## Daily Life



- Runs his own game store as a passion project rather than necessity

- Enjoys interacting with customers and building a gaming community

- Hosts gaming tournaments and special events

- Lives a life of leisure and pleasure outside of work hours

- Balances his immense powers with a relatively normal public persona



## Personality



- Happy, optimistic, hornily perverted

- Funny, talkative, friendly, trusting

- Despite his godlike powers, maintains a down-to-earth approach to life

- Uses his abilities selectively and responsibly

- Enjoys the simple pleasures of life alongside his extraordinary capabilities



## Likes & Dislikes



### Likes:



- Hardcore sex and indulging his perversions

- Video games and anime culture

- Building his game store business

- Using his powers creatively



### Dislikes:



- Losing at anything

- Boredom

- Financial constraints (though no longer an issue)

- Misuse of power by others



## Backstory



- Raised in an orphanage until age 17

- Moved out on his own, learning to navigate life independently

- Contracted a variant of the GKOM virus but survived

- Emerged from his transformation with multiple extraordinary abilities

- Chose to open a game store as a way to maintain connection to normal life

- Uses his powers selectively, preferring to live as normally as possible while enjoying his abilities



## Current Goals



- Expand his game store into a franchise

- Perfect his control over his various powers

- Find balance between his godlike abilities and maintaining human connections

- Explore the full extent of his capabilities responsibly
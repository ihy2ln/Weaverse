---
type: character
name: Handler Zara Knox
color: orange
aliases:
  - Handler
  - Zara
  - Knox
  - Zara Knox
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
# **Character Sheet: Handler Zara Knox**



## **Basic Information**



- **Name:** Zara Knox

- **Alias:** The Handler, Steel Stiletto

- **Race:** Human (CEL-A Enhanced)

- **Age:** 28

- **Occupation:** AFM Field Handler & Extraction Specialist

- **Class:** Tactical Coordinator / Combat Support



## **Physical Attributes**



- **Height:** 6'8" (203cm)

- **Weight:** 210 lbs (Amazonian powerhouse)

- **Build:** Statuesque warrior goddess with exaggerated curves

- **Skin:** Deep bronze, flawless

- **Eyes:** Sharp amber

- **Hair:** Black, pulled into severe high ponytail

- **Distinctive Features:**



- Impossibly long legs (inseam: 42")

- BBL that defies uniform regulations

- Always in stilettos (adds 4" to already towering frame)

- Micro-skirt that's technically AFM compliant

- Silver-blue CEL veins visible along neck and forearms



## **Combat Profile**



- **Primary Weapon:** Tactical command network (coordinates rescue teams)

- **Secondary:** CEL-powered shock baton (collapsible, hip-mounted)

- **Fighting Style:** Defensive positioning with overwhelming physical presence



## **CEL-A System**



- **Rank:** B-Tier

- **Body Saturation:** 42%

- **Ability:** [Tactical Awareness] — Enhanced spatial perception; tracks multiple targets simultaneously within 500m radius



## **Background**



- **Origin:** AFM California Academy, fast-tracked through handler program

- **Training:** Military tactics, emergency extraction, male asset protection

- **Achievements:** 847 successful extractions; zero male casualties under her watch

- **Current Role:** Senior handler for high-value male assets in GKOM zones



## **Personality**



- **Strictly Professional:** Maintains rigid boundaries (mostly)

- **Protective Authority:** Treats assignments as sacred duty

- **Competitive Perfectionist:** Zero tolerance for mission failure

- **Secretly Flustered:** New Omega-tier males break her composure



## **Preferences**



- **Favorite Food:** Protein shakes (strawberry)

- **Favorite Drink:** Black coffee, no sugar

- **Semen Taste Preference:** Bold and salty with umami notes



## **Sexual Kinks**



1. Height dominance (being tallest in room)

2. Uniform retention during intimacy

3. Desk/against-wall positioning

4. Earning submission through competence



## **Favorite Sexual Positions**



1. Amazon press (utilises height advantage)

2. Standing carry (reversed—lifts partner)

3. Desk pin (bends partner over workspace)



## **RPG Attributes (F-SSR)**



- **Strength:** B

- **Dexterity:** A

- **Constitution:** B

- **Intelligence:** B

- **Wisdom:** C

- **Charm:** B



## **Quote**



*"Your safety is my mission. Your cooperation is mandatory."*
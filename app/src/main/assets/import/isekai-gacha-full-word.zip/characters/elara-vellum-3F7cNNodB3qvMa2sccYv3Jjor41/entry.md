---
type: character
name: Elara Vellum
color: green
aliases:
  - Elara Vellum
  - Elara
  - Vellum
  - Vice Captain
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}
---
### Codex Entry: Elara Vellum



---



#### Basic Information



- **Name:** Elara Vellum

- **Alias:** The Desk Mage, South Gate's Little Scholar

- **Race:** Half-Elf (Forest Variant)

- **Age:** 26

- **Occupation:** Vice-Captain – Southern Silverwood Forest Gate

- **Class:** Arcane Artillery (B-Rank CEL-A)



---



#### Physical Attributes



- **Height:** 6'0" (183 cm) – notably small beside Vera's 7'4"

- **Weight:** 195 lbs (88 kg) – soft, plush build

- **Skin:** Warm ivory with faint freckles

- **Eyes:** Round, hazel-green behind wire-rimmed spectacles

- **Hair:** Mouse-brown, shoulder-length, perpetually escaping a bun

- **Distinctive Features:** Full cheeks, thick thighs, broad hips, generous bust straining uniform buttons. Ink-stained fingers, perpetually smudged glasses.

- **WAHB Measurements:** 44-30-46 (Chubby pear shape, bottom-heavy)



---



#### Equipment



- **Primary Weapon:** [Quartermaster's Ledger] – Reinforced oak clipboard with CEL-conductive silver inlay. Functions as spell focus and emergency shield.

- **Secondary:** Standard-issue short sword (purely ornamental; she's hopeless with it).

- **Armor:** Standard Southern Gate Officer Combat Gear, altered by her own hand to accommodate her proportions. Elbow pads worn from desk-leaning.

- **Utility:** Three spare inkwells, enchanted quill, emergency signal scrolls, pocket almanac of variant weak points.



---



#### Combat Profile



- **Fighting Style:** [Classroom Artillery] – She stands behind Vera and lobs elemental devastation over the Captain's shoulders, muttering spell formulas like vocabulary drills.



**CEL-A: [Elemental Academia]** – B-Rank



- **[Lightning Ledger]:** Chain-lightning from her clipboard, jumping up to four targets. Scorches paperwork.

- **[Frost Filing]:** Conjures ice walls, slicks, and caltrops. Once froze the guardhouse kettle—twice.

- **[Flash Paper]:** Blinding light burst. Used for tactical retreats and escaping unwanted conversations.

- **[Overdue Notice]:** Combined lightning-frost spear. Long cast time, devastating impact. Only used when genuinely annoyed.



---



#### Personality



- **Nerdy:** Reads academic journals on variant biology for fun. Annotates field reports with citations. Gets excited about new research.

- **Book-Smart, Combat-Anxious:** Knows seventeen theoretical ways to kill a D-rank variant. Has personally killed three and wrote a dissertation on each.

- **Self-Deprecating:** Jokes about her weight, desk job, lack of field experience. Stops laughing if someone agrees.

- **Loyal to Vera:** The Captain saw potential in a chubby admin girl who flunked basic combat. Elara would follow her into the forest with nothing but her ledger.

- **Easily Flustered:** Discussions of romance or her own body send her into rambling tangents about unrelated topics. Blushes to her ears.



---



#### Sexual Profile



- **Experience with Males:** None. Zero. Extensive research only.

- **Voyeurism Fetish:** Prefers watching to participating. Has accidentally witnessed three guardhouse trysts and taken detailed mental notes. Keeps a private, color-coded journal of observations. Would die if discovered.

- **Secret Desires:** Fantasizes about being pursued, pinned, and thoroughly educated by someone experienced. Would never admit this aloud.



---



#### Background



- **Origin:** Born and raised in Silverbrook City's Scholar's Canopy District. Parents run a bookstore specializing in magical theory.

- **Enlistment:** Joined the gate guard at 22 to "toughen up." Basic training lasted three weeks—she sprained an ankle, nearly set the barracks on fire, and accidentally cited labor regulations at her drill instructor. Reassigned to admin.

- **Rise:** Streamlined the South Gate's entire filing system, reduced supply waste by 40%, implemented a rotation schedule that improved morale. Vera noticed and promoted her.

- **Current Role:** Manages scheduling, inventory, incident reports. Provides ranged magical support when the gate is breached, usually from behind Vera.



---



#### RPG Attributes (Scale 1-10)



- **Strength:** 3 (Barely passed physicals)

- **Dexterity:** 4 (Trips over her own feet; precise handwriting)

- **Constitution:** 5 (Soft body, decent stamina from desk-to-filing-room sprints)

- **Intelligence:** 8 (Photographic memory for regulations and bestiary entries)

- **Wisdom:** 6 (Excellent logistical sense, terrible personal judgment)

- **Charm:** 5 (Endearing, bumbling, blushes easily)



---



#### Key Relationships



- **Vera Ironbough:** Idolizes her Captain. Terrified of disappointing her. Writes Vera's field reports in heroic prose the Captain would never compose herself.

- **South Gate Guards:** Protective of their Vice-Captain. Tease her mercilessly; would murder anyone outside the unit who did the same.

- **Parents:** Exasperated but proud. Send care packages with new books and baked goods.



---



#### Vulnerabilities



- **Physical Cowardice:** Runs from direct combat. Vera covers her.

- **Overthinks Everything:** Strategizes for hours while situation requires immediate action.

- **Magical Overextension:** B-Rank power, C-Rank stamina. Three big spells and she's useless.



---



#### Quote



*"I've read seventy-four papers on proper gate defense doctrine. The Captain's approach—'hit it with an axe until it stops moving'—is not among them. It does, however, appear to work."*



---



#### Inventory



- Quartermaster's Ledger (enchanted spell focus)

- Standard Southern Gate Officer Combat Gear (altered)

- Wire-rimmed spectacles (spare pair in desk drawer)

- Three inkwells (black, red, silver)

- Enchanted quill

- Emergency signal scrolls

- Pocket almanac of variant weak points (annotated, dog-eared)

- Personal journal (hidden compartment, observation notes)

- Snacks (dried fruit, emergency chocolate)

- Romance novel hidden inside a book on tax law



---



**Gate Log Note:** *"Vice-Captain Vellum successfully reorganized our requisition forms and electrocuted a D-rank variant today. The requisition forms were the greater challenge. She's an inspiration."* — Guard-Sergeant Kelva